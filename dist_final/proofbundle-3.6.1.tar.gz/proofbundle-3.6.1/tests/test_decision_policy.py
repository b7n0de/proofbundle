"""WP5 tests: trust policy v0.2 decision_receipt section + evaluate_decision_policy (fail-closed).

Backward compat (v0.1 policy valid under the v0.2 parser), the additive section rules, signer<->trusted-key
binding, predicateType confusion at the policy layer, and the exit-3 contract end to end.
unittest-style to match the repo's `python -m unittest discover`."""
from __future__ import annotations

import base64
import json
import unittest
from pathlib import Path

from proofbundle.decision import build_decision_statement, emit_decision_receipt, verify_decision_receipt
from proofbundle.emit import generate_signer
from proofbundle.policy import PolicyError, evaluate_decision_policy, load_policy

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


def _pred(name: str = "deny") -> dict:
    return json.loads((EXAMPLES / f"decision_receipt_{name}.json").read_text(encoding="utf-8"))


def _keys():
    s = generate_signer()
    return s, base64.b64encode(s.public_key().public_bytes_raw()).decode()


def _policy_trusting(pub_b64: str, **overrides) -> dict:
    section = {
        "accepted_predicate_types": ["https://b7n0de.com/proofbundle/predicates/decision-receipt/v0.1"],
        "trusted_decision_makers": [{"id": "https://example.org/decision-platform/proofbundle-gate/v1", "public_key_b64": pub_b64}],
        "allowed_decision_types": ["preActionAuthorization", "humanEscalation"],
        "allowed_verdicts": ["ALLOW", "DENY", "ESCALATE"],
        "required_evidence_relations": ["evalResult"],
        "require_policy_digest": True,
    }
    section.update(overrides)
    return {"schema": "proofbundle/trust-policy/v0.2", "policy_id": "t", "decision_receipt": section}


class TestDecisionPolicyLoad(unittest.TestCase):
    def test_v01_policy_valid_under_v02_parser(self):
        v01 = load_policy({"schema": "proofbundle/trust-policy/v0.1", "policy_id": "x"})
        self.assertEqual(v01["schema"], "proofbundle/trust-policy/v0.1")

    def test_v02_decision_section_loads(self):
        # a real full-order key — load_policy now rejects a low-order / malformed pinned key
        p = load_policy(_policy_trusting("Ts6DJw7AT4alPGqp9JVzh83VvXoMcRXVU0Lb7R2qB08="))
        self.assertIs(p["decision_receipt"]["require_policy_digest"], True)

    def test_decision_section_under_v01_schema_rejected(self):
        bad = {"schema": "proofbundle/trust-policy/v0.1", "policy_id": "x",
               "decision_receipt": {"require_policy_digest": True}}
        with self.assertRaises(PolicyError):
            load_policy(bad)

    def test_unknown_decision_field_rejected(self):
        bad = {"schema": "proofbundle/trust-policy/v0.2", "policy_id": "x", "decision_receipt": {"surprise": 1}}
        with self.assertRaises(PolicyError):
            load_policy(bad)


class TestEvaluateDecisionPolicy(unittest.TestCase):
    def test_trusted_signer_policy_ok(self):
        _, pub = _keys()
        stmt = build_decision_statement(_pred("deny"))
        r = evaluate_decision_policy(stmt, {}, load_policy(_policy_trusting(pub)), signer_public_key_b64=pub)
        self.assertTrue(r["signer_trusted"] and r["policy_ok"] and r["errors"] == [])

    def test_untrusted_signer_fails(self):
        _, pub = _keys()
        _, other = _keys()
        stmt = build_decision_statement(_pred("deny"))
        r = evaluate_decision_policy(stmt, {}, load_policy(_policy_trusting(other)), signer_public_key_b64=pub)
        self.assertIs(r["signer_trusted"], False)
        self.assertIs(r["policy_ok"], False)

    def test_predicate_type_confusion_fails_policy(self):
        _, pub = _keys()
        stmt = build_decision_statement(_pred("deny"))
        stmt["predicateType"] = "https://b7n0de.com/proofbundle/predicates/eval-result/v0.1"
        r = evaluate_decision_policy(stmt, {}, load_policy(_policy_trusting(pub)), signer_public_key_b64=pub)
        self.assertIs(r["policy_ok"], False)
        self.assertTrue(any("accepted_predicate_types" in e for e in r["errors"]))

    def test_verdict_not_allowed_fails(self):
        _, pub = _keys()
        p = _policy_trusting(pub, allowed_verdicts=["ALLOW"])
        r = evaluate_decision_policy(build_decision_statement(_pred("deny")), {}, load_policy(p), signer_public_key_b64=pub)
        self.assertIs(r["policy_ok"], False)
        self.assertTrue(any("verdict" in e for e in r["errors"]))

    def test_missing_required_evidence_relation_fails(self):
        _, pub = _keys()
        pred = _pred("deny")
        pred["evidenceRefs"] = []
        r = evaluate_decision_policy(build_decision_statement(pred), {}, load_policy(_policy_trusting(pub)), signer_public_key_b64=pub)
        self.assertIs(r["policy_ok"], False)
        self.assertTrue(any("evidence relations" in e for e in r["errors"]))

    def test_no_decision_section_is_not_evaluated(self):
        r = evaluate_decision_policy(build_decision_statement(_pred("deny")), {},
                                     {"schema": "proofbundle/trust-policy/v0.1", "policy_id": "x"},
                                     signer_public_key_b64="AAAA")
        self.assertIsNone(r["policy_ok"])


class TestVerifyWithPolicy(unittest.TestCase):
    def test_verify_with_policy_ok(self):
        s, pub = _keys()
        env = emit_decision_receipt(_pred("deny"), s, strict=True)
        r = verify_decision_receipt(env, s.public_key().public_bytes_raw(), strict=True,
                                    policy=load_policy(_policy_trusting(pub)))
        self.assertTrue(r["crypto_ok"] and r["structure_ok"] and r["policy_ok"] and r["signer_trusted"])

    def test_verify_with_policy_violation(self):
        s, _ = _keys()
        env = emit_decision_receipt(_pred("deny"), s, strict=True)
        _, other = _keys()
        r = verify_decision_receipt(env, s.public_key().public_bytes_raw(),
                                    policy=load_policy(_policy_trusting(other)))
        self.assertIs(r["crypto_ok"], True)
        self.assertIs(r["policy_ok"], False)


class TestDecisionPolicyKnobs(unittest.TestCase):
    """v0.2 governance knobs from the course-correction: each presence/privacy/shape knob with a violation
    that must fail the policy, plus mistyped-flag fail-closed parsing."""

    def _eval(self, pred, section):
        _, pub = _keys()
        pol = load_policy({"schema": "proofbundle/trust-policy/v0.2", "policy_id": "t",
                           "decision_receipt": section})
        return evaluate_decision_policy(build_decision_statement(pred), {}, pol, signer_public_key_b64=pub)

    def test_require_audience(self):
        p = _pred("deny")
        p.pop("validity", None)
        self.assertIs(self._eval(p, {"require_audience": True})["policy_ok"], False)
        self.assertIs(self._eval(_pred("deny"), {"require_audience": True})["policy_ok"], True)

    def test_require_nonce(self):
        p = _pred("deny")
        p["validity"] = {"audience": ["x"]}
        self.assertIs(self._eval(p, {"require_nonce": True})["policy_ok"], False)

    def test_require_not_checked_and_change_conditions(self):
        p = _pred("deny")
        p["notChecked"] = []
        self.assertIs(self._eval(p, {"require_not_checked": True})["policy_ok"], False)
        q = _pred("deny")
        q["decisionChangeConditions"] = []
        self.assertIs(self._eval(q, {"require_decision_change_conditions": True})["policy_ok"], False)

    def test_require_trace_context(self):
        self.assertIs(self._eval(_pred("deny"), {"require_trace_context": True})["policy_ok"], False)
        p = _pred("deny")
        p["traceContext"] = {"traceparent": "00-00000000000000000000000000000000-0000000000000000-01"}
        self.assertIs(self._eval(p, {"require_trace_context": True})["policy_ok"], True)

    def test_allow_raw_inputs_default_false(self):
        p = _pred("deny")
        p["privacy"]["rawInputsIncluded"] = True
        self.assertIs(self._eval(p, {})["policy_ok"], False)
        self.assertIs(self._eval(p, {"allow_raw_inputs": True})["policy_ok"], True)

    def test_require_policy_digest_failing_branch(self):
        p = _pred("deny")
        p["policyBoundary"].pop("policyDigest", None)
        self.assertIs(self._eval(p, {"require_policy_digest": True})["policy_ok"], False)

    def test_allowed_decision_types_violation(self):
        self.assertIs(self._eval(_pred("deny"), {"allowed_decision_types": ["postHocReview"]})["policy_ok"], False)

    def test_mistyped_bool_flag_rejected(self):
        with self.assertRaises(PolicyError):
            load_policy({"schema": "proofbundle/trust-policy/v0.2", "policy_id": "t",
                         "decision_receipt": {"require_audience": "false"}})


class TestDecisionPathTemplateAndExpiryGate(unittest.TestCase):
    """L5 pre-land audit — the decision path mirrors the eval-path AP-1/AP-2 guards, which previously had NO
    analog here: a RAW template (requiresIdentityOverlay:true) authorised a receipt signed by any key, and an
    EXPIRED policy still authorised. Both are now fail-closed → policy_ok=False → CLI exit 3."""

    def _policy_top(self, pub, **top):
        pol = _policy_trusting(pub)   # an otherwise-passing decision policy for _pred("deny")
        pol.update(top)               # add TOP-LEVEL fields (requiresIdentityOverlay / valid_until)
        return pol

    def _verify(self, s, pub, **top):
        env = emit_decision_receipt(_pred("deny"), s, strict=True)
        return verify_decision_receipt(env, s.public_key().public_bytes_raw(), strict=True,
                                       policy=load_policy(self._policy_top(pub, **top)))

    def test_baseline_instantiated_policy_authorises(self):
        # positive control: a pinned, non-template, non-expired decision policy authorises the matching signer
        s, pub = _keys()
        r = self._verify(s, pub, requiresIdentityOverlay=False, valid_until="2099-01-01T00:00:00Z")
        self.assertTrue(r["policy_ok"] and r["signer_trusted"])

    def test_raw_template_flag_does_not_authorise(self):
        s, pub = _keys()
        r = self._verify(s, pub, requiresIdentityOverlay=True)   # raw template, un-instantiated
        self.assertIs(r["policy_ok"], False)
        self.assertIs(r["ok"], False)
        self.assertTrue(any("raw template" in e for e in r["errors"]))

    def test_expired_decision_policy_does_not_authorise(self):
        s, pub = _keys()
        r = self._verify(s, pub, valid_until="2020-01-01T00:00:00Z")   # instantiated but expired
        self.assertIs(r["policy_ok"], False)
        self.assertIs(r["ok"], False)
        self.assertTrue(any("expired" in e for e in r["errors"]))

    def test_shipped_raw_decision_template_refused(self):
        # the ACTUAL shipped template (not a synthetic flag) refuses to authorise a decision as-shipped
        from proofbundle.policy_profiles import profile_path  # noqa: PLC0415
        raw = load_policy(profile_path("decision-receipt-template-v1"))
        self.assertIs(raw.get("requiresIdentityOverlay"), True)
        s, pub = _keys()
        res = evaluate_decision_policy(build_decision_statement(_pred("deny")), {}, raw,
                                       signer_public_key_b64=pub)
        self.assertIs(res["policy_ok"], False)
        self.assertTrue(any("raw template" in e for e in res["errors"]))

    def test_decision_verify_cli_resolves_profile_name(self):
        # L5-F3: `decision verify --policy <profile-name>` resolves the packaged profile (parity with the eval
        # path) instead of erroring "cannot read trust policy". The shipped template then refuses (exit 3), so
        # this one test proves BOTH resolve_policy_source parity AND the raw-template gate end-to-end.
        import contextlib  # noqa: PLC0415
        import io  # noqa: PLC0415
        import os  # noqa: PLC0415
        import tempfile  # noqa: PLC0415

        from proofbundle.cli import main  # noqa: PLC0415
        s, _pub = _keys()
        env = emit_decision_receipt(_pred("deny"), s, strict=True)
        pubk = base64.b64encode(s.public_key().public_bytes_raw()).decode()
        fd, epath = tempfile.mkstemp(suffix=".json")
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(env, f)
            err = io.StringIO()
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(err):
                rc = main(["decision", "verify", epath, "--pub", pubk,
                           "--policy", "decision-receipt-template-v1"])
        finally:
            os.unlink(epath)
        self.assertNotIn("cannot read trust policy", err.getvalue())   # resolved, not a file-not-found
        self.assertEqual(rc, 3)                                         # raw template → policy not satisfied


if __name__ == "__main__":
    unittest.main()
