# Test vectors of draft-gruszka-audit-decision-receipts-11

This package holds all 171 test vectors of Appendix A of draft-gruszka-audit-decision-receipts-08: the seven vectors
of Appendix A.3 (V1-good, V1-bad, V2-good, V2-bad, V3-decision, V3-good, V3-bad), the failure vectors F1 to F93, F95
to F125 with F17-outcome, the passing vectors V2-micro, V2-num, V2-rel, V3-rel, V3-seq, F94, V1-accept, V2-ref and
V3-late, K1 to K29 of the third check of Section 3.5 and S1 and S2 of its second check. Appendix A.3 gives V1-good
and V1-bad in full and identifies the other five vectors by their results and file hashes. The subsection [From Appendix A.5](#from-appendix-a5) below describes F10
and identifies its inputs; the package supplies the files, so that one run covers every vector. It also holds the example Signed Statements and SCITT Receipts for registration that
Appendix A.4 names.

For -10 the package also holds 444 further vectors, 615 in all. The sections Vectors added for -10, Vectors of the
merged parts of -10, Vectors added after the merge, Vectors added after the second reading and Vector added after
the third reading describe them; the paragraphs before those sections describe the 171 vectors of -08 as they were.

For -11 the package holds every vector of the package of -10 unchanged, with the same files, entries and recorded
outputs. It adds vectors/b-payload.json and the section Paragraphs that -10 gave in the draft.

## Contents

- vectors/ holds every envelope and every input that a check uses, under the names that expected.json gives. Among
  them are action bytes, approval records, consumption states, effect bytes and trust policies.
- vectors/b-payload.json holds the 458 bytes of the input B of Appendix A.1 of the draft, which -10 gave in base64
  and -11 gives by name, size and SHA-256.
- expected.json gives, for each vector, where the draft gives it, the result and step expected for it, the
  arguments of the verifier, its expected exit code and the start of its first output line, the output recorded
  when the package was made, and the proofbundle 6.6.0 commands with their recorded exit codes, and lists the
  checks of a4/.
- verifier/ holds a verifier of Sections 3 and 4 and of Appendix B written in Go from the text of the draft, with
  the Go standard library only. It checks a receipt in the DSSE binding of Section 3.10 or, with -binding cose (and
  -decision-binding cose for the decision of an outcome receipt), in the COSE_Sign1 binding of Appendix B; the
  binding is an input and is not taken from the receipt bytes. It runs the first check of Section 3.5 with -first
  and the approver signature of Section 3.11 with -approver-pub. It shares no code with proofbundle.
  verifier/BUILD.txt gives the build command and the SHA-256 of
  the program for one toolchain.
- run_vectors.py runs check_descriptions.py and then every vector against that verifier.
- check_descriptions.py searches the sources listed in its docstring for the words in WORDS, after the exclusions
  documented in its docstring. It exits with 1 when a match remains; run_vectors.py then stops before the vectors.
  Exit code 0 means that this word search found no match. It does not establish that descriptions contain no expected
  results; reviewing their meaning is also necessary.
- For the third check of Section 3.5 the verifier takes each receipt held as -held KEY:FILE, the expected signing
  key in base64 and the envelope. Before it looks up a predecessor, it checks every receipt held under its key, a
  decision receipt by steps 1 to 6 of Section 3.2 and an outcome receipt by steps 1 to 5 of Section 3.2 and step 2 of
  Section 3.4. The predicate of a receipt held must be a JSON object, and where it has relationships, that member and
  its entries must satisfy the field rules of Section 3.8 for relationships. Where a receipt held does not
  meet these checks, the input is invalid, the verifier gives no result
  for the third check and ends with exit code 2. Where a predecessor is not among the receipts held, the third check
  fails with exit code 4. A run without -held does not run the third check.
- For the second check of Section 3.5 the verifier takes, with -second, the same -held arguments and the same
  preliminary checks, and runs that check after the third. It reports an outcome receipt held with status executed
  whose decisionRef names the content root of a decision receipt held whose verdict is not ALLOW. If the third check
  passed, the verifier then exits with code 5; if the third check fails, its exit code 4 is kept, and the second
  check still runs and reports its result. A decisionRef that names no decision receipt held gives no conflict,
  because the check is only as complete as the receipts held. A run without -second does not run the second check
  and prints what it printed before.
- description.txt says, for every vector, how it is derived and which inputs the verifier is given: T, the
  envelope, keys, expected audience and nonce, case, action, effect and approval bytes, consumption state and trust
  policy, and for K1 to K29, S1 and S2 the receipts held with the expected signing key of each. inputs.json
  holds the same calls as expected.json. Neither names a result, so a verifier can be run
  blind against them; the expected results are in expected.json and the other expected files, and this README
  gives some of them in prose. V3-decision is checked as the pair with
  V3-good.
- a4/ holds the inputs of the registration examples. These are the V2-good envelope bytes, Signed Statements A and B, the
  detached payload of B, the counterexamples, the public test keys of the Issuer and of the Receipt issuer, and the
  two SCITT Receipts with a counterexample. A4-description.txt is the text that gave their bytes and described how
  they are built and checked.
- cose/ holds the vectors of the COSE_Sign1 binding of Appendix B, first-check/ those of the first check of Section
  3.5 and approver-signature/ those of the approver signature of Section 3.11. Each folder has its expected file with
  results and recorded outputs, its inputs file and its vectors; the README.md of first-check/ and of
  approver-signature/ says how their vectors are built. The inputs files describe each vector and its inputs and do
  not name its result, and neither do the README.md files of these folders.
- MANIFEST.sha256 lists the SHA-256 of every other file.
- The relying-party inputs of Section 4 have these forms. A consumption state is either a JSON array of
  approval identities, each an object with approvalId, actionDigest and session, which is the current
  generation (c0.json is empty, f-c1.json holds the identity of ap, as c1 in [From Appendix A.5](#from-appendix-a5) below), or a JSON
  object whose members name generations such as current and rotated, each such an array (f-c2.json, used
  by F13). in-c3.json, used by F71, is f-c1.json without its closing bracket and does not parse. F77 uses
  f-c1.json. Before checking whether an approval is consumed, the verifier validates every entry of every
  supplied generation. Each entry must be an object containing non-empty string approvalId and session members
  and an actionDigest in the digest form of Section 3.8. A malformed entry causes refusal under item 5 (CS1 to
  CS4). The received copies of -received (r1.json, used by F90) are a JSON array of approval records.

## Running

Before extracting the downloaded archive, verify its SHA-256 against the value in Appendix A.5 of the draft.
Once extracted, check the files and run the verifier.

    sha256sum -c MANIFEST.sha256
    python3 run_vectors.py

You can try it offline. If a vector does not behave as the draft says, please tell us.

The script uses the Python standard library and builds the verifier with a local Go toolchain without network
access. The recorded outputs were produced with Python 3.13.18 and Go 1.24.7 on Linux x86-64. The outputs of the
vectors added in the merge for -10 and after it, and of SA1 to SA16 signed anew, were recorded with Python 3.11.18
and Go 1.24.7 on Linux x86-64. Other toolchains
may produce different binary hashes or output. With --verifier PATH it uses an existing build instead. With
--proofbundle PATH it also runs the recorded commands of proofbundle 6.6.0 (https://proofbundle.dev), a separate
open-source verifier, and compares their exit codes.

It prints one line per vector and exits with 0 only if every vector
and every check meets its expected result. A passing vector must pass
with exit code 0. A failing vector must fail at its expected step.
A vector that the relying party refuses under Section 4 must pass
receipt verification and be refused. Where the entry of a vector
gives output_has, the output must contain that text, and where it
gives output_lacks, the output must not contain it; for E12 and E13
these are the lines that report a citation or an ALLOW as not
counted, so a verifier that leaves them out fails the run. I1 calls
the decision command with -case executed, which needs the outcome
receipt as well. For I1, success requires exit code 2, the expected
incomplete-invocation diagnostic, and the absence of any
receipt-verification PASS or FAIL result; run_vectors.py fails the
run where any line of the output holds the word PASS or FAIL. The count of outputs equal to the recorded
output is printed but does not change the exit code.

For each vector of the third check of Section 3.5, receipt
verification must pass first. With valid held inputs, the output
must show that the third check ran over the supplied held receipts,
with exit code 0 if it passes or 4 if it fails. With invalid held
input, the verifier must instead report invalid input and no result
for the third check, with exit code 2.

For S1 and S2, the vectors of the second check of Section 3.5,
receipt verification must pass first, and the last line of the
output must show that the second check ran over the supplied held
receipts, with exit code 0 if it passes or 5 if it fails.

The files in a4/ must have the sizes, SHA-256 values and one-byte
changes that A4-description.txt states.

It does not verify the COSE signatures of a4/;
A4-description.txt describes how to.

## Further vectors

Up to -09, Appendix A.5 of the draft gave the further vectors in tables. This section describes them. Section numbers are
those of the draft.

F91, F92 and F93 are V2-good with the member n and the numbers 9007199254740994, 9007199254740992 and
-9007199254740992 written after the member _type, and fail at step 4 of Section 3.2. Each is its own RFC 8785
serialization and fails only under the sentence of that step on numbers whose absolute value is greater than
9007199254740991 and that is written without the frac and exp parts of the grammar in Section 6 of RFC 8259, which
F81 also violates. F92 is 2^53, F91 is 2^53 plus 2, and F93 is the negative of F92. F94 is the same with the number
1e+21, which is written with exp and is its own RFC 8785 serialization, and passes. For step 8, F122 is V1-good
checked under a trust policy that binds the key of gate-1 to gate-1 and gate-2, with gate-2 as the expected
decisionMaker.id, and fails at step 8.

Three further vectors are each checked like their base vector. V2-num is V2-good with the member n and the number
1.5e-7 written after the member _type, which RFC 8785 writes in the same form, and passes. F89 is V1-good without
the approval record entry of inputSnapshot and with the evidenceRefs of V3-decision, which cite B. It fails at Case
1 of Section 3.3 because its inputSnapshot has no entry whose name is "approval record". F89 illustrates rejection
despite the presence of evaluation evidence, but does not establish that a verifier enforces the second half of the
rule of Section 2.6. F17 fails at the verdict check of Case 3 whatever its evidenceRefs hold and only illustrates
that rule. F90 is the envelope of F10, checked like F10 by a relying party that has honoured nothing and has
received ap, whose validUntil is earlier than T; that relying party refuses it under item 2 of Section 4.

F95 is V2-good with its payload written without its base64 padding and fails at step 2 of Section 3.2. F96 and F97
are the envelope of V2-good with one more member whose value is written NaN or Infinity, neither of which is a
number in the grammar of Section 6 of RFC 8259; both fail at step 1. The test package describes each vector and the
inputs it is checked with without naming its result, which only the file of expected results gives, so that an
implementation can be checked blind.

For the member relationships, V2-rel and V3-rel are V2-good and V3-good with one entry that holds every member of
Figure 1 and Figure 2 for it, and pass. F98 to F107 change that entry or the array in V2-good, one rule of Section
3.8 each, and fail at step 7 of Section 3.2; F108 to F114 do the same in V3-good and fail at step 3 of Section 3.4.

For the third check of Section 3.5, K1 to K3 check a receipt together with the receipts that an Auditor holds. The
entry of relationships of V2-rel has relation supersedes and names V1-good by targetReceiptDigest and
targetSubjectDigest. K1 is V2-rel with V1-good and V2-num held, and passes. K2 is V2-rel with
relationships[0].targetSubjectDigest set to an object whose digestAlgorithm is "jcs-sha256-v1" and whose digest is
the value of subject[0].digest.sha256 of V2-num, with the same receipts held, and K3 is V2-rel with V2-good and
V2-num held; both pass Section 3.2 and fail that check. V1-good and V2-rel decide different actions, and a DENY
changes no state (Section 2.2), so K1 to K3 show only how that check matches digests, not a sequence of states of
one action (Section 2.1). K4 and K5 check the outcome receipt V3-rel, whose entry of relationships names V1-good as
that of V2-rel does. K4 holds V1-good and passes; K5 holds V2-good, passes Section 3.4 and fails that check. Like K1
to K3, K4 and K5 show only how that check matches digests, not a sequence of states of one action.

Each receipt held is given with its expected signing key, and K1 to K29 show whether that check ran over the
receipts held. K1 and K4 hold V1-good, which has expired at their evaluation time T, and pass that check. In K6 the
predecessor V1-good and in K8 a receipt held that no entry names is held only with one byte of its signature
changed, and in K11 V1-good is supplied under the key of observer-1, so the input of each is invalid. K7 names F30,
which passes steps 1 to 6 of Section 3.2 and fails step 7, as its predecessor and passes that check. K9 is a
decision receipt and K10 an outcome receipt whose predecessor is the outcome receipt V3-good, and both pass, as K1
and K4 do with a decision receipt as predecessor. K12 to K14 check a chain of three, a receipt that names V2-rel,
which names V1-good. With V1-good held only with a changed signature the input is invalid (K12), with V1-good absent
that check fails (K13), and with V2-rel and V1-good held it passes (K14). K27 checks V2-good, which has no entry of
relationships, with V2-rel held, whose entry names V1-good, which is not held; it passes, because the lookup does
not follow the entries of a receipt held that no entry of the chain names.

K15 and K16 hold a predecessor whose predicate is not a JSON object. F120 is V2-good with predicate replaced by the
JSON string "decision" and F121 is V3-good with predicate replaced by the empty JSON array, each with the subject
digest taken over that value and signed again by the key that signed its base. As receipts in their own right, F120
fails at step 6 of Section 3.2 and F121 at step 2 of Section 3.4. K15 uses a variant of V2-rel whose entry of
relationships names F120, signed again by the key that signed V2-rel. K16 uses a variant of V3-rel whose entry names
F121, signed again by the key that signed V3-rel. Each holds F120 or F121 under the key that signed it. The input of
each is invalid because the predicate of a held receipt must be a JSON object.

K17 to K25 hold a receipt whose relationships does not have the form that Section 3.8 gives. In K17 to K19, the held
predecessor is a variant of V2-good with relationships added, signed again by the key that signed V2-good. Each uses
a variant of V2-rel whose entry names that predecessor, signed again by the key that signed V2-rel. In K20 to K22,
the held predecessor is a variant of V3-good with relationships added, signed again by the key that signed V3-good.
Each uses a variant of V3-rel whose entry names that predecessor, signed again by the key that signed V3-rel. That
relationships is an object instead of an array in K17 and K20, has an entry that is not an object in K18 and K21,
and has an entry with relation supersedes whose targetReceiptDigest is an object with the only member sha256 in K19
and K22. K23 to K25 check V2-rel with V1-good held and, named by no entry, the predecessor of K17, K18 or K19, and
K26 holds F120 in the same way. The held receipts of K17 to K25 pass steps 1 to 6 of Section 3.2, or steps 1 to 5 of
Section 3.2 and step 2 of Section 3.4, under the key that signed them, and F120 fails step 6 of Section 3.2. The
input of each of K17 to K26 is invalid, because the preliminary checks of Section 3.5 include the form of predicate
and of relationships of every supplied held receipt, whether or not an entry names it.

For the type integer of Section 3.8, V3-seq is V3-good with the member sequence whose runId is r1 and whose seq is
written 1, and passes. F115 writes seq as 1.0 and fails at step 1 of Section 3.4, because its payload is not its own
RFC 8785 serialization, which writes 1. F116 writes seq as 1e+21, which is its own serialization, and fails at step
3 of Section 3.4.

For the form of the entries of signatures in step 1 of Section 3.2, F117, F118 and F119 are the envelope of V1-good
with a second entry of signatures after its one entry, the number 42, the empty object and an object whose sig is
the number 5. The first entry still verifies in step 3, and each of the three fails at step 1. For step 3, F123 is
the envelope of V1-good with S of its signature replaced by S plus L, and fails at step 3. No vector separates the
equation with the cofactor from the one without.

Each of the following vectors separates one rule that the earlier vectors of this package do not separate. Each
changed payload is signed again by the key that signed its base, with the subject digest taken over the new
predicate.

F124 is V2-good with privacy.rawInputsIncluded written as the JSON string "false" instead of the boolean false and
fails at step 7 of Section 3.2. V2-ref is V2-good with proposedAction.parametersRef {"uri":
"https://git.example/acme/widgets/pull/7"} in place of proposedAction.parametersDigest, checked without action
bytes, and passes, because note (1) of Section 3.8 permits parametersRef alone. F125 is the envelope of V2-ref
checked with the action bytes a2 and fails at step 10 of Section 3.2, because this document takes no digest from
parametersRef. V3-late is V3-good with performedAt 2026-10-15T09:11:01Z, one second after its evaluation time T and
before validity.expiresAt of V3-decision, and passes, because step 7 of Section 3.4 does not compare performedAt
with T.

K28 is V2-rel with a second entry of relationships with relation supersedes, whose targetReceiptDigest names the
content root of V2-good, checked like K1 with V1-good and V2-num held. Its first entry is met and its second names
no receipt held, so it passes Section 3.2 and fails the third check, because each entry with relation supersedes is
checked on its own. K29 is V2-rel with relation corrects in place of supersedes in its one entry, which still names
V1-good, checked with V2-num held only. It passes the third check, because an entry with another relation is not
part of that check, although its target is not held.

For the second check of Section 3.5, S1 and S2 check V3-good, as the pair with V3-decision, with two receipts held
and -second. In S1 they are V3-decision with decision.verdict ESCALATE and V3-good with decisionRef naming the
content root of that receipt; S1 passes Section 3.4 and fails the second check, because an outcome receipt held with
status executed names a decision receipt held whose verdict is not ALLOW. In S2 they are V3-decision and V3-good
themselves, and S2 passes that check. The first check of Section 3.5 had no vector in -08; E1 to E19 in
first-check/ are its vectors for -10.

## Keys

All keys in this package are test keys of the draft, given in Appendix A.1 and in A4-description.txt. They are
published and are not for real receipts. Every key that signs in this package has a seed that is SHA-256 over a
public ASCII label as Appendix A.1 describes, gate-sa, approver-1 and approver-2 of approver-signature/ included, so
that every signature can be made again. The keys with a torsion component use the secret scalars of gate-1 and
observer-1; the identity point O and the keys that are not points sign nothing that a check accepts.


## Vectors added for -10

The package of -10 holds every vector of the package of -08 unchanged, with the same files and entries, and 330
further vectors in two groups, G01 to G16c and H001 to H313. They are in expected-10/ with their expected results
and recorded outputs and in inputs-10/ without results, one file per vector, read in the order of the file names.
Each entry of inputs-10/ says which vector it is derived from and how. run_vectors.py reads expected-10/ after
expected-08/. The original G/H addition comprised 330 vectors. expected-10/ now contains 346 vectors, including PK1
to PK5, H314 to H316, I1, N1, J1, J2 and CS1 to CS4. Together with the retained 171 vectors and the COSE,
first-check and approver-signature groups, run_vectors.py covers 615 vectors. Each changed payload is signed again by
the key that signed its base, with the subject digest taken over the new predicate.

G01 is the envelope of V1-good whose one signature has an S less than L and an R that is r times the base point plus
a point of order 8. It satisfies the group equation of Section 5.1.7 of RFC 8032 with the cofactor 8 and not the
equation without it, and fails at step 3 of Section 3.2. It is the vector that separates the two equations, which
the package of -08 did not have. G02a, G02c and G02f are V1-good with one more entry of signatures beside its valid
one: before it, an entry whose keyid is that of gate-1 and whose sig is a signature of observer-1 over the same PAE,
after it, an entry whose sig is the base64 of 64 zero bytes, and after it, an entry whose sig is not base64. All
three pass, because the keyid does not select a key and the sig of other entries is not verified. G03a is V2-good
with the number 2^53 nested five levels below traceContext, an open object, and G03b is V2-good with that number
inside decision.obligations. Both payloads are their own RFC 8785 serialization, and both fail at step 4.

G05a is V1-good with proposedAction.parametersRef in place of proposedAction.parametersDigest, checked with ap and
without action bytes, and fails at Case 1 of Section 3.3, because ap names a digest that the receipt no longer
carries. G05b is V3-good, signed again with decisionRef naming the content root of V3-decision with the same change,
and fails at step 4 of Section 3.4, because requestedActionDigest has no parametersDigest to equal. G06 is V2-good
whose actionOutcome has no status and fails at Case 2. G07 is V3-good without effectDigest, checked without effect
bytes, and fails at step 6 of Section 3.4. G10a and G10b are S1 with the verdict DENY and REFUSE in place of
ESCALATE, and fail the second check of Section 3.5 as S1 does.

G14a to G16c are checked by a relying party under Section 4 with V1-good and ap. In G14a the consumption state holds
an identity with the approvalId and session of ap and the digest of another action, and in G14b one with the
approvalId and action of ap and another session. Neither is the identity of ap, so both pass and are not refused.
G15a and G15b have received two copies of the identity of ap, one with validUntil 2026-10-15T09:00:30Z and ap2,
first in one order and then in the other. In both T is not earlier than the earliest validUntil, and both are
refused under item 2, whatever the order. In G16c one generation of the consumption state is an object, not an
array, and the relying party refuses under item 5, because it cannot consult a complete view.

H001 to H313 each separate one rule of the field rules of Section 3.8 that no earlier vector separates. A rule here
is the type of one row of Figure 1 or Figure 2, its column Required, the exclusion of null at that row, the exclusion
of null inside an open object, an array of any values or a value of type any value, the non-empty part of a type, the
type of the entries of an array, the exclusion of members that a figure does not list for an object, note (1), or
one part of the definitions of digest, timestamp, typedDigest, relationDigest, array of 1 to 64 objects and integer.
A decision receipt vector is V1-good with one change, checked like V1-good, and fails at step 7 of Section 3.2; an
outcome receipt vector is V3-good with one change, checked like V3-good, and fails at step 3 of Section 3.4. Where the
row lies below a member that V1-good or V3-good does not have, that member is first made present with valid values,
and the receipt with those values and without the one change passes. The entry of each vector in inputs-10/ names
the change and the rule it separates.

## Vectors of the merged parts of -10

These vectors come with the parts that -10 adds to the text: the requirements independent of the encoding and the
COSE_Sign1 binding (Section 3.9, Section 3.10 and Appendix B), the first check of Section 3.5, the approver signature
(Section 3.11) and the rule on the expected key of step 3. run_vectors.py runs them after expected-10/, from
cose/expected-cose.json, first-check/expected-first.json and approver-signature/expected-sa.json in that order.

cose/ holds 56 vectors. C1-good, C2-good and C3-good are V1-good, V2-good and V3-good with their predicates in the
COSE_Sign1 binding, signed by gate-1 and observer-1, and pass; C3-mixed is C3-good with the decision in the DSSE
binding and passes. For each case one vector fails at each of steps 1, 2, 3 and 6 of Appendix B.3, five fail at steps
1 and 2 of Section 3.4 for the outcome receipt of C3-good, and 18 further vectors change C2-good in one way each.
X-dsse-as-cose and X-cose-as-dsse check a receipt in the binding it is not in and fail at step 1. C2-depth32 holds in
its unprotected header the label 99 with 29 nested arrays around null, which puts null at depth 32, and passes;
C2-s1-depth33 has 30 such arrays and fails at step 1, because step 1 admits no depth greater than 32. CPK1 to CPK4
belong to the rule on the expected key and are described below; the six vectors added after the merge are
described in the next section. The description of each vector is in
cose/expected-cose.json and cose/inputs-cose.json; cose/keys.json gives the public keys and kid values of gate-1 and
observer-1.

first-check/ holds E1 to E21, approver-signature/ holds SA1 to SA21; the README.md of each folder describes how
they are built, and the section Results of first-check/ and approver-signature/ gives their results with reasons.

The rule on the expected key says that the key under which step 3 verifies a receipt decodes, is not the identity
point, and multiplied by L gives the identity point, for decision and outcome receipts in every binding. Without it a
verifier accepts, under the key O, 01 followed by 31 zero bytes, the signature R = O, S = 0 for every message, and
under a key a*B + T with T of order 8 every signature whose hash k is a multiple of 8. PK1 and PK2 are V1-good and
V3-good with their payloads under the key O and the signature (O, 0); PK3 and PK4 are the same payloads under the key
of gate-1 and of observer-1 plus a point of order 8, signed with a nonce for which k is a multiple of 8.
vectors/pk-policy-o.json and vectors/pk-policy-t.json bind those keys to the identifiers of V1-good and V3-good. PK1
and PK3 fail at step 3 of Section 3.2, PK2 and PK4 at step 1 of Section 3.4, which applies that step. CPK1 to CPK4 in
cose/ are the same four cases for C1-good and for the outcome receipt of C3-good in the COSE_Sign1 binding, with
policies cose/vectors/cpk1-policy.json to cpk4-policy.json, and fail at step 3 of Appendix B.3. Each of the eight
passes the group equation of Section 5.1.7 of RFC 8032 without the cofactor.

H314 is V1-good with recordedAt "2026-10-15T09:00:60Z" added to its predicate and fails at step 7 of Section 3.2,
because a timestamp of Section 3.8 has a second from 00 to 59. It is in expected-10/ with PK1 to PK4.

All vectors of -08 and of the section Vectors added for -10 keep their files, results and recorded outputs. The
original 330 G/H additions include recorded proofbundle commands. Of the 89 additions incorporated during the merge,
the five in expected-10/ have a proofbundle command recorded with 6.6.0; the others have no proofbundle command.

## Vectors added after the merge

These 15 vectors come with the external reading of the merged -10 and with the year rule of Section 3.8. The five in
expected-10/ have a proofbundle command recorded with 6.6.0; the others have no proofbundle command. Each changed
payload is signed again by the key that signed
its base, with the subject digest taken over the new predicate.

H315 and H316 are V1-good with recordedAt "0000-06-01T00:00:00Z" and "2026-10-15T09:00:00.1234567Z" added to its
predicate and fail at step 7 of Section 3.2, because a timestamp of Section 3.8 has a year from 0001 to 9999 and one
to six fraction digits. I1 is the decision receipt of V3-good given to the decision command with -case executed and
no outcome receipt; Case 3 needs both receipts, and the verifier gives no result for that invocation and ends with
exit code 2. N1 is V1-good with an approval record that has the further member "extra" with the integer literal
9007199254740992; the record is its own RFC 8785 serialization and P does not contain the number, so N1 passes,
because the bound of step 4 of Section 3.2 on integer literals applies to P only. PK5 is V1-good checked under an
expected key that is not the encoding of a point, which vectors/pk-policy-n.json binds to gate-1, and fails at step 3
of Section 3.2. These five are in expected-10/.

In cose/, six vectors change the unprotected header of C2-good, which the signature does not cover.
C2-s1-unprot-label has a label false and C2-s1-unprot-crit the label 2, crit; both fail at step 1 of Appendix B.3,
because every label of the unprotected header is an integer or a text string and crit stands only in the protected
header. C2-int64-max holds the integers 9223372036854775807 and -9223372036854775808 and passes; C2-s1-int64-pos and
C2-s1-int64-neg hold 9223372036854775808 and -9223372036854775809 and fail at step 1, as does C2-s1-dup-label, whose
map has the label "x" twice. E20 in first-check/ and SA19 to SA21 in approver-signature/ are described in the
README.md of those folders and in the section Results of first-check/ and approver-signature/.

## Vectors added after the second reading

These nine vectors come with the second external reading of -10. The six in expected-10/ have a proofbundle command
recorded with 6.6.0; the others have no proofbundle command. Each changed payload is signed again by gate-1, the
key that signed its base, with the
subject digest taken over the new predicate.

For JSON values parsed from receipt bytes, payload bytes or approval record bytes, the outermost value has depth
zero. Each object member value or array element increases depth by one. A value with depth greater than 64 fails
the step that parses it. The verifier applies this limit to every JSON value it reads. J1 and J2 are V1-good with
an approval record that has the further member "extra" with 63 and 64 arrays nested around the number 0, so that
the deepest value of the record has depth 64 and 65. J1 passes; J2 fails at Case 1 of Section 3.3, because the
record does not parse. E21 in first-check/ is the case that separates the limit in the first check of Section
3.5 and is described in the README.md of that folder and in the section Results of first-check/ and
approver-signature/.

CS1 to CS4 are V1-accept with a consumption state that holds a malformed entry: [null] (CS1), an entry without
session (CS2), an entry whose actionDigest has uppercase hexadecimal digits and so is not in the digest form of
Section 3.8 (CS3), and the generations current, with an entry in the form of Section 4, and rotated, with an
entry whose approvalId is the empty string (CS4). None of them holds the identity of ap, and each is refused
under item 5 of Section 4. These six are in expected-10/.

In cose/, C2-iss-8192 and C2-s1-iss-8193 are C2-good with an iss of 8192 and 8193 ASCII characters, the protected
header encoded anew and signed anew by gate-1. This binding limits iss to between 1 and 8192 Unicode code points,
inclusive, including when kid is used. The protected header of both holds kid and neither x5t nor x5chain, and
their unprotected header is empty. C2-iss-8192 passes, and C2-s1-iss-8193 fails at step 1 of Appendix B.3.

## Vector added after the third reading

This vector comes with the third external reading of -10 and, like the other vectors in cose/, has no proofbundle
command. In cose/, C2-iss-4097e is C2-good with an iss of 4097 times the character U+00E9, which is 4097 Unicode
code points and 8194 bytes in UTF-8, the protected header encoded anew and signed anew by gate-1. It passes,
because iss is counted as Unicode code points; a verifier that counts bytes refuses it at step 1 of Appendix B.3.

## Results of first-check/ and approver-signature/

The README.md files of first-check/, approver-signature/ and approver-signature/vectors/ say how these vectors are
built and name no result. The results are in first-check/expected-first.json and approver-signature/expected-sa.json;
this section gives them with the reasons that those README files gave up to the fourth external reading of -10.

E20: a line reports the citation of e-ap4 as not counted, and the first check fails. E21: the citation of
e21-ap-deep gives no identity and is reported as not counted, so only F10 cites the identity, and the first check
passes; a reader without the limit finds the identity twice, and the first check fails. The receipts dec-0005 to
dec-0008 that E1 to E21 hold each pass Section 3.2; dec-0008 fails Case 1 because it names two approval records,
which the first check does not ask of a held receipt. For E12, E13 and E20, run_vectors.py fails the run where the
line of output_has is missing.

SA17 and SA18 both fail at check 5; a verifier that applies only the group equation and the bound on S passes both.
SA19 fails at check 2, because sig must be in the base64 form of step 2 of Section 3.10. SA20 passes, because no
subgroup test is applied to R. SA21 fails at check 5.

SA1 to SA16, 3 passing and 13 failing:

| Vector | Expected | Reason |
|---|---|---|
| SA1 | pass | every check of Section 3.11.3 holds |
| SA2 | fail at approver signature, check 5 | the approver signed other action bytes; M of the presented record differs from the signed M |
| SA3 | fail at approver signature, check 5 | wrong signer; the signature does not verify under the approver key |
| SA4 | fail at approver signature, check 3 | wrong signer; the trust policy does not bind this key to approver user-123 |
| SA5 | fail at case 1 | expired; validUntil is before T, so the bounds of Case 1 fail before the approver signature is checked; the signature itself is valid |
| SA6 | fail at approver signature, check 5 | copy under another session; session is under the signature |
| SA7 | fail at approver signature, check 5 | validity extended after signing; validUntil is under the signature |
| SA8 | pass | a record without the signature stays valid under Case 1 and is not reported as signed |
| SA9 | fail at approver signature, check 2 | the relying party asked for the signature and the record has none |
| SA10 | pass | a verifier not asked for the signature passes Case 1 and does not report the record as signed |
| SA11 | fail at approver signature, check 4 | the approver key is the key that signed the decision receipt |
| SA12 | fail at approver signature, check 1 | the action bytes are required for the approver signature |
| SA13 | fail at approver signature, check 2 | approverSignature has a member other than sig |
| SA14 | fail at approver signature, check 5 | S is not less than L |
| SA15 | fail at approver signature, check 2 | sig is not in the base64 form of step 2 |
| SA16 | fail at approver signature, check 5 | the signature is not over M |

SA8 and SA10 also require that the output of the verifier of this package does not contain the words approver
signature, and SA1 that it contains the line approver signature: PASS, as that verifier writes them. This tests, on
that verifier's output, the rule of Section 3.11.3 that a verifier that has not run the checks of that section MUST
NOT report that the approver signed. The test is stricter than the draft, which also lets a verifier report that
the record carries approverSignature if it says that the signature was not checked; it is a property of the
verifier of this package, not a requirement on every verifier.

## Paragraphs that -10 gave in the draft

-10 gave the following paragraphs in Appendix A.5 and Appendix B.5 of the draft. -11 leaves them out of the text
and refers to this package. They follow as -10 gave them, with the section numbers of the draft, which -11 keeps.
Figure 4 of -10 gave each vector of the COSE_Sign1 binding with its expected result, its file and the SHA-256 of
the file; cose/expected-cose.json gives the name and expected result of each, its recorded command names the file,
and MANIFEST.sha256 gives the SHA-256 of the file.

### From Appendix A.5

The test package gives each further vector an entry in its expected files with its expected result and the files
its recorded command checks, and a corresponding entry in its inputs files without the expected result; its README
describes the vectors in prose, and its file MANIFEST.sha256 gives the path and the SHA-256 of each file. A
changed payload is signed again by the key that signed its base, with the subject digest taken over the new
predicate. For K1 to K29, S1 and S2 and E1 to E21, the receipt passes, and the expected result recorded in the
test package is that of the third, second or first check of Section 3.5 over the receipts held, each held under
the key that signed it unless its entry in the test package says otherwise; an invalid input gives no result for
that check. For E1 to E21 the Auditor also holds approval records and takes the consumption scope from its audit
context or its trust policy, in the form that the test package describes; where it can obtain or read none, the
first check gives no result. F10 is V1-good with decidedAt 2026-10-15T09:20:00Z, decisionId and validity.nonce
dec-0004, validity.expiresAt 2026-10-15T09:25:00Z and the approval record ap2, ap with validUntil
2026-10-15T09:30:00Z, in inputSnapshot[1]; c1 is the consumption state of a relying party that has honoured ap.
F90 is refused under item 2 of Section 4. For SA1 to SA21, the package specifies whether the approver-signature
check is requested and which inputs are supplied. SA8 and SA10 do not request it. SA12 requests it without action
bytes and fails check 1. The other vectors request it with action bytes and the specified approver key. SA1 to
SA16, SA19 and SA20 are signed with the test keys gate-sa, approver-1 and approver-2 of Appendix A.1. SA19 is SA1
with its signature written with pad bits that are not zero, the decoded bytes unchanged. SA20 is signed under
approver-1 with R the identity point and S = k a mod L, a the secret scalar of approver-1, and passes, because no
subgroup test is applied to R. SA21 is SA1 checked with an approver key that is not the encoding of a point. SA17
and SA18 are signed by gate-1 and have as approver key the identity point O, 01 followed by 31 zero bytes, and the
key of observer-1 plus a point of order 8. PK1 to PK4 are V1-good and V3-good under the key O with the signature R
= O, S = 0 and under the key of gate-1 or observer-1 plus a point of order 8, with a nonce for which the group
equation without the cofactor holds; each passes that equation and fails under the rule on the expected key of
step 3 of Section 3.2. PK5 is V1-good checked under an expected key that is not the encoding of a point. H315 and
H316 are V1-good with recordedAt in the year 0000 and with seven digits of a fraction of a second. N1 is V1-good
with an approval record that has a further member with the integer literal 9007199254740992; it passes, because
the bound of step 4 of Section 3.2 applies to P and not to A. I1 gives the decision receipt of V3-good to the
decision command of the verifier of the test package with case executed and without an outcome receipt. The
decision command accepts cases approval and declined. Case 3 is checked with the outcome command and requires both
receipts. A decision command requesting case executed is an incomplete invocation and gives no verification
result. For I1, success requires exit code 2, the expected incomplete-invocation diagnostic, and the absence of
any receipt-verification PASS or FAIL result. Without a case, the decision command checks Section 3.2 only and
checks no case. E20 is E15 without e-ap4 held: the held decision cites e-ap4, which is not held and is reported as
not counted, and then ap, which still counts, so the first check fails. E21 is E1 with V1-good held and ap held
replaced by a payload of V1-good signed anew and by ap with a further member whose deepest value has depth 66;
that citation gives no identity and is reported as not counted, so only F10 cites the identity and the first check
passes. J1 and J2 are V1-good with an approval record whose deepest value has depth 64 and 65; J1 passes, and J2
fails at Case 1. CS1 to CS4 are V1-accept with a consumption state that holds a malformed entry: the entry null,
an entry without session, an entry whose actionDigest is not in the digest form, and in a second generation an
entry whose approvalId is the empty string; each is refused under item 5 of Section 4. The vectors of field rules
of Section 3.8, H001 to H316, have such entries too; MANIFEST.sha256 of the test package gives the SHA-256 of each
file. The other vectors of the test package, F1 to F9, F11 to F88 and F17-outcome, are described only in the
package.

G01 separates the equation with the cofactor from the one without. F89 illustrates rejection despite the presence
of evaluation evidence, but does not establish that a verifier enforces the second half of the rule of Section 2.6.
F17 fails at the verdict check of Case 3 whatever its evidenceRefs hold and only illustrates that rule. V1-good and
V2-rel decide different actions, and a DENY changes no state (Section 2.2), so K1 to K5 show only how the third
check matches digests, not a sequence of states of one action (Section 2.1).

F10 passes receipt verification and is refused by the relying party under Section 4, with c1 under item 1, because
item 2 makes ap2, a copy of ap with other metadata, the same approval. The proofbundle 6.6.0 command receives ap2
and c1 and refuses F10 under Section 4 with exit code 3. The trust policy of Appendix A.1 names no consumption
scope, so Section 3.5 gives no result for F10 without an audit context that names one (E6); E1 holds V1-good and
F10 within one scope, and its first check reports them as a pair.

### From Appendix B.5

C1-good, C2-good and C3-good carry the predicates of V1-good, V2-good, and V3-decision with V3-good in this binding
and pass Cases 1, 2 and 3; in C3-good, decisionRef names the content root of the decision receipt in this binding.
C3-mixed carries the predicate of V3-good unchanged in this binding and passes Case 3 with the DSSE receipt
V3-decision. For each case, one vector fails at each of steps 1, 2, 3 and 6 of Section 3.2, for Case 3 in the
decision receipt, and five vectors fail at steps 1 and 2 of Section 3.4 in the outcome receipt. Eighteen vectors
derived from C2-good fail at step 1 (a byte after the message, labels out of order, alg -7, a further label, no
kid, no iss, a label repeated in the unprotected header, another content type, and in the unprotected header an
indefinite length, a floating-point value, a tag and the simple value undefined), at step 3 (another key, S plus
L), at step 4 (a payload that is not its own serialization) and at step 6 (a third member, another sub, a predicate
that is not an object). Two vectors check a receipt in the other binding and fail at step 1. C2-depth32 has in its
unprotected header the label 99 with 29 nested arrays around null, which puts null at depth 32, and passes;
C2-s1-depth33 has 30 such arrays and fails at step 1. C2-s1-unprot-label and C2-s1-unprot-crit have in the
unprotected header the label false and the label 2, crit, and fail at step 1. C2-int64-max holds there the integers
9223372036854775807 and -9223372036854775808 and passes; C2-s1-int64-pos and C2-s1-int64-neg hold
9223372036854775808 and -9223372036854775809 and fail at step 1, as does C2-s1-dup-label, whose map has one label
twice. C2-iss-8192 and C2-s1-iss-8193 are C2-good with an iss of 8192 and 8193 ASCII characters, signed anew by
gate-1; the first passes and the second fails at step 1. Their protected header holds kid and neither x5t nor
x5chain. C2-iss-4097e is C2-good with an iss of 4097 times the character U+00E9, which is 4097 Unicode code points
and 8194 bytes in UTF-8, signed anew by gate-1, and passes, because iss is counted as Unicode code points. CPK1 to
CPK4 are C1-good and the outcome receipt of C3-good under the expected key O with R = O, S = 0 and under the key of
gate-1 or observer-1 plus a point of order 8; they fail at step 3, the outcome receipts at step 1 of Section 3.4.
Figure 4 gives each vector with its expected result, its file and the SHA-256 of the file.

## What the vectors do not show

No vector other than H314 holds a timestamp whose second is 60. PK5 and SA21 hold a key that is not the encoding
of a point; such a key also fails the other parts of the rule on the key, so they do not separate the decoding from
those parts. No vector holds a key in an encoding that is not canonical. No vector separates the rule that an integer is not
greater than 9007199254740991, which step 4 of Section 3.2 checks first. Only J1, J2 and E21 hold a
JSON value of depth greater than 32; no vector holds an envelope, a payload, a consumption state or another input
deeper than 64. Only C2-iss-4097e holds an iss with characters outside ASCII. No vector holds an iss of more than
8192 code points outside ASCII: a count in bytes refuses it as well, so it would separate no reading that
C2-s1-iss-8193 does not. No vector shows a consumption state that has
lost an entry still required by item 6 of Section 4, because the inputs of the verifier do not show which entries are
still required.

Assisted by little helpers.
