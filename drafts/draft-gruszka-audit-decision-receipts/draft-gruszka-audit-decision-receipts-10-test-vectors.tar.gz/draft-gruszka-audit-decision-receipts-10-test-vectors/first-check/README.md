# Vectors of the first check of Section 3.5

This folder holds E1 to E21, the vectors of the first check of Section 3.5 of draft-gruszka-audit-decision-receipts.
Every path in expected-first.json and inputs-first.json is relative to the root of the package. The verifier of the
package runs the check with -first (firstcheck.go); every run without -first prints what it printed before.
run_vectors.py in the root runs these vectors with all others.

## Inputs of the first check

- -first, with -held, runs the first check after the preliminary checks and the third check, and after the second
  check where -second is given. The receipts held are those of -held, KEY:FILE, as for the second and third check.
- -held-approval FILE, repeatable, gives approval record bytes that the Auditor holds. A held ALLOW cites an approval
  record by the digest of an inputSnapshot entry named "approval record"; the record held whose SHA-256 is that
  digest gives the identity (approvalId, actionDigest, session).
- -audit-context FILE is a JSON object. Its member consumptionScope, where present, is the consumption scope. Its
  member unreleased, where present, is an array of content roots of held ALLOW decisions that the Auditor can show
  never left the control of the relying party.
- The trust policy of -policy may have a member consumptionScope as well. It is used only where the audit context
  names none.
- A consumption scope is {"id": a non-empty string, "decisions": an array of content roots, each 64 lowercase
  hexadecimal digits}. The draft does not define this form; it is the form of this verifier.

## Results

- Exit code 6 and a last line "AUDITOR, Section 3.5, first check over the receipts held (N), separate from the
  receipt: FAIL" where two distinct released ALLOW payloads in the scope cite approval records with the same
  identity, unless the third check (4) or the second check (5) has failed before.
- Exit code 0 and the same line with PASS otherwise. A line "AUDITOR, Section 3.5, first check, not counted" comes
  before it for each ALLOW shown as unreleased and for each cited approval record that is not held or gives no
  identity.
- Exit code 2 and a last line "AUDITOR, Section 3.5, first check: NO RESULT" where no scope is named, where the scope
  or the audit context cannot be read, or where an approval record file cannot be read. A scope named by the audit
  context that cannot be read is not replaced by the scope of the trust policy.

## Identity

The identity of a cited approval is the triple (approvalId, actionDigest.sha256, session), compared field by field.
The verifier keys it by the JSON array of the three strings, so that no two different triples share a key. E19 holds
two approval records whose triples differ but whose three values joined with NUL separators would be equal.

A held ALLOW that cites more than one approval record is counted for each of them, and a citation that gives no
identity does not stop the others. E20 is E15 without e-ap4 held: dec-0008 cites e-ap4, which is not held, and then
ap, which is held and has the identity that V1-good cites. For E12, E13 and E20 the entry in expected-first.json
gives output_has, the line that reports what is not counted.

For identity extraction in the first check, a citation of approval record bytes that hold a JSON value with depth
greater than 64 gives no identity and is reported as not counted. E21 is E1 with V1-good held replaced by
vectors/e21-v1-deep.dsse.json, the payload of V1-good citing vectors/e21-ap-deep.json and signed anew by gate-1,
and ap held replaced by e21-ap-deep.json, which is ap with the further member "extra" of 65 arrays nested around
the number 0, so that its deepest value has depth 66. e21-ap-deep.json has the identity of ap and ap2. The scope
rp-1 of vectors/e21-ac.json names the content roots of e21-v1-deep and F10. The entry in expected-first.json gives
output_has with the line that reports the citation of e21-ap-deep.

## Files

- vectors/e-ap3.json is ap with actionDigest SHA-256(a2); vectors/e-ap4.json is ap with session sess-2.
- vectors/e-d-other-action.dsse.json (dec-0005) is V1-good citing e-ap3 for the action a2,
  vectors/e-d-other-session.dsse.json (dec-0006) is V1-good citing e-ap4, vectors/e-d-deny.dsse.json (dec-0007) is
  V1-good with verdict DENY and reason code user_refusal, and vectors/e-d-two-records.dsse.json (dec-0008) names two
  approval records, e-ap4 and then ap. Each has decisionId and validity.nonce as named and is signed by gate-1.
- vectors/e-apx.json and vectors/e-apy.json are the two approval records of E19. With D the string of 64 zeros, e-apx
  has approvalId "a", actionDigest D and session "b" NUL D NUL "c", and e-apy has approvalId "a" NUL D NUL "b",
  actionDigest D and session "c". vectors/e-d-apx.dsse.json (dec-0009) and vectors/e-d-apy.dsse.json (dec-0010) are
  V1-good citing them, signed by gate-1, and vectors/e-ac-xy.json is the audit context whose scope names V1-good,
  dec-0009 and dec-0010.
- vectors/e-v1-copy.dsse.json is the envelope of V1-good without white space and vectors/e-v1-two-sigs.dsse.json the
  payload of V1-good signed by gate-1 and observer-1. Both have the content root of V1-good. E2 holds them with
  V1-good, each under the key of gate-1.
- vectors/e-ac-*.json are audit contexts and vectors/e-policy-scope-both.json is the trust policy of Appendix A.1
  with a consumptionScope that names V1-good and F10. vectors/e-ac-unparseable.json does not parse, as intended.
- expected-first.json gives for each vector its description, arguments, exit code, the start of its last line and
  the recorded output; inputs-first.json gives the same calls without results. This README names no result; the
  README.md at the root of the package gives the results of E20 and E21 with their reasons.

## Keys

All keys are the test keys of Appendix A.1. They are published and are not for real receipts.
