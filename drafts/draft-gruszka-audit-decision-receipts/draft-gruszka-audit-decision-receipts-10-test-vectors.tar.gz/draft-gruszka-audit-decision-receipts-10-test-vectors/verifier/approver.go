package main

// The check of the approver signature of Section 3.11, the approver signature profile, written from version 4 of
// that profile text only. It runs with -approver-pub, after the checks of Case 1 have passed and before any check of
// Section 4 (Section 3.11.3). Without -approver-pub the verifier does not look at approverSignature and prints what
// it printed before.

import (
	"bytes"
	"crypto/ed25519"
	"fmt"
	"math/big"
)

// signatureContext is the string c of Section 3.11.1.
const signatureContext = "approval-record-signature-v1"

// orderL is the order L of Section 5.1 of RFC 8032.
var orderL, _ = new(big.Int).SetString("7237005577332262213973186563042994240857116359379907606001950938285454250989", 10)

// approverArgs are the inputs of Section 3.11.2: the approver key that the trust policy selects, in base64 and as
// bytes. An empty pubB64 means that the verifier is not asked to check the approver signature.
type approverArgs struct {
	pub    ed25519.PublicKey
	pubB64 string
}

// approverSignature runs checks 1 to 5 of Section 3.11.3 on the approval record ao, which has passed Case 1. Each failure
// is named "approver signature, check n".
func approverSignature(ao map[string]any, actionSupplied bool, ap approverArgs, pol policy,
	decisionPub ed25519.PublicKey) error {
	// Check 1: action bytes. They MUST be supplied; step 10 and Case 1 have then bound them.
	if !actionSupplied {
		return failf("approver signature, check 1", "the action bytes must be supplied")
	}
	// Check 2: presence and form. approverSignature MUST be present, a JSON object whose only member is sig, and sig a
	// string in the base64 form of step 2 of Section 3.2.
	v, present := ao["approverSignature"]
	if !present {
		return failf("approver signature, check 2", "the approval record has no approverSignature")
	}
	so, ok := obj(v)
	if !ok {
		return failf("approver signature, check 2", "approverSignature is not a JSON object")
	}
	if len(so) != 1 {
		return failf("approver signature, check 2", "approverSignature has members other than sig")
	}
	sigText, ok := str(so["sig"])
	if !ok {
		return failf("approver signature, check 2", "approverSignature has no member sig whose value is a string")
	}
	sig, err := strictB64(sigText)
	if err != nil {
		return failf("approver signature, check 2", "sig is not in the base64 form of step 2 of Section 3.2: %v", err)
	}
	// Check 3: key binding. The trust policy MUST bind the approver key to the value of approver in A.
	approver := getStr(ao, "approver")
	if !permits(pol.Approver, ap.pubB64, approver) {
		return failf("approver signature, check 3", "the trust policy does not bind the approver key to %q", approver)
	}
	// Check 4: separation. The approver key MUST differ from the key under which step 3 verified the decision receipt.
	if bytes.Equal(ap.pub, decisionPub) {
		return failf("approver signature, check 4", "the approver key is the key of the decision receipt")
	}
	// Check 5: signature. U is A without approverSignature, B its RFC 8785 serialization, M the PAE with c and B.
	u := map[string]any{}
	for k, x := range ao {
		if k != "approverSignature" {
			u[k] = x
		}
	}
	b, err := jcs(u)
	if err != nil {
		return failf("approver signature, check 5", "the members of the approval record have no RFC 8785 form: %v", err)
	}
	m := []byte(fmt.Sprintf("DSSEv1 %d %s %d ", len(signatureContext), signatureContext, len(b)))
	m = append(m, b...)
	if len(sig) != ed25519.SignatureSize {
		return failf("approver signature, check 5", "sig is %d bytes long, not 64", len(sig))
	}
	s := make([]byte, 32)
	for i := 0; i < 32; i++ { // S is read as a little-endian integer
		s[i] = sig[63-i]
	}
	if new(big.Int).SetBytes(s).Cmp(orderL) >= 0 {
		return failf("approver signature, check 5", "S of sig is not less than L")
	}
	// The approver key decodes, is not the identity point and multiplied by L gives the identity point. No subgroup
	// test is applied to R.
	if err := checkPublicKey(ap.pub, "the approver key"); err != nil {
		return failf("approver signature, check 5", "%v", err)
	}
	// crypto/ed25519 checks the group equation without the cofactor 8.
	if !ed25519.Verify(ap.pub, m, sig) {
		return failf("approver signature, check 5", "sig does not verify over M under the approver key")
	}
	return nil
}
