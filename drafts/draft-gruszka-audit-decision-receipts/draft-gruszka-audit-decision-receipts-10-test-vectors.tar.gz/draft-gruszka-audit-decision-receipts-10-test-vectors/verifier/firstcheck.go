package main

// The first check of Section 3.5 (order CLOUD-DRAFT-AUDIT-10-EINMALIG-01). Within the consumption scope of the
// relying party, no two distinct released ALLOW decision payloads, identified by different content roots, may cite
// approval records with the same identity (approvalId, actionDigest and session).
//
// It runs only with -first and needs -held. Its inputs are those of an Auditor:
//
//	-held KEY:FILE        the receipts held, with the same preliminary checks as the second and third check
//	-held-approval FILE   approval record bytes the Auditor holds; repeatable
//	-audit-context FILE   a JSON object; its member consumptionScope, where present, is the scope, and its member
//	                      unreleased, where present, lists the content roots of held ALLOW decisions that the Auditor
//	                      can show never left the control of the relying party
//	-policy FILE          the trust policy; its member consumptionScope is the scope where the audit context names
//	                      none
//
// A consumption scope is a JSON object {"id": non-empty string, "decisions": [content roots]}, the content roots as
// 64 lowercase hexadecimal digits. The draft does not define this form; it is the form of this verifier.
// Without a scope, or with a scope or an audit context that cannot be read, the first check gives no result and the
// exit code is 2; a scope named by the audit context that cannot be read is not replaced by the scope of the trust
// policy. A held ALLOW counts only where its content root is in the scope and not listed as unreleased. Copies and
// further signatures of one payload have one content root and count once. The identity of a cited approval is read
// from the held approval record bytes whose SHA-256 is the digest of an inputSnapshot entry named "approval record";
// approvalId and session are compared as strings and actionDigest by its sha256 value. A cited approval record that is
// not held, or that has no approvalId, session and actionDigest in the form of Case 1, gives no identity; it is not
// counted, and a line says so. The receipt being verified counts only where it is also held. Where the check fails,
// the exit code is 6, unless the third check (4) or the second check (5) has already failed. The last line is that of
// the first check. Go standard library only.

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"
)

type firstArgs struct {
	approvals    []string
	auditContext string
	policyFile   string
}

type scopeSpec struct {
	id        string
	decisions map[string]bool
	from      string
}

func readScope(v any) (*scopeSpec, error) {
	o, ok := obj(v)
	if !ok {
		return nil, fmt.Errorf("it is not a JSON object")
	}
	id, ok := str(o["id"])
	if !ok || id == "" {
		return nil, fmt.Errorf("its id is not a non-empty string")
	}
	arr, ok := o["decisions"].([]any)
	if !ok {
		return nil, fmt.Errorf("its decisions is not an array")
	}
	m := map[string]bool{}
	for i, x := range arr {
		s, ok := str(x)
		if !ok || !hex64.MatchString(s) {
			return nil, fmt.Errorf("decisions[%d] is not a content root of 64 lowercase hexadecimal digits", i)
		}
		m[s] = true
	}
	return &scopeSpec{id: id, decisions: m}, nil
}

func readObjectFile(path, what string) (map[string]any, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("the %s cannot be read: %v", what, err)
	}
	v, err := parseJSON(b)
	if err != nil {
		return nil, fmt.Errorf("the %s does not parse: %v", what, err)
	}
	o, ok := obj(v)
	if !ok {
		return nil, fmt.Errorf("the %s is not a JSON object", what)
	}
	return o, nil
}

// obtainScope takes the scope from the audit context, or where that names none, from the trust policy.
func obtainScope(fa firstArgs) (*scopeSpec, map[string]bool, error) {
	unreleased := map[string]bool{}
	if fa.auditContext != "" {
		o, err := readObjectFile(fa.auditContext, "audit context")
		if err != nil {
			return nil, nil, err
		}
		if u, present := o["unreleased"]; present {
			arr, ok := u.([]any)
			if !ok {
				return nil, nil, fmt.Errorf("unreleased in the audit context is not an array")
			}
			for i, x := range arr {
				s, ok := str(x)
				if !ok || !hex64.MatchString(s) {
					return nil, nil, fmt.Errorf("unreleased[%d] in the audit context is not a content root", i)
				}
				unreleased[s] = true
			}
		}
		if sv, present := o["consumptionScope"]; present {
			sc, err := readScope(sv)
			if err != nil {
				return nil, nil, fmt.Errorf("the consumption scope that the audit context names cannot be read (%v); "+
					"no scope is taken from the trust policy instead", err)
			}
			sc.from = "the audit context"
			return sc, unreleased, nil
		}
	}
	o, err := readObjectFile(fa.policyFile, "trust policy")
	if err != nil {
		return nil, nil, err
	}
	if sv, present := o["consumptionScope"]; present {
		sc, err := readScope(sv)
		if err != nil {
			return nil, nil, fmt.Errorf("the consumption scope that the trust policy names cannot be read (%v)", err)
		}
		sc.from = "the trust policy"
		return sc, unreleased, nil
	}
	return nil, nil, fmt.Errorf("neither the audit context nor the trust policy names a consumption scope")
}

type approvalHeld struct {
	file, digest string
	b            []byte
}

func loadApprovals(files []string) ([]approvalHeld, error) {
	var out []approvalHeld
	for _, f := range files {
		b, err := os.ReadFile(f)
		if err != nil {
			return nil, fmt.Errorf("the approval record %s cannot be read: %v", f, err)
		}
		s := sha256.Sum256(b)
		out = append(out, approvalHeld{file: f, digest: hex.EncodeToString(s[:]), b: b})
	}
	return out, nil
}

// identityOf reads (approvalId, actionDigest, session) from approval record bytes, or says why it cannot.
func identityOf(b []byte) (key, show, why string) {
	v, err := parseJSON(b)
	if err != nil {
		return "", "", fmt.Sprintf("its bytes do not parse (%v)", err)
	}
	o, ok := obj(v)
	if !ok {
		return "", "", "it is not a JSON object"
	}
	if !nonEmptyString(o["approvalId"]) || !nonEmptyString(o["session"]) {
		return "", "", "its approvalId or session is not a non-empty string"
	}
	ad, ok := digestOf(o["actionDigest"])
	if !ok {
		return "", "", "its actionDigest does not have the digest form"
	}
	id, _ := str(o["approvalId"])
	se, _ := str(o["session"])
	keyBytes, _ := json.Marshal([3]string{id, ad, se})
	return string(keyBytes), fmt.Sprintf("(%s, %s, %s)", id, ad, se), ""
}

// firstCheck returns the number of released ALLOW payloads counted, the number of approval identities they cite, the
// lines for what is not counted, and the first pair that breaks the check.
func firstCheck(hs []held, sc *scopeSpec, unreleased map[string]bool, aps []approvalHeld) (int, int, []string, error) {
	byID := map[string]map[string]bool{}
	show := map[string]string{}
	seen := map[string]bool{}
	var notes []string
	counted := 0
	for _, h := range hs {
		if h.outcome || getStr(h.pred, "decision", "verdict") != "ALLOW" || !sc.decisions[h.R] || seen[h.R] {
			continue
		}
		seen[h.R] = true
		if unreleased[h.R] {
			notes = append(notes, fmt.Sprintf("the ALLOW with content root %s, which the audit context shows was "+
				"never released", h.R))
			continue
		}
		counted++
		entries, _ := h.pred["inputSnapshot"].([]any)
		for i, e := range entries {
			eo, _ := obj(e)
			if n, _ := str(eo["name"]); n != "approval record" {
				continue
			}
			d, ok := digestOf(eo["digest"])
			if !ok {
				notes = append(notes, fmt.Sprintf("inputSnapshot[%d] of the ALLOW with content root %s, whose digest "+
					"does not have the digest form", i, h.R))
				continue
			}
			var ap *approvalHeld
			for k := range aps {
				if aps[k].digest == d {
					ap = &aps[k]
					break
				}
			}
			if ap == nil {
				notes = append(notes, fmt.Sprintf("the approval record with SHA-256 %s that the ALLOW with content "+
					"root %s cites, which is not held", d, h.R))
				continue
			}
			key, sh, why := identityOf(ap.b)
			if key == "" {
				notes = append(notes, fmt.Sprintf("the approval record %s that the ALLOW with content root %s cites: "+
					"%s", ap.file, h.R, why))
				continue
			}
			if byID[key] == nil {
				byID[key] = map[string]bool{}
			}
			byID[key][h.R] = true
			show[key] = sh
		}
	}
	keys := make([]string, 0, len(byID))
	for k := range byID {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		if len(byID[k]) < 2 {
			continue
		}
		rs := make([]string, 0, len(byID[k]))
		for r := range byID[k] {
			rs = append(rs, r)
		}
		sort.Strings(rs)
		return counted, len(keys), notes, fmt.Errorf("the released ALLOW decision payloads with content roots %s in "+
			"scope %q cite approval records with the same identity %s", strings.Join(rs, " and "), sc.id, show[k])
	}
	return counted, len(keys), notes, nil
}

// auditorFirst runs, for -first, the third check, the second check where -second is given, and then the first check
// of Section 3.5 over the receipts held, after the same preliminary checks, and exits. The lines of the third and
// second check are those of auditorThird and auditorSets.
func auditorFirst(rc *receipt, args []string, second bool, fa firstArgs) {
	const pre = "AUDITOR, Section 3.5"
	which := "first and third check"
	if second {
		which = "first, second and third check"
	}
	hs, err := loadHeld(args)
	if err != nil {
		fmt.Printf("%s, %s: NO RESULT, the input is invalid: %v\n", pre, which, err)
		os.Exit(2)
	}
	code := 0
	at3 := fmt.Sprintf("%s, third check over the receipts held (%d), separate from the receipt:", pre, len(hs))
	var lines []string
	if err := supersedes(rc.Pred, "", hs, map[string]bool{rc.R: true}, &lines); err != nil {
		fmt.Println(at3, "FAIL", err)
		code = 4
	} else {
		for _, l := range lines {
			fmt.Println(at3, l)
		}
		if len(lines) == 0 {
			fmt.Println(at3, "PASS, no entry of relationships with relation supersedes")
		} else {
			fmt.Println(at3, "PASS")
		}
	}
	if second {
		at2 := fmt.Sprintf("%s, second check over the receipts held (%d), separate from the receipt:", pre, len(hs))
		n, err := secondCheck(hs)
		if err != nil {
			fmt.Println(at2, "FAIL", err)
			if code == 0 {
				code = 5
			}
		} else {
			fmt.Printf("%s PASS, %d outcome receipt(s) held with status executed, none names a decision receipt "+
				"held whose verdict is not ALLOW\n", at2, n)
		}
	}
	sc, unreleased, err := obtainScope(fa)
	if err == nil {
		var aps []approvalHeld
		aps, err = loadApprovals(fa.approvals)
		if err == nil {
			at1 := fmt.Sprintf("%s, first check over the receipts held (%d), separate from the receipt:", pre, len(hs))
			n, ids, notes, ferr := firstCheck(hs, sc, unreleased, aps)
			for _, l := range notes {
				fmt.Printf("%s, first check, not counted: %s\n", pre, l)
			}
			if ferr != nil {
				fmt.Println(at1, "FAIL", ferr)
				if code == 0 {
					code = 6
				}
			} else {
				fmt.Printf("%s PASS, scope %q from %s, %d released ALLOW decision payload(s) counted, %d approval "+
					"identity(ies) cited, none by two of them\n", at1, sc.id, sc.from, n, ids)
			}
			os.Exit(code)
		}
	}
	fmt.Printf("%s, first check: NO RESULT, %v\n", pre, err)
	if code == 0 {
		code = 2
	}
	os.Exit(code)
}
