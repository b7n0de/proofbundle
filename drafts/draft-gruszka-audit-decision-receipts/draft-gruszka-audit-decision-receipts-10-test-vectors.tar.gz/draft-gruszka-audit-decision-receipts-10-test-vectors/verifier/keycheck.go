package main

// The rule on the expected public key of step 3 of the signature checks: the key decodes as specified in Section
// 5.1.3 of RFC 8032, is not the identity point, and multiplying it by L gives the identity point. It applies to the
// expected key of a decision receipt and of an outcome receipt in every binding, and to the approver key of check 5
// of the approver signature. crypto/ed25519 does not apply it: under the key 01 followed by 31 zero bytes it accepts
// R equal to that point and S = 0 for every message, and it accepts a key with a torsion component wherever the
// hash k is a multiple of the order of that component. The arithmetic below uses math/big; it is slow but runs only
// once per key.

import (
	"errors"
	"math/big"
)

var (
	edP    = new(big.Int).Sub(new(big.Int).Lsh(big.NewInt(1), 255), big.NewInt(19))
	edD    = edDConst()
	edSqm1 = new(big.Int).Exp(big.NewInt(2), new(big.Int).Rsh(new(big.Int).Sub(edP, big.NewInt(1)), 2), edP)
)

func edDConst() *big.Int {
	// d = -121665 / 121666 mod p
	p := new(big.Int).Sub(new(big.Int).Lsh(big.NewInt(1), 255), big.NewInt(19))
	inv := new(big.Int).ModInverse(big.NewInt(121666), p)
	d := new(big.Int).Mul(big.NewInt(-121665), inv)
	return d.Mod(d, p)
}

// edPoint is a point in extended coordinates (X:Y:Z:T) with x = X/Z, y = Y/Z, xy = T/Z.
type edPoint struct{ X, Y, Z, T *big.Int }

func edIdentity() edPoint {
	return edPoint{big.NewInt(0), big.NewInt(1), big.NewInt(1), big.NewInt(0)}
}

func edMod(x *big.Int) *big.Int { return x.Mod(x, edP) }

// edAdd adds two points with the formulas of Section 5.1.4 of RFC 8032.
func edAdd(a, b edPoint) edPoint {
	m := func(x, y *big.Int) *big.Int { return edMod(new(big.Int).Mul(x, y)) }
	A := m(edMod(new(big.Int).Sub(a.Y, a.X)), edMod(new(big.Int).Sub(b.Y, b.X)))
	B := m(edMod(new(big.Int).Add(a.Y, a.X)), edMod(new(big.Int).Add(b.Y, b.X)))
	C := m(m(m(big.NewInt(2), a.T), b.T), edD)
	D := m(m(big.NewInt(2), a.Z), b.Z)
	E := edMod(new(big.Int).Sub(B, A))
	F := edMod(new(big.Int).Sub(D, C))
	G := edMod(new(big.Int).Add(D, C))
	H := edMod(new(big.Int).Add(B, A))
	return edPoint{m(E, F), m(G, H), m(F, G), m(E, H)}
}

func edMul(s *big.Int, p edPoint) edPoint {
	q := edIdentity()
	for i := s.BitLen() - 1; i >= 0; i-- {
		q = edAdd(q, q)
		if s.Bit(i) == 1 {
			q = edAdd(q, p)
		}
	}
	return q
}

func edIsIdentity(p edPoint) bool {
	// x = 0 and y = 1, that is X = 0 and Y = Z
	return edMod(new(big.Int).Set(p.X)).Sign() == 0 && edMod(new(big.Int).Sub(p.Y, p.Z)).Sign() == 0
}

// edDecode decodes 32 bytes as specified in Section 5.1.3 of RFC 8032, rejecting y >= p and x = 0 with sign bit 1.
func edDecode(b []byte) (edPoint, error) {
	if len(b) != 32 {
		return edPoint{}, errors.New("it is not 32 bytes long")
	}
	le := make([]byte, 32)
	for i := 0; i < 32; i++ {
		le[i] = b[31-i]
	}
	sign := le[0] >> 7
	le[0] &= 0x7f
	y := new(big.Int).SetBytes(le)
	if y.Cmp(edP) >= 0 {
		return edPoint{}, errors.New("its y coordinate is not less than p")
	}
	y2 := edMod(new(big.Int).Mul(y, y))
	u := edMod(new(big.Int).Sub(y2, big.NewInt(1)))
	v := edMod(new(big.Int).Add(new(big.Int).Mul(edD, y2), big.NewInt(1)))
	// x = u v^3 (u v^7)^((p-5)/8)
	v3 := edMod(new(big.Int).Mul(new(big.Int).Mul(v, v), v))
	v7 := edMod(new(big.Int).Mul(new(big.Int).Mul(v3, v3), v))
	e := new(big.Int).Rsh(new(big.Int).Sub(edP, big.NewInt(5)), 3)
	x := edMod(new(big.Int).Mul(new(big.Int).Mul(u, v3), new(big.Int).Exp(edMod(new(big.Int).Mul(u, v7)), e, edP)))
	vx2 := edMod(new(big.Int).Mul(v, new(big.Int).Mul(x, x)))
	switch {
	case vx2.Cmp(u) == 0:
	case vx2.Cmp(edMod(new(big.Int).Neg(u))) == 0:
		x = edMod(new(big.Int).Mul(x, edSqm1))
	default:
		return edPoint{}, errors.New("it is not the encoding of a point")
	}
	if x.Sign() == 0 && sign == 1 {
		return edPoint{}, errors.New("x is 0 and its sign bit is 1")
	}
	if uint(x.Bit(0)) != uint(sign) {
		x = edMod(new(big.Int).Sub(edP, x))
	}
	return edPoint{x, y, big.NewInt(1), edMod(new(big.Int).Mul(x, y))}, nil
}

// checkPublicKey applies the rule on the key named by what; the error says which part fails.
func checkPublicKey(pub []byte, what string) error {
	a, err := edDecode(pub)
	if err != nil {
		return errors.New(what + " does not decode: " + err.Error())
	}
	if edIsIdentity(a) {
		return errors.New(what + " is the identity point")
	}
	if !edIsIdentity(edMul(orderL, a)) {
		return errors.New(what + " multiplied by L is not the identity point")
	}
	return nil
}
