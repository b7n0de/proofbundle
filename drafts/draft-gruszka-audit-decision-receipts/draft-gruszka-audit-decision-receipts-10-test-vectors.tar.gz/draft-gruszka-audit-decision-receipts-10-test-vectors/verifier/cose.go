// The COSE_Sign1 binding of Appendix B of the proposal for draft -10: steps 1, 2, 3 and 6 of Section 3.2 for a
// receipt that is a tagged COSE_Sign1 message of RFC 9052 with an EdDSA (Ed25519) signature, in the core
// deterministic encoding of Section 4.2.1 of RFC 8949. Go standard library only.
package main

import (
	"bytes"
	"crypto/ed25519"
	"encoding/binary"
	"fmt"
	"unicode/utf8"
)

const (
	coseDecisionType = "https://signed-evidence.org/receipts/decision/v0.1"
	coseOutcomeType  = "https://signed-evidence.org/receipts/outcome/v0.1"
	coseContentType  = "application/json"
	coseAlgEdDSA     = -8
)

// cose is the binding of Appendix B.
var cose = binding{name: "cose", open: coseOpen, stmt: coseStatement}

// ---------------------------------------------------------------- a strict CBOR reader

type cborTag struct {
	num uint64
	v   any
}

type cborMap struct {
	keys, vals []any
}

type cborSimple int // 20 false, 21 true, 22 null

type cborReader struct {
	b []byte
	i int
}

// cborDecode reads exactly one data item in the core deterministic encoding of Section 4.2.1 of RFC 8949: the
// shortest form of every argument, definite lengths only, map keys in the bytewise lexicographic order of their
// encodings and without duplicates, valid UTF-8 in text strings, no floating-point value and no simple value
// other than false, true and null.
func cborDecode(b []byte) (any, error) {
	r := &cborReader{b: b}
	v, err := r.item(0)
	if err != nil {
		return nil, err
	}
	if r.i != len(b) {
		return nil, fmt.Errorf("trailing bytes at %d", r.i)
	}
	return v, nil
}

func (r *cborReader) head() (byte, uint64, error) {
	if r.i >= len(r.b) {
		return 0, 0, fmt.Errorf("unexpected end at %d", r.i)
	}
	ib := r.b[r.i]
	r.i++
	mt, ai := ib>>5, ib&31
	var n int
	switch {
	case ai < 24:
		return mt, uint64(ai), nil
	case ai == 24:
		n = 1
	case ai == 25:
		n = 2
	case ai == 26:
		n = 4
	case ai == 27:
		n = 8
	case ai == 31:
		return 0, 0, fmt.Errorf("indefinite length at %d", r.i-1)
	default:
		return 0, 0, fmt.Errorf("reserved additional information at %d", r.i-1)
	}
	if mt == 7 {
		return 0, 0, fmt.Errorf("floating-point or extended simple value at %d", r.i-1)
	}
	if r.i+n > len(r.b) {
		return 0, 0, fmt.Errorf("unexpected end at %d", r.i)
	}
	var v uint64
	for _, c := range r.b[r.i : r.i+n] {
		v = v<<8 | uint64(c)
	}
	r.i += n
	min := map[int]uint64{1: 24, 2: 1 << 8, 4: 1 << 16, 8: 1 << 32}[n]
	if v < min {
		return 0, 0, fmt.Errorf("argument not in its shortest form at %d", r.i-n-1)
	}
	return mt, v, nil
}

func (r *cborReader) item(depth int) (any, error) {
	if depth > 32 {
		return nil, fmt.Errorf("nesting deeper than 32")
	}
	start := r.i
	mt, v, err := r.head()
	if err != nil {
		return nil, err
	}
	switch mt {
	case 0:
		if v > 1<<63-1 {
			return nil, fmt.Errorf("integer out of range at %d", start)
		}
		return int64(v), nil
	case 1:
		if v > 1<<63-1 {
			return nil, fmt.Errorf("integer out of range at %d", start)
		}
		return -1 - int64(v), nil
	case 2, 3:
		if v > uint64(len(r.b)-r.i) {
			return nil, fmt.Errorf("string longer than the input at %d", start)
		}
		s := r.b[r.i : r.i+int(v)]
		r.i += int(v)
		if mt == 2 {
			return append([]byte{}, s...), nil
		}
		if !utf8.Valid(s) {
			return nil, fmt.Errorf("text string is not UTF-8 at %d", start)
		}
		return string(s), nil
	case 4:
		if v > uint64(len(r.b)-r.i) {
			return nil, fmt.Errorf("array longer than the input at %d", start)
		}
		a := make([]any, 0, int(v))
		for k := uint64(0); k < v; k++ {
			x, err := r.item(depth + 1)
			if err != nil {
				return nil, err
			}
			a = append(a, x)
		}
		return a, nil
	case 5:
		if v > uint64(len(r.b)-r.i) {
			return nil, fmt.Errorf("map longer than the input at %d", start)
		}
		m := &cborMap{}
		var prev []byte
		for k := uint64(0); k < v; k++ {
			ks := r.i
			key, err := r.item(depth + 1)
			if err != nil {
				return nil, err
			}
			enc := r.b[ks:r.i]
			if prev != nil && bytes.Compare(prev, enc) >= 0 {
				return nil, fmt.Errorf("map keys not in deterministic order or duplicated at %d", ks)
			}
			prev = enc
			val, err := r.item(depth + 1)
			if err != nil {
				return nil, err
			}
			m.keys = append(m.keys, key)
			m.vals = append(m.vals, val)
		}
		return m, nil
	case 6:
		x, err := r.item(depth + 1)
		if err != nil {
			return nil, err
		}
		return cborTag{v, x}, nil
	default: // 7, simple values below 24
		switch v {
		case 20, 21, 22:
			return cborSimple(v), nil
		}
		return nil, fmt.Errorf("simple value %d at %d", v, start)
	}
}

func (m *cborMap) get(k any) (any, bool) {
	for i, x := range m.keys {
		if x == k {
			return m.vals[i], true
		}
	}
	return nil, false
}

func hasTag(v any) bool {
	switch x := v.(type) {
	case cborTag:
		return true
	case []any:
		for _, e := range x {
			if hasTag(e) {
				return true
			}
		}
	case *cborMap:
		for i := range x.keys {
			if hasTag(x.keys[i]) || hasTag(x.vals[i]) {
				return true
			}
		}
	}
	return false
}

// cborHead encodes a head in its shortest form.
func cborHead(mt byte, n uint64) []byte {
	switch {
	case n < 24:
		return []byte{mt<<5 | byte(n)}
	case n < 1<<8:
		return []byte{mt<<5 | 24, byte(n)}
	case n < 1<<16:
		b := []byte{mt<<5 | 25, 0, 0}
		binary.BigEndian.PutUint16(b[1:], uint16(n))
		return b
	case n < 1<<32:
		b := []byte{mt<<5 | 26, 0, 0, 0, 0}
		binary.BigEndian.PutUint32(b[1:], uint32(n))
		return b
	}
	b := []byte{mt<<5 | 27, 0, 0, 0, 0, 0, 0, 0, 0}
	binary.BigEndian.PutUint64(b[1:], n)
	return b
}

// sigStructure1 is the Sig_structure of Section 4.4 of RFC 9052 for COSE_Sign1 with empty external_aad.
func sigStructure1(protected, payload []byte) []byte {
	var b []byte
	b = append(b, cborHead(4, 4)...)
	b = append(b, cborHead(3, 10)...)
	b = append(b, "Signature1"...)
	b = append(b, cborHead(2, uint64(len(protected)))...)
	b = append(b, protected...)
	b = append(b, cborHead(2, 0)...)
	b = append(b, cborHead(2, uint64(len(payload)))...)
	b = append(b, payload...)
	return b
}

// ---------------------------------------------------------------- steps 1, 2 and 3 (Appendix B)

type coseCtx struct{ iss, sub string }

const maxIssChars = 8192

func coseOpen(b []byte, pub ed25519.PublicKey) ([]byte, any, error) {
	// Step 1: one tagged COSE_Sign1 in core deterministic encoding, with the protected header of Appendix B
	v, err := cborDecode(b)
	if err != nil {
		return nil, nil, failf("step 1", "receipt is not one CBOR data item in core deterministic encoding: %v", err)
	}
	tg, ok := v.(cborTag)
	if !ok || tg.num != 18 {
		return nil, nil, failf("step 1", "receipt is not a COSE_Sign1 message with tag 18")
	}
	arr, ok := tg.v.([]any)
	if !ok || len(arr) != 4 {
		return nil, nil, failf("step 1", "COSE_Sign1 is not an array of four elements")
	}
	if hasTag(arr) {
		return nil, nil, failf("step 1", "COSE_Sign1 holds a tag other than the outer tag 18")
	}
	prot, ok1 := arr[0].([]byte)
	unprot, ok2 := arr[1].(*cborMap)
	_, ok3 := arr[2].([]byte)
	isNull := arr[2] == cborSimple(22)
	sig, ok4 := arr[3].([]byte)
	if !ok1 || !ok2 || !(ok3 || isNull) || !ok4 {
		return nil, nil, failf("step 1", "COSE_Sign1 elements are not protected bstr, unprotected map, payload bstr or nil and signature bstr")
	}
	pv, err := cborDecode(prot)
	if err != nil {
		return nil, nil, failf("step 1", "protected header is not one CBOR map in core deterministic encoding: %v", err)
	}
	ph, ok := pv.(*cborMap)
	if !ok {
		return nil, nil, failf("step 1", "protected header is not a map")
	}
	want := []any{int64(1), int64(3), int64(4), int64(15)}
	if len(ph.keys) != len(want) {
		return nil, nil, failf("step 1", "protected header must hold exactly the labels 1, 3, 4 and 15")
	}
	for i, k := range want {
		if ph.keys[i] != k {
			return nil, nil, failf("step 1", "protected header must hold exactly the labels 1, 3, 4 and 15")
		}
	}
	if a, _ := ph.get(int64(1)); a != int64(coseAlgEdDSA) {
		return nil, nil, failf("step 1", "alg %v is not EdDSA (-8)", a)
	}
	if c, _ := ph.get(int64(3)); c != coseContentType {
		return nil, nil, failf("step 1", "content type %v is not %s", c, coseContentType)
	}
	if k, _ := ph.get(int64(4)); !nonEmptyBytes(k) {
		return nil, nil, failf("step 1", "kid is not a non-empty byte string")
	}
	cw, _ := ph.get(int64(15))
	cm, ok := cw.(*cborMap)
	if !ok || len(cm.keys) != 2 || cm.keys[0] != int64(1) || cm.keys[1] != int64(2) {
		return nil, nil, failf("step 1", "CWT Claims must be a map with exactly iss (1) and sub (2)")
	}
	iss, ok1 := cm.vals[0].(string)
	sub, ok2 := cm.vals[1].(string)
	if !ok1 || !ok2 || iss == "" || sub == "" {
		return nil, nil, failf("step 1", "iss and sub must be non-empty text strings")
	}
	// Finding F3 of the second external reading: iss is a text string containing between 1 and 8192 characters,
	// inclusive, as required by Section 6 of RFC 9943; characters are counted as Unicode code points.
	if n := utf8.RuneCountInString(iss); n > maxIssChars {
		return nil, nil, failf("step 1", "iss has %d characters, more than %d (Section 6 of RFC 9943)", n, maxIssChars)
	}
	// Finding F2: every label of the unprotected header is an integer or a text string (Section 3 of RFC 9052), and
	// crit, label 2, stands only in the protected header (Section 3.1 of RFC 9052).
	for _, k := range unprot.keys {
		switch k.(type) {
		case int64, string:
		default:
			return nil, nil, failf("step 1", "unprotected header has a label that is neither an integer nor a text string")
		}
		if k == int64(2) {
			return nil, nil, failf("step 1", "unprotected header contains crit (2)")
		}
	}
	for _, k := range want {
		if _, there := unprot.get(k); there {
			return nil, nil, failf("step 1", "unprotected header repeats protected label %v", k)
		}
	}
	// Step 2: the payload is carried, not detached
	if isNull {
		return nil, nil, failf("step 2", "payload is detached (nil)")
	}
	P := arr[2].([]byte)
	// Step 3: Ed25519 over Sig_structure; Go's ed25519.Verify rejects an S that is not less than L
	if err := checkPublicKey(pub, "the expected key"); err != nil {
		return nil, nil, failf("step 3", "%v", err)
	}
	if len(sig) != ed25519.SignatureSize || !ed25519.Verify(pub, sigStructure1(prot, P), sig) {
		return nil, nil, failf("step 3", "the signature does not verify under the expected key")
	}
	return P, coseCtx{iss: iss, sub: sub}, nil
}

// ---------------------------------------------------------------- step 6 (Appendix B)

func coseStatement(sv any, kind string, ctx any) (map[string]any, map[string]any, string, error) {
	wantType, idName, prefix := coseDecisionType, "decisionId", "decision:"
	if kind == "outcome" {
		wantType, idName, prefix = coseOutcomeType, "outcomeId", "outcome:"
	}
	st, ok := obj(sv)
	if !ok {
		return nil, nil, "", failf("step 6", "payload is not an object")
	}
	if len(st) != 2 {
		return nil, nil, "", failf("step 6", "payload must have exactly the members predicate and type")
	}
	t, ok := str(st["type"])
	if !ok {
		return nil, nil, "", failf("step 6", "payload must have exactly the members predicate and type")
	}
	if t != wantType {
		return nil, nil, "", failf("step 6", "type %q", t)
	}
	pred, ok := obj(st["predicate"])
	if !ok {
		return nil, nil, "", failf("step 6", "predicate is not an object")
	}
	id, ok := str(pred[idName])
	if c := ctx.(coseCtx); !ok || id == "" || c.sub != prefix+id {
		return nil, nil, "", failf("step 6", "sub %q is not %q followed by %s", c.sub, prefix, idName)
	}
	pc, err := jcs(pred)
	if err != nil {
		return nil, nil, "", failf("step 6", "%v", err)
	}
	return st, pred, shaHex(pc), nil
}

func nonEmptyBytes(v any) bool { b, ok := v.([]byte); return ok && len(b) > 0 }
