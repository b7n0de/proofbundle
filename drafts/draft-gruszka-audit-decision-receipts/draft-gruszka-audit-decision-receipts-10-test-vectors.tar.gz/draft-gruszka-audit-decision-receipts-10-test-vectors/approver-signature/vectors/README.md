# Vectors of the approver signature profile, version 1

This directory holds 16 vectors for Section 3.9 as proposed in PROFILE-approver-signature.txt. For -10 they were signed anew with test keys derived as Appendix A.1 describes: the seed of each key is SHA-256 over the ASCII string "draft-gruszka-audit-decision-receipts test key " followed by its label, gate-sa, approver-1 or approver-2. Every signature can be made again from these labels.

## Test keys

Not for real records. The decision receipts are signed with gate-sa, whose decisionMaker.id is gate-sa. policy.json binds gate-sa to gate-sa for decisions, approver-1 to user-123 and approver-2 to user-456 as approvers. policy-gate-as-approver.json binds the gate key to user-123 as approver and is used by SA11 only.

- gate-sa `ULcjJ1DulKja0EjIH+F/fCjsHCX64AHa5vM3Zo01tH8=`
- approver-1 `NaFodtbI4q99jUOKDY3PdgFuOX3ODCQ3cpuZ4DK3Z1o=`
- approver-2 `i262dRw6N2af5ECLfw3xwFdco7MAzbhloiUF6lB6xbY=`

## Inputs common to all vectors

- a1.txt, the action bytes, SHA-256 `dec54f771352454097310ae4bd6608c0070ebebb3955c6be013c1b3a8e310bd0`. Every decision names them in parametersDigest and every call that supplies action bytes supplies a1.txt.
- a1x.txt, other action bytes, SHA-256 `b683418806875ff79c6fa190c50edab0b96577ad8062de5ba7b41dc1d9c363fb`, used only inside the signature of SA2.
- Decision receipts follow V1-good of Appendix A.2 of the draft with decisionMaker.id gate-sa, decisionId and validity.nonce dec- followed by the vector name in lower case, policyEngine example-gate/write and inputSnapshot[1].digest the SHA-256 of the approval record file of the vector. Unless a vector says otherwise, decidedAt is 2026-10-15T09:00:05Z, validity.expiresAt 2026-10-15T09:05:05Z and T 2026-10-15T09:01:00Z.
- The base approval record has approvalId appr-sa-001, approver user-123, session sess-1, actionDigest the SHA-256 of a1, approvedAt 2026-10-15T09:00:00Z and validUntil 2026-10-15T09:15:00Z.
- The expected audience is observer-1, the expected nonce the decisionId, the case is approval. A call with -approver-pub asks for the approver signature with that key.

## Recomputing a vector

Take the approval record file, remove the member approverSignature, serialize the rest under RFC 8785 to get B, form M = "DSSEv1" SP LEN(c) SP c SP LEN(B) SP B with c the ASCII string approval-record-signature-v1, and verify sig under the approver key named for the vector. vectors.json gives B as text and SHA-256(M) for every vector, so each step can be compared. Then run the checks of Section 3.9.3 in order.

## Vectors

| Vector | Change |
|---|---|
| SA1 | approval record signed by approver-1 over its own members, checked with approver-1 |
| SA2 | record names a1, signature made over the same record naming a1x |
| SA3 | record signed by approver-2, checked with approver-1, the key bound to user-123 |
| SA4 | record signed by approver-2, checked with approver-2, which the policy binds to user-456 only |
| SA5 | signed record with validUntil 09:10:00, decision valid until 09:20:00, T 09:12:00 |
| SA6 | copy of SA1 under session sess-2, signature of sess-1 kept, cited by a new decision |
| SA7 | copy of SA1 with validUntil moved from 09:15:00 to 09:30:00, signature kept |
| SA8 | record without approverSignature, approver signature not requested |
| SA9 | record without approverSignature, approver signature requested |
| SA10 | the signed record of SA1, approver signature not requested |
| SA11 | record signed with the gate key, which a policy also binds to user-123 as approver |
| SA12 | the signed record of SA1 checked without action bytes |
| SA13 | the signature of SA1 with a second member keyid in approverSignature |
| SA14 | the signature of SA1 with S replaced by S plus L |
| SA15 | the signature of SA1 written without its base64 padding |
| SA16 | signature by approver-1 over B itself instead of M, the PAE with the context string |

The expected result of each vector is in ../expected-sa.json; the README.md at the root of the package gives it with its reason.

## Files and SHA-256

| Vector | approval record | envelope | SHA-256(M) |
|---|---|---|---|
| SA1 | `08cd36eb9461be5b4ebe420efd6597a3a0c39f2c3f259f8c48743d93e61d52c5` | `32850d087111cb33cf0f13b3bf1c765155d996a0a20e03b83ca379deb4936481` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA2 | `0626dbb9384dc640790b38a5cec5226dd5de87359a11c073f351e67703ddebfb` | `fbcf1ec29ded9680823b06d2eeabb233a63ae03dcf67928f58ee5f0652e1647c` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA3 | `a6642068bca3ebc7a7fb7d4f674bdeccc52b7793badf5ba0d538f5209f02e1c1` | `18770b4f069b48ae80dea078580cef372b82eef449c0987c018f7ff674ba12f7` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA4 | `a6642068bca3ebc7a7fb7d4f674bdeccc52b7793badf5ba0d538f5209f02e1c1` | `4999e1e814e925857e6fb2fed18a1034b7104b7b34f3a18632d73ee2d6893da9` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA5 | `ecf9b5faf5b16d968bc8c7cf056288d647f1dd577c3a044aeca696c791d06794` | `70dcd0bebebf4d59d2fb514dc821f50c5742fda7271cdfdb842f2e4eedc2fad1` | `3ef36cd692726ec5f57a27637b1f197c24c80b0b135be9c8fb6617ea66d48601` |
| SA6 | `54a0c470fd858f72ce02c0821c27f5bba3fbc0a1b341b4da2a67f0351fa66845` | `69ae7c321e3426c9d886c681fd0efd9cf0b03b979cc8dcfdbf208b241c9e4db0` | `d453ad5bbf305ee58d7060637a85064589ea4a698c7165743b1f7dd8105b12b1` |
| SA7 | `0f510d6c1b290ca0ef3910e67980b698f413173b74202e427ba05894a8946c84` | `a60778e15317cf8d4fcfc19d6492c3ec95188e16d59b6c91bf0ef261e5038086` | `794adaab5f9ea63e98a6972786ad155bfa8571b26a0df577de42414e241ff0f4` |
| SA8 | `d8b10f173153cae55596112b22387cd80999bb87e9963cb917d1be900b651da9` | `741372d9b05d56007b702439de911b3a7d0a077e62276950558a24914faf261f` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA9 | `d8b10f173153cae55596112b22387cd80999bb87e9963cb917d1be900b651da9` | `71574ec2f3a39a0173b38765fed3dbed230f9ac41e61dfbb1c84ce04b4929e20` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA10 | `08cd36eb9461be5b4ebe420efd6597a3a0c39f2c3f259f8c48743d93e61d52c5` | `17aeb325a3360e78fe301d28cfed0658e2f36d7a04fb2dc378c07c2e8034b818` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA11 | `ce667fce8b1c92c5451a9369bc29b1d7cc7eea3c1d277a2cfe050b95ff2e5d96` | `4bd538d9cd4b15fe63dd9862ef27f01b243e8ab57c538bff03ede1e72cb28218` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA12 | `08cd36eb9461be5b4ebe420efd6597a3a0c39f2c3f259f8c48743d93e61d52c5` | `d5ca5f503d82fd4581dd209f3d4299bc05b9e3b6b8df232dfe63a128f8caeb4b` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA13 | `9b88d4b2967e9b8455d7efeac7f49da772f4857b9ef3efc6fdf79bdb10773302` | `3b20863ad49882df3ab60255521d378ea2a3d157c8b037435bca3ebaac2420a3` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA14 | `bb1534b06310ebe859009dce1587ed333a1eb126a7b878995e3fe3c669e598da` | `5f31d3a6c9fe831a5a72c1a361be903b6fe5526cc11ab3f170940fcf1eae1ca9` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA15 | `b04d159879a65243d4353712eb194556d4b581685c861aff8cc2c215fd2a9b85` | `1cf21b8f720e0f1064862c88b338d252220182f876577b5e9854cd0364fcb21a` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
| SA16 | `ed064b8303912f6ebb9e5b99e3416155b7c322168e163401fc1a956b606178a6` | `ea2eee0f34e50301ac1344a9babbbe15939030728dd34fc4efaf3cb9d7bec1d9` | `49bd09a9dbbb28eab3af6f843757a33b2c384a343bddc1e8bc2f1624a3282e77` |
