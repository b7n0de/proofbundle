# Vectors of the approver signature of Section 3.11

This folder holds SA1 to SA21, the vectors of the check of the approver signature that Section 3.11 of
draft-gruszka-audit-decision-receipts-10 defines. Every path in expected-sa.json and inputs-sa.json is relative to the
root of the package, and run_vectors.py in the root runs these vectors with all others. The verifier runs the check
with -approver-pub KEY and -case approval (approver.go); without -approver-pub it does not look at approverSignature
and prints what it printed before.

SA1 to SA16 are described in vectors/README.md, which was written when the profile was a proposal numbered Section 3.9;
its sections 3.9.1 to 3.9.5 are now 3.11.1 to 3.11.5. vectors/vectors.json gives for each of them the signed bytes B,
SHA-256(M) and the arguments relative to vectors/. Their decision receipts are signed with gate-sa, and their
approval records with approver-1 and approver-2. For -10 all three keys are derived as Appendix A.1 describes: the
seed of each is SHA-256 over the ASCII string "draft-gruszka-audit-decision-receipts test key " followed by the label
gate-sa, approver-1 or approver-2, so that every signature can be made again. Their public parts are
gate-sa ULcjJ1DulKja0EjIH+F/fCjsHCX64AHa5vM3Zo01tH8=, approver-1 NaFodtbI4q99jUOKDY3PdgFuOX3ODCQ3cpuZ4DK3Z1o= and approver-2 i262dRw6N2af5ECLfw3xwFdco7MAzbhloiUF6lB6xbY= (vectors/keys.json). SA1 to SA16
were re-signed with keys derived from public labels. The approval-record signatures and, where necessary, the
inputSnapshot digests and subject digests of their decision receipts were regenerated. Their other predicate
members and expected results are unchanged.

SA17 and SA18 separate the rule of check 5 on the approver key: the key decodes, is not the identity point, and
multiplied by L gives the identity point. In SA17 the approver key is the identity point O, 01 followed by 31 zero
bytes, and the sig of the approval record is R = O and S = 0, which satisfies the group equation without the cofactor
for every message. In SA18 the approver key is a*B + T, where a is the secret scalar of observer-1 of Appendix A.1 and T
a point of order 8, and the sig was made with a nonce for which the hash k is a multiple of 8, so that the group
equation without the cofactor holds. Each approval record is that of SA1 without its signature, with approvalId
appr-sa17 or appr-sa18, signed as check 5 describes. Its decision receipt is that of SA1 with decisionId and nonce
dec-sa17 or dec-sa18 and decisionMaker.id gate-1, signed by gate-1 of Appendix A.1. vectors/policy-sa17.json and
vectors/policy-sa18.json bind the approver key to user-123 and gate-1 to gate-1.

SA19 to SA21 come with the external reading of -10. SA19 has the signature of SA1 written with pad bits that are not
zero in its last base64 character before the padding; the decoded bytes are those of the signature of SA1. SA20 is
signed under approver-1 with R the identity point O and S = k a mod L, where a is the secret scalar of approver-1.
SA21 is SA1 checked with an approver key that is not the encoding of a point, which vectors/policy-sa21.json binds
to user-123. The approval records of SA19 and SA20 are that of
SA1 with approvalId appr-sa19 and appr-sa20, and their decision receipts that of SA1 with decisionId and nonce dec-sa19
and dec-sa20, signed by gate-sa.

This README and vectors/README.md name no result. The results are in expected-sa.json, and the README.md at the
root of the package gives them with their reasons.
