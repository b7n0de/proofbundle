#!/usr/bin/env python3
"""Run every test vector of draft-gruszka-audit-decision-receipts-10 against the verifier, offline.

The vectors of -07 are in expected.json, the vectors added in -08 in expected-08/*.json and the vectors added in
-10 in expected-10/*.json, each folder read in the order of its file names. Then come the vectors of the COSE_Sign1
binding of Appendix B in cose/expected-cose.json, of the first check of Section 3.5 in first-check/expected-first.json
and of the approver signature in approver-signature/expected-sa.json.

Usage: python3 run_vectors.py [--verifier PATH] [--proofbundle PATH] [--json OUT]

Before the vectors the script runs check_descriptions.py, which searches the inputs files, description.txt,
description-08/ and the README.md files of first-check/, approver-signature/ and approver-signature/vectors/ for the
words in its list WORDS. Where that search ends with an exit code other than 0, the script prints its report and
exits with 1 before it runs any vector. A run without a match does not show that no description names a result.

Without --verifier the script builds the verifier from verifier/ with the local Go toolchain (standard library only,
no network; measured with Go 1.24.7). Each vector in expected.json is run with the arguments given there, from the
directory of this script. A passing vector must end with exit code 0 and a first line starting with PASS. A failing
vector must end with exit code 1 and a first line starting with the expected prefix in expected.json, for
example "FAIL step 7" for step 7 of Section 3.2. A vector that the relying party refuses under Section 4 must pass
the receipt and end with exit code 3 and a line "RELYING PARTY, Section 4 ... REFUSE". A vector of the third check of
Section 3.5 ("third_check" in expected.json) is called with one -held KEY:FILE per receipt held. It must pass the
receipt, and its last line must show that the third check ran over that number of receipts held: a passing vector
ends with exit code 0 and "AUDITOR, Section 3.5, third check over the receipts held (N), ... PASS", a vector whose
third check fails ends with exit code 4 and "... (N), ... FAIL", and a vector whose input is invalid, because a
receipt held fails the preliminary checks of that check, ends with exit code 2 and "AUDITOR, Section 3.5, third check:
NO RESULT, the input is invalid". A run without -held is not a run of the third check. A vector of the second check
of Section 3.5 ("second_check") is called with -held and -second. It must pass the receipt, and its last line must
show that the second check ran over that number of receipts held: a passing vector ends with exit code 0 and
"AUDITOR, Section 3.5, second check over the receipts held (N), ... PASS", a vector whose second check fails ends
with exit code 5 and "... (N), ... FAIL". A vector of the first check of Section 3.5 ("first_check") must pass the
receipt and end with the exit code and the start of the last line that its entry gives: 0 and "... first check over
the receipts held (N), ... PASS", 6 and "... FAIL", or 2 and "AUDITOR, Section 3.5, first check: NO RESULT". A vector
of the approver signature ("approver_signature") that passes must start with PASS. Every vector whose entry gives
"output_has" must print that text, and every vector whose entry gives "output_lacks" must not print it; for E12 and
E13 of the first check these are the not-counted diagnostics of Section 3.5, so a run without them fails. For I1, a
vector of an incomplete invocation ("incomplete_call"), success requires exit code 2, the expected
incomplete-invocation diagnostic, and the absence of any receipt-verification PASS or FAIL result: its first line
starts with the prefix that its entry gives, and no line of its output holds the word PASS or FAIL. The count of
outputs equal to the recorded output is reported but does not change the exit code, because another verifier may word its lines differently. With --proofbundle the script
also runs the proofbundle 6.6.0 commands of expected.json and compares their exit codes with the recorded ones. It
then checks the files of a4/ against the sizes, SHA-256 values and one-byte changes that A4-description.txt states
for the Signed Statements and Receipts of Appendix A.4; it does not verify their COSE signatures. The script prints
one line per vector and per check and a summary, and exits with 0 only if every vector and every check is as
expected. Standard library only; measured with Python 3.13.18.
"""
import argparse
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent


def build_verifier(tmp):
    exe = pathlib.Path(tmp) / ("adrverify.exe" if os.name == "nt" else "adrverify")
    env = dict(os.environ, CGO_ENABLED="0", GOFLAGS="", GOPROXY="off", GOTOOLCHAIN="local")
    p = subprocess.run(["go", "build", "-trimpath", "-o", str(exe), "."], cwd=HERE / "verifier", env=env,
                       capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit("go build failed:\n" + p.stdout + p.stderr)
    return str(exe)


def run(cmd):
    p = subprocess.run(cmd, cwd=HERE, capture_output=True)
    return p.returncode, (p.stdout + p.stderr).decode("utf-8", "replace").strip()


GROUPS = ("cose/expected-cose.json", "first-check/expected-first.json", "approver-signature/expected-sa.json")
THIRD = "AUDITOR, Section 3.5, third check"
RESULT = re.compile(r"\b(PASS|FAIL)\b")
SECOND = "AUDITOR, Section 3.5, second check"


def second(v, code, lines):
    n = v["verifier"]["argv"].count("-held")
    if n == 0 or "-second" not in v["verifier"]["argv"] or not lines[0].startswith("PASS"):
        return False
    at = f"{SECOND} over the receipts held ({n}), separate from the receipt: "
    if v["expected"] == "pass":
        return code == 0 and lines[-1].startswith(at + "PASS")
    if v["expected"] == "auditor-fail":
        return code == 5 and lines[-1].startswith(at + "FAIL")
    return False


def third(v, code, lines):
    n = v["verifier"]["argv"].count("-held")
    if n == 0 or not lines[0].startswith("PASS"):
        return False
    at = f"{THIRD} over the receipts held ({n}), separate from the receipt: "
    if v["expected"] == "pass":
        return code == 0 and lines[-1].startswith(at + "PASS")
    if v["expected"] == "auditor-fail":
        return code == 4 and lines[-1].startswith(at + "FAIL")
    if v["expected"] == "input-invalid":
        return code == 2 and lines[-1].startswith(THIRD + ": NO RESULT, the input is invalid")
    return False


def first(v, code, lines):
    return lines[0].startswith("PASS") and lines[-1].startswith(v["verifier"]["prefix"])


def check(v, code, out):
    lines = out.split("\n") if out else [""]
    e = v["verifier"]
    if code != e["exit"]:
        return False
    # a diagnostic that the entry requires (output_has) must be printed, and one it rules out (output_lacks) must not
    if v.get("output_has") and v["output_has"] not in out:
        return False
    if v.get("output_lacks") and v["output_lacks"] in out:
        return False
    if v.get("incomplete_call"):
        # finding F4 of the second external reading: exit code 2, the expected diagnostic, and no PASS or FAIL result
        return code == 2 and lines[0].startswith(e["prefix"]) and not RESULT.search(out)
    if v.get("first_check"):
        return first(v, code, lines)
    if v.get("approver_signature") and v["expected"] == "pass":
        return lines[0].startswith("PASS")
    if v.get("second_check"):
        return second(v, code, lines)
    if v.get("third_check"):
        return third(v, code, lines)
    if "-held" in e["argv"]:
        return False
    if v["expected"] == "pass":
        return lines[0].startswith("PASS")
    if v["expected"] == "fail":
        return lines[0].startswith(e["prefix"] + ":")
    if v["expected"] == "auditor-fail":
        return lines[0].startswith("PASS") and any(
            l.startswith("AUDITOR, Section 3.5") and "FAIL" in l for l in lines[1:])
    return lines[0].startswith("PASS") and any(
        l.startswith("RELYING PARTY, Section 4") and "REFUSE" in l for l in lines[1:])


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--verifier")
    ap.add_argument("--proofbundle")
    ap.add_argument("--json")
    a = ap.parse_args()
    chk = subprocess.run([sys.executable, "-I", "-B", str(HERE / "check_descriptions.py"), str(HERE)],
                         capture_output=True, text=True)
    print((chk.stdout + chk.stderr).rstrip())
    if chk.returncode != 0:
        sys.exit(1)
    vectors = json.loads((HERE / "expected.json").read_text(encoding="utf-8"))["vectors"]
    for d in ("expected-08", "expected-10"):
        vectors += [v for f in sorted((HERE / d).glob("*.json"))
                    for v in json.loads(f.read_text(encoding="utf-8"))["vectors"]]
    for f in GROUPS:
        vectors += json.loads((HERE / f).read_text(encoding="utf-8"))["vectors"]
    with tempfile.TemporaryDirectory() as tmp:
        exe = a.verifier or build_verifier(tmp)
        rows, bad, same, pb_bad = [], 0, 0, 0
        for v in vectors:
            code, out = run([exe] + v["verifier"]["argv"])
            ok = check(v, code, out)
            bad += not ok
            same += out == v["verifier"]["recorded_output"]
            row = {"name": v["name"], "where": v["where"], "expected": v["text_result"], "exit": code,
                   "first_line": out.split("\n")[0], "as_expected": ok}
            if a.proofbundle:
                exits = [run([a.proofbundle] + c["argv"])[0] for c in v["proofbundle"]]
                row["proofbundle_exits"] = exits
                pbok = exits == [c["exit"] for c in v["proofbundle"]]
                row["proofbundle_as_recorded"] = pbok
                pb_bad += not pbok
            rows.append(row)
            print(f"{v['name']:<12} {'OK  ' if ok else 'DIFF'} exit {code}  {v['text_result']:<44} "
                  f"{v['where']:<13} {row['first_line'][:70]}")
    good = [v for v in vectors if v["expected"] == "pass"]
    fail = [v for v in vectors if v["expected"] != "pass"]
    okn = {r["name"] for r in rows if r["as_expected"]}
    print(f"vectors {len(vectors)}: passing {sum(v['name'] in okn for v in good)} of {len(good)} with exit 0, "
          f"failing, refused or with invalid input at the expected step {sum(v['name'] in okn for v in fail)} of "
          f"{len(fail)}")
    th = [v for v in vectors if v.get("third_check")]
    print(f"vectors of the third check of Section 3.5: {sum(v['name'] in okn for v in th)} of {len(th)} with that check "
          f"run over the receipts held as expected")
    se = [v for v in vectors if v.get("second_check")]
    print(f"vectors of the second check of Section 3.5: {sum(v['name'] in okn for v in se)} of {len(se)} with that check "
          f"run over the receipts held as expected")
    fi = [v for v in vectors if v.get("first_check")]
    print(f"vectors of the first check of Section 3.5: {sum(v['name'] in okn for v in fi)} of {len(fi)} as expected")
    for g in ("COSE_Sign1 binding, Appendix B", "approver signature"):
        gv = [v for v in vectors if v.get("group") == g]
        print(f"vectors of the group {g}: {sum(v['name'] in okn for v in gv)} of {len(gv)} as expected")
    print(f"verifier output equal to the recorded output: {same} of {len(vectors)}")
    if a.proofbundle:
        print(f"proofbundle exit codes as recorded: {len(vectors) - pb_bad} of {len(vectors)}")
    a4bad = 0
    a4 = json.loads((HERE / "expected.json").read_text(encoding="utf-8")).get("registration_examples", [])
    for c in a4:
        b = (HERE / c["file"]).read_bytes()
        if "sha256" in c:
            ok = len(b) == c["size"] and hashlib.sha256(b).hexdigest() == c["sha256"]
        elif "hex" in c:
            ok = b.hex() == c["hex"]
        elif "offset" in c:
            x = (HERE / c["base"]).read_bytes()
            ok = (len(x) == len(b) and [i for i in range(len(b)) if b[i] != x[i]] == [c["offset"]]
                  and x[c["offset"]] == c["from"] and b[c["offset"]] == c["to"])
        else:
            ok = c["absent"].encode() in (HERE / c["base"]).read_bytes() and c["absent"].encode() not in b
        a4bad += not ok
        print(f"{'A.4':<12} {'OK  ' if ok else 'DIFF'} {c['file']:<44} {c['check']}")
    if a4:
        print(f"Appendix A.4 checks as stated: {len(a4) - a4bad} of {len(a4)}")
    if a.json:
        pathlib.Path(a.json).write_text(json.dumps(rows, indent=1) + "\n", encoding="utf-8")
    sys.exit(1 if bad or pb_bad or a4bad else 0)


if __name__ == "__main__":
    main()
