#!/usr/bin/env python3
"""Check that the descriptions meant for a blind run name no result.

The inputs files (inputs.json, inputs-08/, inputs-10/, cose/inputs-cose.json, first-check/inputs-first.json,
approver-signature/inputs-sa.json), description.txt, description-08/ and the README.md files of first-check/,
approver-signature/ and approver-signature/vectors/ describe vectors and their inputs. None of them may name the
expected result of a vector, the verdict of a check, or a reason for which a verifier would refuse a vector; the
results are in the expected files. This script reports every place where one of the words of WORDS remains and
exits with 1 if there is one, else with 0. run_vectors.py runs it before the vectors.

In each string or line it checks, it first leaves out text in double quotes or backquotes (JSON values such as
"refused" are inputs), words in capitals only other than PASS and FAIL (enumerated values such as REFUSE), file
paths and the names of vectors (such as V1-accept). A phrase that only describes an input may stay where ALLOWED
lists it with its reason.

Usage: python3 check_descriptions.py [ROOT]   (ROOT defaults to the directory of this script)
Standard library only.
"""
import json
import pathlib
import re
import sys

WORDS = re.compile(r"\b(pass(?:es|ed|ing)?|fail(?:s|ed|ing|ure)?|refus(?:e|es|ed|al|ing)|reject(?:s|ed|ion|ing)?|"
                   r"accept(?:s|ed|ance|ing)?|succeed(?:s|ed)?|success|because|would|invalid|valid)\b", re.I)
QUOTED = re.compile(r"\"[^\"\n]*\"|`[^`\n]*`")
PATH = re.compile(r"\S*[A-Za-z0-9_-]\.(?:json|txt|cose|bin|pem|cbor|md|py|go|sha256)\b\S*")
CAPS = re.compile(r"\b(?!(?:PASS|FAIL)\b)[A-Z][A-Z0-9_]+\b")

JSON_FILES = ["inputs.json", "inputs-08/*.json", "inputs-10/*.json", "cose/inputs-cose.json",
              "first-check/inputs-first.json", "approver-signature/inputs-sa.json"]
TEXT_FILES = ["description.txt", "description-08/*.txt", "first-check/README.md", "approver-signature/README.md",
              "approver-signature/vectors/README.md"]
EXPECTED = ["expected.json", "expected-08/*.json", "expected-10/*.json", "cose/expected-cose.json",
            "first-check/expected-first.json", "approver-signature/expected-sa.json"]
SKIP_KEYS = {"argv", "name", "derived_from"}

# (file pattern, exact phrase, reason). The phrase is left out before the words are looked for.
ALLOWED = [
    ("inputs-10/*.json", "(parents made present with valid values first, as in the file of the vector)",
     "build instruction: the members above the changed one are first given values in the form of Section 3.8, so "
     "that only the named change differs from the base payload"),
    ("approver-signature/*", "decision valid until 09:20:00",
     "input value: the end of the validity window of the decision receipt of SA5"),
    ("approver-signature/vectors/*", "decision valid until 09:20:00",
     "input value: the end of the validity window of the decision receipt of SA5"),
    ("first-check/README.md", "whose three values joined with NUL separators would be equal",
     "input property: how the two approval records of E19 are built"),
    ("first-check/README.md", "unless the third check (4) or the second check (5) has failed before",
     "section Results: the exit codes of the verifier of the package for any run, not the result of a vector"),
    ("first-check/README.md", "Exit code 0 and the same line with PASS otherwise",
     "section Results: the output of the verifier of the package for any run, not the result of a vector"),
]


def names(root):
    out = set()
    for pat in EXPECTED + JSON_FILES:
        for f in sorted(root.glob(pat)):
            for v in json.loads(f.read_text(encoding="utf-8")).get("vectors", []):
                out.add(v["name"])
    for f in sorted(root.glob("description-08/*.txt")):
        out.add(f.stem)
    return sorted(out, key=len, reverse=True)


def strings(o, path=()):
    if isinstance(o, dict):
        for k, v in o.items():
            if k not in SKIP_KEYS:
                yield from strings(v, path + (k,))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from strings(v, path + (str(i),))
    elif isinstance(o, str):
        yield path, o


def hits(text, rel, vnames):
    allowed = 0
    for pat, phrase, _ in ALLOWED:
        if pathlib.PurePosixPath(rel).match(pat) and phrase in text:
            allowed += text.count(phrase)
            text = text.replace(phrase, " ")
    t = QUOTED.sub(" ", text)
    t = PATH.sub(" ", t)
    for n in vnames:
        t = re.sub(r"(?<![\w-])" + re.escape(n) + r"(?![\w-])", " ", t)
    t = CAPS.sub(" ", t)
    return [m.group(0) for m in WORDS.finditer(t)], allowed


def main():
    root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else __file__).resolve()
    if root.is_file():
        root = root.parent
    vnames = names(root)
    found, allowed_n, checked = [], 0, 0
    for pat in JSON_FILES:
        for f in sorted(root.glob(pat)):
            rel = f.relative_to(root).as_posix()
            doc = json.loads(f.read_text(encoding="utf-8"))
            items = [(v.get("name", "?"), "/".join(p), s) for v in doc.get("vectors", []) for p, s in strings(v)]
            items += [("-", k, doc[k]) for k in ("note",) if isinstance(doc.get(k), str)]
            for name, where, s in items:
                checked += 1
                w, al = hits(s, rel, vnames)
                allowed_n += al
                if w:
                    found.append((rel, name, where, w, s))
    for pat in TEXT_FILES:
        for f in sorted(root.glob(pat)):
            rel = f.relative_to(root).as_posix()
            # a paragraph is checked as one string, so that a phrase broken over two lines is found
            paras = re.split(r"\n\s*\n", f.read_text(encoding="utf-8"))
            line = 1
            for para in paras:
                s = " ".join(x.strip() for x in para.split("\n"))
                checked += 1
                w, al = hits(s, rel, vnames)
                allowed_n += al
                if w:
                    found.append((rel, "-", f"paragraph at line {line}", w, s))
                line += para.count("\n") + 2
    for rel, name, where, w, s in found:
        print(f"RESULT NAMED {rel} {name} {where}: {', '.join(w)}: {s}")
    print(f"descriptions: {checked} strings and paragraphs checked, {allowed_n} allowed input phrases, "
          f"{len(found)} naming a result")
    sys.exit(1 if found else 0)


if __name__ == "__main__":
    main()
