#!/usr/bin/env python3
"""Run every test vector of draft-gruszka-audit-decision-receipts-06 against the verifier, offline.

Usage: python3 run_vectors.py [--verifier PATH] [--proofbundle PATH] [--json OUT]

Without --verifier the script builds the verifier from verifier/ with the local Go toolchain (standard library only,
no network; measured with Go 1.24.7). Each vector in expected.json is run with the arguments given there, from the
directory of this script. A passing vector must end with exit code 0 and a first line starting with PASS. A failing
vector must end with exit code 1 and a first line starting with the expected prefix in expected.json, for
example "FAIL step 7" for step 7 of Section 3.2. A vector that the relying party refuses under Section 4 must pass
the receipt and end with exit code 3 and a line "RELYING PARTY, Section 4 ... REFUSE". With --proofbundle the script
also runs the proofbundle 6.4.0 commands of expected.json and compares their exit codes with the recorded ones. It
then checks the files of a4/ against the sizes, SHA-256 values and one-byte changes that A4-description.txt states
for the Signed Statements and Receipts of Appendix A.4; it does not verify their COSE signatures. The script prints
one line per vector and per check and a summary, and exits with 0 only if every vector and every check is as
expected. Standard library only; measured with Python 3.13.18.
"""
import argparse
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent


def build_verifier(tmp):
    exe = pathlib.Path(tmp) / ("adrverify.exe" if os.name == "nt" else "adrverify")
    env = dict(os.environ, CGO_ENABLED="0", GOFLAGS="", GOPROXY="off", GOTOOLCHAIN="local")
    p = subprocess.run(["go", "build", "-trimpath", "-o", str(exe), "."], cwd=HERE / "verifier", env=env,
                       capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit("go build failed:\n" + p.stdout + p.stderr)
    return str(exe)


def run(cmd):
    p = subprocess.run(cmd, cwd=HERE, capture_output=True)
    return p.returncode, (p.stdout + p.stderr).decode("utf-8", "replace").strip()


def check(v, code, out):
    lines = out.split("\n") if out else [""]
    e = v["verifier"]
    if code != e["exit"]:
        return False
    if v["expected"] == "pass":
        return lines[0].startswith("PASS")
    if v["expected"] == "fail":
        return lines[0].startswith(e["prefix"] + ":")
    return lines[0].startswith("PASS") and any(
        l.startswith("RELYING PARTY, Section 4") and "REFUSE" in l for l in lines[1:])


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--verifier")
    ap.add_argument("--proofbundle")
    ap.add_argument("--json")
    a = ap.parse_args()
    vectors = json.loads((HERE / "expected.json").read_text(encoding="utf-8"))["vectors"]
    with tempfile.TemporaryDirectory() as tmp:
        exe = a.verifier or build_verifier(tmp)
        rows, bad, same, pb_bad = [], 0, 0, 0
        for v in vectors:
            code, out = run([exe] + v["verifier"]["argv"])
            ok = check(v, code, out)
            bad += not ok
            same += out == v["verifier"]["recorded_output"]
            row = {"name": v["name"], "where": v["where"], "expected": v["text_result"], "exit": code,
                   "first_line": out.split("\n")[0], "as_expected": ok}
            if a.proofbundle:
                exits = [run([a.proofbundle] + c["argv"])[0] for c in v["proofbundle"]]
                row["proofbundle_exits"] = exits
                pbok = exits == [c["exit"] for c in v["proofbundle"]]
                row["proofbundle_as_recorded"] = pbok
                pb_bad += not pbok
            rows.append(row)
            print(f"{v['name']:<12} {'OK  ' if ok else 'DIFF'} exit {code}  {v['text_result']:<44} "
                  f"{v['where']:<13} {row['first_line'][:70]}")
    good = [v for v in vectors if v["expected"] == "pass"]
    fail = [v for v in vectors if v["expected"] != "pass"]
    okn = {r["name"] for r in rows if r["as_expected"]}
    print(f"vectors {len(vectors)}: passing {sum(v['name'] in okn for v in good)} of {len(good)} with exit 0, "
          f"failing or refused at the expected step {sum(v['name'] in okn for v in fail)} of {len(fail)}")
    print(f"verifier output equal to the recorded output: {same} of {len(vectors)}")
    if a.proofbundle:
        print(f"proofbundle exit codes as recorded: {len(vectors) - pb_bad} of {len(vectors)}")
    a4bad = 0
    a4 = json.loads((HERE / "expected.json").read_text(encoding="utf-8")).get("registration_examples", [])
    for c in a4:
        b = (HERE / c["file"]).read_bytes()
        if "sha256" in c:
            ok = len(b) == c["size"] and hashlib.sha256(b).hexdigest() == c["sha256"]
        elif "hex" in c:
            ok = b.hex() == c["hex"]
        elif "offset" in c:
            x = (HERE / c["base"]).read_bytes()
            ok = (len(x) == len(b) and [i for i in range(len(b)) if b[i] != x[i]] == [c["offset"]]
                  and x[c["offset"]] == c["from"] and b[c["offset"]] == c["to"])
        else:
            ok = c["absent"].encode() in (HERE / c["base"]).read_bytes() and c["absent"].encode() not in b
        a4bad += not ok
        print(f"{'A.4':<12} {'OK  ' if ok else 'DIFF'} {c['file']:<44} {c['check']}")
    if a4:
        print(f"Appendix A.4 checks as stated: {len(a4) - a4bad} of {len(a4)}")
    if a.json:
        pathlib.Path(a.json).write_text(json.dumps(rows, indent=1) + "\n", encoding="utf-8")
    sys.exit(1 if bad or pb_bad or a4bad else 0)


if __name__ == "__main__":
    main()
