# Test vectors of draft-gruszka-audit-decision-receipts-06

This package holds all 100 test vectors of Appendix A of draft-gruszka-audit-decision-receipts-06: the seven vectors
of Appendix A.3 (V1-good, V1-bad, V2-good, V2-bad, V3-decision, V3-good, V3-bad), the failure vectors F1 to F88 and
F91 to F93 with F17-outcome, and the passing vectors V2-micro and F94. Appendix A.3 and Appendix A.5 of the draft
give the seven vectors of A.3 and F10 in full; the package holds them as well, so that one run covers every vector.
It also holds the example Signed Statements and SCITT Receipts for registration that Appendix A.4 names.

## Contents

- vectors/ holds every envelope and every input that a check uses, under the names that expected.json gives. Among
  them are action bytes, approval records, consumption states, effect bytes and trust policies.
- expected.json gives, for each vector, where the draft gives it, the result and step expected for it, the
  arguments of the verifier, its expected exit code and the start of its first output line, the output recorded
  when the package was made, and the proofbundle 6.4.0 commands with their recorded exit codes, and lists the
  checks of a4/.
- verifier/ holds a verifier of Sections 3 and 4 written in Go from the text of the draft, with the Go standard
  library only. It shares no code with proofbundle. verifier/BUILD.txt gives the build command and the SHA-256 of
  the program for one toolchain.
- run_vectors.py runs every vector against that verifier.
- A5-description.txt is the text of Appendix A.5 before its failure vectors moved into this package. It describes
  how each vector is derived and checked and gives Table 6 with the results of proofbundle 6.4.0.
- description-06.txt describes F91 to F94, the four vectors for the bound of step 4 of Section 3.2.
- a4/ holds the inputs of the registration examples. These are the V2-good envelope bytes, Signed Statements A and B, the
  detached payload of B, the counterexamples, the public test keys of the Issuer and of the Receipt issuer, and the
  two SCITT Receipts with a counterexample. A4-description.txt is the text that gave their bytes and described how
  they are built and checked.
- MANIFEST.sha256 lists the SHA-256 of every other file.

## Running

Before extracting the downloaded archive, verify its SHA-256 against the value in Appendix A.5 of the draft.
Once extracted, check the files and run the verifier.

    sha256sum -c MANIFEST.sha256
    python3 run_vectors.py

You can try it offline. If a vector does not behave as the draft says, please tell us.

The script uses the Python standard library and builds the verifier with a local Go toolchain without network
access. The recorded outputs were produced with Python 3.13.18 and Go 1.24.7 on Linux x86-64. Other toolchains may produce different binary hashes or output. With
--verifier PATH it uses an existing build instead. With --proofbundle PATH it also runs the recorded commands
of proofbundle 6.4.0 (https://proofbundle.dev), a separate open-source verifier, and compares their exit codes. It
prints one line per vector and exits with 0 only if every passing
vector passes with exit code 0, every failing vector fails at its expected step, every vector that the
relying party refuses under Section 4 passes the receipt and is refused, and the files in a4/ have the sizes,
SHA-256 values and one-byte changes that A4-description.txt states. It does not verify the COSE signatures of a4/;
A4-description.txt describes how to.

## Keys

All keys in this package are test keys of the draft, given in Appendix A.1 and in A4-description.txt. They are
published and are not for real receipts.

Assisted by little helpers.
