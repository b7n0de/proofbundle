package main

// Field rules of Section 3.8 (since an earlier revision): a generic check of a predicate against the rows in fieldrules.go.
// The meaning of each type, of Required and of Null is taken from the paragraphs of Section 3.8.

import (
	"fmt"
	"regexp"
	"strings"
)

// Since a later revision: a fraction of a second has one to six digits.
var tsRE = regexp.MustCompile(`^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?Z$`)
var intRE = regexp.MustCompile(`^(0|[1-9][0-9]*)$`)
var wordRE = regexp.MustCompile(`^[A-Za-z]+$`)

func parentOf(path string) string {
	if i := strings.LastIndex(path, "."); i >= 0 {
		return path[:i]
	}
	return ""
}

func enumOf(note string) []string {
	if i := strings.Index(note, " is "); i >= 0 {
		note = note[i+4:]
	}
	note = strings.ReplaceAll(note, " or ", ", ")
	var out []string
	for _, w := range strings.Split(note, ",") {
		out = append(out, strings.TrimSpace(w))
	}
	return out
}

type tableChecker struct {
	children map[string][]fieldRule
}

func newTableChecker(rules []fieldRule) *tableChecker {
	tc := &tableChecker{children: map[string][]fieldRule{}}
	for _, r := range rules {
		p := parentOf(r.path)
		tc.children[p] = append(tc.children[p], r)
	}
	return tc
}

func last(path string) string {
	if i := strings.LastIndex(path, "."); i >= 0 {
		return path[i+1:]
	}
	return path
}

func (tc *tableChecker) obj(m map[string]any, key, where string) error {
	rules := map[string]fieldRule{}
	for _, r := range tc.children[key] {
		rules[last(r.path)] = r
	}
	for k := range m {
		if _, ok := rules[k]; !ok {
			return fmt.Errorf("%s.%s is not a member the table of Section 3.8 lists", where, k)
		}
	}
	for name, r := range rules {
		if _, ok := m[name]; !ok && r.req == "yes" {
			return fmt.Errorf("%s.%s is required by the table of Section 3.8", where, name)
		}
	}
	if key == "proposedAction" {
		_, d := m["parametersDigest"]
		_, r := m["parametersRef"]
		if !d && !r {
			return fmt.Errorf("%s has neither parametersDigest nor parametersRef (note (1))", where)
		}
	}
	for name, x := range m {
		if err := tc.val(x, rules[name], where+"."+name); err != nil {
			return err
		}
	}
	return nil
}

func noNull(v any, where string) error {
	return checkNulls(v, where, map[string]bool{})
}

func (tc *tableChecker) val(x any, r fieldRule, where string) error {
	if x == nil {
		if r.null == "yes" {
			return nil
		}
		return fmt.Errorf("%s is null", where)
	}
	switch {
	case r.typ == "any value":
		return noNull(x, where)
	case r.typ == "object":
		m, ok := obj(x)
		if !ok {
			return fmt.Errorf("%s is not an object", where)
		}
		return tc.obj(m, r.path, where)
	case r.typ == "open object":
		if _, ok := obj(x); !ok {
			return fmt.Errorf("%s is not an object", where)
		}
		return noNull(x, where)
	case strings.HasPrefix(r.typ, "array") || strings.HasPrefix(r.typ, "non-empty array"):
		xs, ok := x.([]any)
		if !ok {
			return fmt.Errorf("%s is not an array", where)
		}
		if strings.HasPrefix(r.typ, "non-empty") && len(xs) == 0 {
			return fmt.Errorf("%s is empty", where)
		}
		// Since revision -07, for relationships: at least one and at most 64 entries.
		if r.typ == "array of 1 to 64 objects" && (len(xs) < 1 || len(xs) > 64) {
			return fmt.Errorf("%s holds %d entries, not 1 to 64", where, len(xs))
		}
		for i, e := range xs {
			w := fmt.Sprintf("%s[%d]", where, i)
			var err error
			switch r.typ {
			case "array of objects", "array of 1 to 64 objects":
				m, ok := obj(e)
				if !ok {
					return fmt.Errorf("%s is not an object", w)
				}
				err = tc.obj(m, r.path+"[]", w)
			case "array of objects or strings":
				if _, isStr := str(e); isStr {
					continue
				}
				m, ok := obj(e)
				if !ok {
					return fmt.Errorf("%s is neither an object nor a string", w)
				}
				err = tc.obj(m, r.path+"[]", w)
			case "array of strings":
				if _, ok := str(e); !ok {
					return fmt.Errorf("%s is not a string", w)
				}
			case "non-empty array of non-empty strings":
				if !nonEmptyString(e) {
					return fmt.Errorf("%s is not a non-empty string", w)
				}
			case "array of any values":
				err = noNull(e, w)
			default:
				return fmt.Errorf("unknown type %q", r.typ)
			}
			if err != nil {
				return err
			}
		}
		return nil
	case r.typ == "string":
		if _, ok := str(x); !ok {
			return fmt.Errorf("%s is not a string", where)
		}
	case r.typ == "non-empty string":
		if !nonEmptyString(x) {
			return fmt.Errorf("%s is not a non-empty string", where)
		}
	case r.typ == "boolean":
		if _, ok := x.(bool); !ok {
			return fmt.Errorf("%s is not a boolean", where)
		}
	case r.typ == "integer, 0 or more":
		n, ok := x.(number)
		if !ok || !intRE.MatchString(string(n)) {
			return fmt.Errorf("%s is not an integer of 0 or more", where)
		}
	case r.typ == "digest":
		if _, ok := digestOf(x); !ok {
			return fmt.Errorf("%s is not a digest", where)
		}
	case r.typ == "timestamp":
		s, ok := str(x)
		if !ok || !tsRE.MatchString(s) {
			return fmt.Errorf("%s is not a timestamp", where)
		}
	case r.typ == "typedDigest":
		return nil // checked in the form step 7 gives, by typedDigests
	case r.typ == `"0.1." and one or more digits`:
		s, ok := str(x)
		if !ok || !schemaVersionRE.MatchString(s) {
			return fmt.Errorf("%s is not \"0.1.\" and one or more digits", where)
		}
	case r.typ == "relationDigest":
		// Since revision -07: an object whose only members are digestAlgorithm, jcs-sha256-v1, and digest, hex64.
		m, ok := obj(x)
		if !ok || len(m) != 2 {
			return fmt.Errorf("%s is not a relationDigest", where)
		}
		if a, _ := str(m["digestAlgorithm"]); a != "jcs-sha256-v1" {
			return fmt.Errorf("%s.digestAlgorithm is not jcs-sha256-v1", where)
		}
		if s, ok := str(m["digest"]); !ok || !hex64RE.MatchString(s) {
			return fmt.Errorf("%s.digest is not 64 lowercase hexadecimal digits", where)
		}
	case strings.HasPrefix(r.typ, "(") && fieldNotes[r.typ] != "":
		s, _ := str(x)
		for _, w := range enumOf(fieldNotes[r.typ]) {
			if s == w {
				return nil
			}
		}
		return fmt.Errorf("%s is not one of the values of note %s", where, r.typ)
	case wordRE.MatchString(r.typ):
		if s, _ := str(x); s != r.typ {
			return fmt.Errorf("%s is not %s", where, r.typ)
		}
	default:
		return fmt.Errorf("unknown type %q", r.typ)
	}
	return nil
}

var decisionTable = newTableChecker(decisionFieldRules)
var outcomeTable = newTableChecker(outcomeFieldRules)
