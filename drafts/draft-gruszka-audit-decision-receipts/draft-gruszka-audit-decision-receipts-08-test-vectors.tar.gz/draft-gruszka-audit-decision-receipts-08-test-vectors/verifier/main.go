// Command adrverify checks decision and outcome receipts by the procedure of Section 3 of
// draft-gruszka-audit-decision-receipts-00 (an early revision),
// changed for the text of -04: the digest and timestamp members are the paths that
// Section 3.2 step 7 and Section 3.4 step 3 now list, evidenceRefs[].typedDigest is checked in the form
// step 7 gives, and -consumed adds the check of Section 4 for a relying party. Changed later: step 7
// and step 3 also apply the field tables of Section 3.8 (fieldrules.go, read from the TXT of that revision), and the
// relying-party check of -consumed runs after the receipt has passed and reports separately from it. Changed in
// a later revision: step 1 checks first that the envelope bytes are valid UTF-8, as the new wording of step 1 says; the
// strict JSON reader already rejected duplicate member names in any object. Changed in draft -05: step 1
// rejects envelope bytes that begin with a byte order mark, and the consumption state of -consumed may be an object
// of generations (Section 4, item 4), and failures of the outcome envelope and statement are reported as steps 1 and 2
// of Section 3.4. Changed later: a fraction of a second has one to six digits. Changed later
// payload in step 2 and sig in step 3 are decoded as base64 with the alphabet and padding of Section 4
// of RFC 4648, without line breaks or other characters and with pad bits of zero; step 6 checks digest.sha256 of the
// subject entry and no other member of the Statement, the subject entry or its digest.
// Changed for revision -07: integers written with digits only keep the range of Section 2.2 of RFC 7493, every
// other finite number follows the number serialization of RFC 8785, and
// -received adds the check of item 2 of Section 4 against the earliest validUntil of the copies received.
// Changed in delivery -42: -held adds the third check of Section 3.5 over the receipts an Auditor holds; an entry of
// relationships with relation supersedes must name, by the digest of targetReceiptDigest, the content root of a
// receipt held, and where it has targetSubjectDigest, that digest must be the subject digest of that receipt.
// Changed in delivery -47: step 1 also requires every entry of signatures to be an object whose member sig is a
// string; step 3 does not verify the signature of the other entries.
// Changed in delivery -47 (P4): the third check of Section 3.5 also applies to an outcome receipt (-held in outcome);
// a receipt held there is a decision receipt under the decision maker's key or an outcome receipt under the
// outcome-signing key.
// Changed in delivery -51 (P5 OZ-AUDIT-50-M1): each -held names the expected signing key of its receipt as
// KEY:FILE. Before any predecessor is looked up, every supplied held envelope must pass, under its expected key,
// steps 1 to 6 of Section 3.2 as a decision receipt or steps 1 to 5 of Section 3.2 and step 2 of Section 3.4 as an
// outcome receipt, in the decision and the outcome command alike; either kind may be a predecessor of either kind.
// No other check of Sections 3.2 to 3.4 is applied to a held receipt. Where a held envelope fails these preliminary
// checks, the input is invalid: the third check gives no result and the exit code is 2. A predecessor absent from a
// valid set of held receipts is a failure of the third check, with exit code 4. A run without -held does not run
// the third check and prints no line for it.
// Changed in delivery -53 (P5 OZ-AUDIT-50-M1, Nachtrag 22): the preliminary checks also require, for every supplied
// held envelope, that where its predicate has relationships, the member and its entries satisfy the field rules of
// Section 3.8 for relationships, the same rules that step 7 of Section 3.2 and step 3 of Section 3.4 apply to it
// (heldRelationships). A held envelope that fails them makes the input invalid, with exit code 2, so the following
// of supersedes meets only entries in the form of Section 3.8.
// Changed for the test package CLOUD-DRAFT-AUDIT-08-PAKET-01: -second adds the second check of Section 3.5 over the
// same receipts held, after the same preliminary checks: no outcome receipt held with status executed may name, in
// decisionRef, the content root of a decision receipt held whose verdict is not ALLOW. It runs only with -second,
// after the third check, and exits with code 5 where it fails; a run without -second prints what it printed before.
// It is written from the text of that document only and uses the Go standard library; it shares no
// code with proofbundle. It implements the rules the text states; the complete field rules of the
// predicate references beyond those are not implemented.
//
//	adrverify decision -policy FILE -pub B64 -signer ID -t T [-aud A] [-nonce N]
//	                   [-case approval|declined|executed] [-action FILE] [-approval FILE] ENVELOPE
//	                   [-consumed FILE]   relying-party check of Section 4, not part of verifying the receipt
//	                   [-held KEY:FILE ...] third check of Section 3.5 over the receipts held, not part of
//	                                      verifying the receipt; KEY is the expected signing key of the held
//	                                      receipt in base64; exit code 4 where the check fails and 2 where a held
//	                                      envelope fails the preliminary checks
//	adrverify outcome  -policy FILE -pub B64 -executor-id ID -decision ENVELOPE -decision-pub B64
//	                   -decision-signer ID -t T [-decision-aud A] [-decision-nonce N] [-effect FILE] ENVELOPE
//	                   [-held KEY:FILE ...] third check of Section 3.5 over the receipts held, as for decision
//	                   [-second]            with -held, in either command: also the second check of Section 3.5
//	                                      over the receipts held; exit code 5 where it fails
//
// The consumed file is a JSON array of approval identities {"approvalId", "actionDigest": {"sha256"}, "session"}
// that the relying party has already honoured (Section 4, items 1 and 2). It is a check of the relying party,
// separate from the verification of the receipt: it runs only with -case approval and only after the receipt
// has passed, and its result is printed on its own line.
// The policy file is {"decision": {"<key b64>": ["<decisionMaker.id>"]}, "outcome": {"<key b64>": ["<executor.id>"]}}.
// Exit code 0 means pass, 1 means a failure of the receipt (the line names the step), 2 a wrong call or invalid
// input, 3 that the receipt passed but the relying-party check of Section 4 refuses to honour its approval, 4
// that the receipt passed but the third check of Section 3.5 fails, and 5 that the receipt passed and the third
// check, where run, passed, but the second check of Section 3.5 fails.
package main

import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"math"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
	"unicode/utf8"
)

const (
	payloadType   = "application/vnd.in-toto+json"
	statementType = "https://in-toto.io/Statement/v1"
	decisionType  = "https://b7n0de.com/proofbundle/predicates/decision-receipt/v0.1"
	outcomeType   = "https://b7n0de.com/proofbundle/predicates/action-outcome/v0.1"
)

// ---------------------------------------------------------------- a strict JSON reader

type number string // the literal text of a JSON number

type parser struct {
	b   []byte
	pos int
}

func parseJSON(b []byte) (any, error) {
	p := &parser{b: b}
	p.ws()
	v, err := p.value(0)
	if err != nil {
		return nil, err
	}
	p.ws()
	if p.pos != len(p.b) {
		return nil, fmt.Errorf("trailing bytes at %d", p.pos)
	}
	return v, nil
}

func (p *parser) ws() {
	for p.pos < len(p.b) && (p.b[p.pos] == ' ' || p.b[p.pos] == '\t' || p.b[p.pos] == '\n' || p.b[p.pos] == '\r') {
		p.pos++
	}
}

func (p *parser) value(depth int) (any, error) {
	if depth > 64 {
		return nil, errors.New("nesting too deep")
	}
	if p.pos >= len(p.b) {
		return nil, errors.New("unexpected end")
	}
	switch c := p.b[p.pos]; {
	case c == '{':
		p.pos++
		obj := map[string]any{}
		p.ws()
		if p.pos < len(p.b) && p.b[p.pos] == '}' {
			p.pos++
			return obj, nil
		}
		for {
			p.ws()
			k, err := p.str()
			if err != nil {
				return nil, err
			}
			if _, dup := obj[k]; dup {
				return nil, fmt.Errorf("duplicate member name %q", k)
			}
			p.ws()
			if p.pos >= len(p.b) || p.b[p.pos] != ':' {
				return nil, errors.New("expected ':'")
			}
			p.pos++
			p.ws()
			v, err := p.value(depth + 1)
			if err != nil {
				return nil, err
			}
			obj[k] = v
			p.ws()
			if p.pos < len(p.b) && p.b[p.pos] == ',' {
				p.pos++
				continue
			}
			if p.pos < len(p.b) && p.b[p.pos] == '}' {
				p.pos++
				return obj, nil
			}
			return nil, errors.New("expected ',' or '}'")
		}
	case c == '[':
		p.pos++
		arr := []any{}
		p.ws()
		if p.pos < len(p.b) && p.b[p.pos] == ']' {
			p.pos++
			return arr, nil
		}
		for {
			p.ws()
			v, err := p.value(depth + 1)
			if err != nil {
				return nil, err
			}
			arr = append(arr, v)
			p.ws()
			if p.pos < len(p.b) && p.b[p.pos] == ',' {
				p.pos++
				continue
			}
			if p.pos < len(p.b) && p.b[p.pos] == ']' {
				p.pos++
				return arr, nil
			}
			return nil, errors.New("expected ',' or ']'")
		}
	case c == '"':
		return p.str()
	case bytes.HasPrefix(p.b[p.pos:], []byte("true")):
		p.pos += 4
		return true, nil
	case bytes.HasPrefix(p.b[p.pos:], []byte("false")):
		p.pos += 5
		return false, nil
	case bytes.HasPrefix(p.b[p.pos:], []byte("null")):
		p.pos += 4
		return nil, nil
	default:
		m := regexp.MustCompile(`^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?`).Find(p.b[p.pos:])
		if m == nil {
			return nil, fmt.Errorf("unexpected byte at %d", p.pos)
		}
		p.pos += len(m)
		return number(m), nil
	}
}

func (p *parser) str() (string, error) {
	if p.pos >= len(p.b) || p.b[p.pos] != '"' {
		return "", errors.New("expected string")
	}
	p.pos++
	var sb strings.Builder
	for {
		if p.pos >= len(p.b) {
			return "", errors.New("unterminated string")
		}
		c := p.b[p.pos]
		switch {
		case c == '"':
			p.pos++
			return sb.String(), nil
		case c < 0x20:
			return "", errors.New("control character in string")
		case c == '\\':
			if p.pos+1 >= len(p.b) {
				return "", errors.New("bad escape")
			}
			e := p.b[p.pos+1]
			p.pos += 2
			switch e {
			case '"', '\\', '/':
				sb.WriteByte(e)
			case 'b':
				sb.WriteByte('\b')
			case 'f':
				sb.WriteByte('\f')
			case 'n':
				sb.WriteByte('\n')
			case 'r':
				sb.WriteByte('\r')
			case 't':
				sb.WriteByte('\t')
			case 'u':
				r, err := p.hex4()
				if err != nil {
					return "", err
				}
				if utf16.IsSurrogate(r) {
					if r >= 0xDC00 || !bytes.HasPrefix(p.b[p.pos:], []byte(`\u`)) {
						return "", errors.New("lone surrogate")
					}
					p.pos += 2
					r2, err := p.hex4()
					if err != nil {
						return "", err
					}
					r = utf16.DecodeRune(r, r2)
					if r == utf8.RuneError {
						return "", errors.New("lone surrogate")
					}
				}
				sb.WriteRune(r)
			default:
				return "", errors.New("bad escape")
			}
		default:
			r, size := utf8.DecodeRune(p.b[p.pos:])
			if r == utf8.RuneError && size <= 1 {
				return "", errors.New("invalid UTF-8")
			}
			sb.Write(p.b[p.pos : p.pos+size])
			p.pos += size
		}
	}
}

func (p *parser) hex4() (rune, error) {
	if p.pos+4 > len(p.b) {
		return 0, errors.New("short \\u escape")
	}
	v, err := strconv.ParseUint(string(p.b[p.pos:p.pos+4]), 16, 32)
	if err != nil {
		return 0, errors.New("bad \\u escape")
	}
	p.pos += 4
	return rune(v), nil
}

// ---------------------------------------------------------------- RFC 8785 serialization

func canon(v any, out *bytes.Buffer) error {
	switch x := v.(type) {
	case nil:
		out.WriteString("null")
	case bool:
		if x {
			out.WriteString("true")
		} else {
			out.WriteString("false")
		}
	case number:
		// Since revision -07: a number written with digits only, without fraction or exponent, fails if its
		// magnitude is greater than 9007199254740991 (step 4, Section 2.2 of RFC 7493), as before. Every other
		// number is read as an IEEE 754 double and written as RFC 8785 writes it (Section 3.2.2.3, the number
		// serialization of ECMAScript), where this verifier used to fail closed.
		if s := string(x); intLiteral.MatchString(s) {
			if n, err := strconv.ParseInt(s, 10, 64); err != nil || n > 9007199254740991 || n < -9007199254740991 {
				return fmt.Errorf("number %s is outside the safe integer range", s)
			}
		}
		f, err := strconv.ParseFloat(string(x), 64)
		if err != nil || math.IsInf(f, 0) || math.IsNaN(f) {
			return fmt.Errorf("number %s is not a finite IEEE 754 double", string(x))
		}
		out.WriteString(esNumber(f))
	case string:
		canonString(x, out)
	case []any:
		out.WriteByte('[')
		for i, e := range x {
			if i > 0 {
				out.WriteByte(',')
			}
			if err := canon(e, out); err != nil {
				return err
			}
		}
		out.WriteByte(']')
	case map[string]any:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Slice(keys, func(i, j int) bool { return utf16Less(keys[i], keys[j]) })
		out.WriteByte('{')
		for i, k := range keys {
			if i > 0 {
				out.WriteByte(',')
			}
			canonString(k, out)
			out.WriteByte(':')
			if err := canon(x[k], out); err != nil {
				return err
			}
		}
		out.WriteByte('}')
	default:
		return fmt.Errorf("unexpected value %T", v)
	}
	return nil
}

var intLiteral = regexp.MustCompile(`^-?(0|[1-9][0-9]*)$`)

// esNumber writes a finite double as ECMAScript Number::toString does, which RFC 8785 uses: the shortest digits
// that round-trip, in plain notation for exponents from -7 to 20 and in exponent notation otherwise.
func esNumber(f float64) string {
	if f == 0 {
		return "0"
	}
	if f < 0 {
		return "-" + esNumber(-f)
	}
	e := strconv.FormatFloat(f, 'e', -1, 64)
	i := strings.IndexByte(e, 'e')
	digits := strings.Replace(e[:i], ".", "", 1)
	exp, _ := strconv.Atoi(e[i+1:])
	k, n := len(digits), exp+1
	switch {
	case k <= n && n <= 21:
		return digits + strings.Repeat("0", n-k)
	case 0 < n && n <= 21:
		return digits[:n] + "." + digits[n:]
	case -6 < n && n <= 0:
		return "0." + strings.Repeat("0", -n) + digits
	}
	sign := "+"
	if n-1 < 0 {
		sign = "-"
	}
	ex := strconv.Itoa(abs(n - 1))
	if k == 1 {
		return digits + "e" + sign + ex
	}
	return digits[:1] + "." + digits[1:] + "e" + sign + ex
}

func abs(i int) int {
	if i < 0 {
		return -i
	}
	return i
}

func canonString(s string, out *bytes.Buffer) {
	out.WriteByte('"')
	for _, r := range s {
		switch r {
		case '"':
			out.WriteString(`\"`)
		case '\\':
			out.WriteString(`\\`)
		case '\b':
			out.WriteString(`\b`)
		case '\f':
			out.WriteString(`\f`)
		case '\n':
			out.WriteString(`\n`)
		case '\r':
			out.WriteString(`\r`)
		case '\t':
			out.WriteString(`\t`)
		default:
			if r < 0x20 {
				fmt.Fprintf(out, `\u%04x`, r)
			} else {
				out.WriteRune(r)
			}
		}
	}
	out.WriteByte('"')
}

func utf16Less(a, b string) bool {
	ua, ub := utf16.Encode([]rune(a)), utf16.Encode([]rune(b))
	for i := 0; i < len(ua) && i < len(ub); i++ {
		if ua[i] != ub[i] {
			return ua[i] < ub[i]
		}
	}
	return len(ua) < len(ub)
}

func jcs(v any) ([]byte, error) {
	var b bytes.Buffer
	err := canon(v, &b)
	return b.Bytes(), err
}

// ---------------------------------------------------------------- helpers

type fail struct{ step, msg string }

func (f fail) Error() string { return f.step + ": " + f.msg }

func failf(step, format string, a ...any) error { return fail{step, fmt.Sprintf(format, a...)} }

func shaHex(b []byte) string { s := sha256.Sum256(b); return hex.EncodeToString(s[:]) }

var hex64 = regexp.MustCompile(`^[0-9a-f]{64}$`)

// Since a later revision: a fraction of a second has one to six digits.
var rfc3339z = regexp.MustCompile(`^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?Z$`)

func obj(v any) (map[string]any, bool) { m, ok := v.(map[string]any); return m, ok }
func str(v any) (string, bool)         { s, ok := v.(string); return s, ok }

func get(m map[string]any, path ...string) any {
	var cur any = m
	for _, k := range path {
		o, ok := obj(cur)
		if !ok {
			return nil
		}
		cur = o[k]
	}
	return cur
}

func getStr(m map[string]any, path ...string) string { s, _ := str(get(m, path...)); return s }

// digestProblem names what is wrong with the digest object at path, or returns "" if it is {"sha256": hex64}. Only the
// message depends on it; whether the step fails is decided by digestOf as before.
func digestProblem(m map[string]any, path ...string) string {
	name := strings.Join(path, ".")
	parent, _ := obj(get(m, path[:len(path)-1]...))
	v, present := parent[path[len(path)-1]]
	if _, ok := digestOf(v); ok {
		return ""
	}
	if !present {
		return name + " missing"
	}
	o, ok := obj(v)
	if !ok || len(o) != 1 {
		return name + " is not an object with the one member sha256"
	}
	s, ok := str(o["sha256"])
	if !ok {
		return name + ".sha256 is not a string"
	}
	if hex64.MatchString(strings.ToLower(s)) {
		return name + ".sha256 has upper-case hexadecimal digits"
	}
	return name + ".sha256 is not 64 lowercase hexadecimal digits"
}

func digestOf(v any) (string, bool) {
	o, ok := obj(v)
	if !ok || len(o) != 1 {
		return "", false
	}
	s, ok := str(o["sha256"])
	return s, ok && hex64.MatchString(s)
}

// strictB64 decodes base64 in the form of step 2 of Section 3.2 (since a later revision): only the alphabet of Section 4
// of RFC 4648 and its padding, a length that is a multiple of four, no line breaks or other characters, and pad bits
// of zero (Section 3.5 of RFC 4648). Go's decoder ignores CR and LF, so they are rejected before it runs.
var b64Form = regexp.MustCompile(`^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$`)

func strictB64(s string) ([]byte, error) {
	if !b64Form.MatchString(s) {
		return nil, fmt.Errorf("characters or padding outside Section 4 of RFC 4648")
	}
	b, err := base64.StdEncoding.Strict().DecodeString(s)
	if err != nil {
		return nil, fmt.Errorf("pad bits are not zero")
	}
	return b, nil
}

func parseTime(s string) (time.Time, error) {
	if !rfc3339z.MatchString(s) {
		return time.Time{}, fmt.Errorf("%q is not RFC 3339 UTC with Z", s)
	}
	return time.Parse(time.RFC3339Nano, s)
}

var schemaVersionRE = regexp.MustCompile(`^0\.1\.[0-9]+$`)

func nonEmptyString(v any) bool { s, ok := str(v); return ok && s != "" }

// Digest and timestamp members by full path, as Section 3.2 step 7 and Section 3.4 step 3 list them;
// "[]" stands for each entry of an array.
var decisionDigestPaths = []string{"agent.configurationDigest", "principal.authnContextRef.digest",
	"proposedAction.target.digest", "proposedAction.parametersDigest", "proposedAction.parametersSchemaRef.digest",
	"inputSnapshot[].digest", "policyBoundary.policyDigest", "evidenceRefs[].digest", "evidenceRefs[].artifactDigest",
	"actionOutcome.outcomeRef.digest"}
var decisionTimePaths = []string{"decidedAt", "recordedAt", "policyBoundary.validFrom", "policyBoundary.validUntil",
	"actionOutcome.performedAt", "validity.expiresAt", "relationships[].declaredAt"}
var outcomeDigestPaths = []string{"decisionRef", "requestedActionDigest", "actualActionDigest", "responseDigest",
	"effectDigest", "receiverRefs[].digest", "receiverRefs[].artifactDigest"}
var outcomeTimePaths = []string{"performedAt", "recordedAt", "relationships[].declaredAt"}

type found struct {
	path string
	val  any
}

// at returns the values present at a dotted path; a segment ending in [] fans out over an array.
func at(v any, path string) []found {
	out := []found{{"predicate", v}}
	for _, seg := range strings.Split(path, ".") {
		arr := strings.HasSuffix(seg, "[]")
		name := strings.TrimSuffix(seg, "[]")
		var next []found
		for _, f := range out {
			m, ok := obj(f.val)
			if !ok {
				continue
			}
			x, present := m[name]
			if !present {
				continue
			}
			if !arr {
				next = append(next, found{f.path + "." + name, x})
				continue
			}
			if xs, ok := x.([]any); ok {
				for i, e := range xs {
					next = append(next, found{fmt.Sprintf("%s.%s[%d]", f.path, name, i), e})
				}
			}
		}
		out = next
	}
	return out
}

// digestPaths requires each non-null value at the listed paths to be {"sha256": hex64}.
func digestPaths(pred map[string]any, paths []string) error {
	for _, p := range paths {
		for _, f := range at(pred, p) {
			if f.val == nil {
				continue
			}
			if _, ok := digestOf(f.val); !ok {
				return fmt.Errorf("%s is not a sha256 digest object", f.path)
			}
		}
	}
	return nil
}

// timePaths requires each non-null value at the listed paths to be an RFC 3339 UTC time with Z.
func timePaths(pred map[string]any, paths []string) error {
	for _, p := range paths {
		for _, f := range at(pred, p) {
			if f.val == nil {
				continue
			}
			s, ok := str(f.val)
			if !ok {
				return fmt.Errorf("%s is not a string", f.path)
			}
			if _, err := parseTime(s); err != nil {
				return fmt.Errorf("%s: %v", f.path, err)
			}
		}
	}
	return nil
}

var hex64RE = regexp.MustCompile(`^[0-9a-f]{64}$`)

// typedDigests checks evidenceRefs[].typedDigest in the form Section 3.2 step 7 gives.
func typedDigests(pred map[string]any) error {
	for _, f := range at(pred, "evidenceRefs[].typedDigest") {
		m, ok := obj(f.val)
		if !ok {
			return fmt.Errorf("%s is not an object", f.path)
		}
		for k := range m {
			if k != "type" && k != "purpose" && k != "digestAlgorithm" && k != "digest" {
				return fmt.Errorf("%s has the member %s", f.path, k)
			}
		}
		if !nonEmptyString(m["type"]) {
			return fmt.Errorf("%s.type is not a non-empty string", f.path)
		}
		if _, has := m["purpose"]; has && !nonEmptyString(m["purpose"]) {
			return fmt.Errorf("%s.purpose is not a non-empty string", f.path)
		}
		if s, _ := str(m["digestAlgorithm"]); s != "jcs-sha256-v1" {
			return fmt.Errorf("%s.digestAlgorithm is not jcs-sha256-v1", f.path)
		}
		if s, ok := str(m["digest"]); !ok || !hex64RE.MatchString(s) {
			return fmt.Errorf("%s.digest is not 64 lowercase hexadecimal digits", f.path)
		}
	}
	return nil
}

// checkDigests (early revisions) required every non-null member named digest or ending in Digest to be
// {"sha256": hex64}; since a later revision the listed paths above are used instead. Kept for comparison only.
func checkDigests(v any, where string) error {
	switch x := v.(type) {
	case map[string]any:
		for k, e := range x {
			if (k == "digest" || strings.HasSuffix(k, "Digest")) && e != nil {
				if _, ok := digestOf(e); !ok {
					return fmt.Errorf("%s.%s is not a sha256 digest object", where, k)
				}
			}
			if err := checkDigests(e, where+"."+k); err != nil {
				return err
			}
		}
	case []any:
		for i, e := range x {
			if err := checkDigests(e, fmt.Sprintf("%s[%d]", where, i)); err != nil {
				return err
			}
		}
	}
	return nil
}

// checkNulls rejects a null anywhere below v except at the dotted paths in allowed.
func checkNulls(v any, where string, allowed map[string]bool) error {
	switch x := v.(type) {
	case nil:
		if !allowed[where] {
			return fmt.Errorf("%s is null where no rule permits it", where)
		}
	case map[string]any:
		for k, e := range x {
			if err := checkNulls(e, where+"."+k, allowed); err != nil {
				return err
			}
		}
	case []any:
		for i, e := range x {
			if err := checkNulls(e, fmt.Sprintf("%s[%d]", where, i), allowed); err != nil {
				return err
			}
		}
	}
	return nil
}

func members(pred map[string]any, required, optional []string) error {
	allowed := map[string]bool{}
	for _, k := range append(append([]string{}, required...), optional...) {
		allowed[k] = true
	}
	for _, k := range required {
		if _, ok := pred[k]; !ok {
			return fmt.Errorf("missing member %s", k)
		}
	}
	for k := range pred {
		if !allowed[k] {
			return fmt.Errorf("member %s is not allowed", k)
		}
	}
	return nil
}

func timestamps(pred map[string]any, paths [][]string) error {
	for _, p := range paths {
		if v := get(pred, p...); v != nil {
			s, ok := str(v)
			if !ok {
				return fmt.Errorf("%s is not a string", strings.Join(p, "."))
			}
			if _, err := parseTime(s); err != nil {
				return err
			}
		}
	}
	return nil
}

// ---------------------------------------------------------------- trust policy (Section 3.1)

// policy maps a base64 public key to the identities it may attest, for decisions and for outcomes.
type policy struct {
	Decision map[string][]string `json:"decision"`
	Outcome  map[string][]string `json:"outcome"`
}

func loadPolicy(path string) policy {
	b, err := os.ReadFile(path)
	if err != nil {
		fmt.Fprintln(os.Stderr, "policy:", err)
		os.Exit(2)
	}
	v, err := parseJSON(b)
	o, ok := obj(v)
	if err != nil || !ok {
		fmt.Fprintln(os.Stderr, "policy is not a JSON object")
		os.Exit(2)
	}
	read := func(m any) map[string][]string {
		out := map[string][]string{}
		mo, _ := obj(m)
		for k, ids := range mo {
			arr, _ := ids.([]any)
			for _, x := range arr {
				if s, ok := str(x); ok {
					out[k] = append(out[k], s)
				}
			}
		}
		return out
	}
	return policy{Decision: read(o["decision"]), Outcome: read(o["outcome"])}
}

func permits(m map[string][]string, pubB64, id string) bool {
	for _, x := range m[pubB64] {
		if x == id {
			return true
		}
	}
	return false
}

// ---------------------------------------------------------------- steps 1 to 6 (shared)

type receipt struct {
	P         []byte
	R         string
	Statement map[string]any
	Pred      map[string]any
}

func envelopeSteps(envBytes []byte, pub ed25519.PublicKey, wantType string) (*receipt, error) {
	// Step 1: envelope (wording of a later revision): valid UTF-8, one JSON object, no duplicate member names in any
	// object (the strict reader above rejects them), with payload, payloadType and signatures
	if !utf8.Valid(envBytes) {
		return nil, failf("step 1", "envelope is not valid UTF-8")
	}
	if bytes.HasPrefix(envBytes, []byte("\xef\xbb\xbf")) { // wording of draft -05
		return nil, failf("step 1", "envelope begins with a byte order mark")
	}
	ev, err := parseJSON(envBytes)
	if err != nil {
		return nil, failf("step 1", "envelope is not JSON: %v", err)
	}
	env, ok := obj(ev)
	if !ok {
		return nil, failf("step 1", "envelope is not an object")
	}
	pt, ok1 := str(env["payloadType"])
	pl, ok2 := str(env["payload"])
	sigs, ok3 := env["signatures"].([]any)
	if !ok1 || !ok2 || !ok3 {
		return nil, failf("step 1", "envelope lacks payload, payloadType or signatures")
	}
	if pt != payloadType {
		return nil, failf("step 1", "payloadType %q", pt)
	}
	// since delivery -47 (P2): every entry of signatures is an object whose member sig is a string; only the
	// signature of the other entries is not verified in step 3
	for i, s := range sigs {
		so, ok := obj(s)
		if !ok {
			return nil, failf("step 1", "signatures[%d] is not an object", i)
		}
		if _, ok := str(so["sig"]); !ok {
			return nil, failf("step 1", "signatures[%d] has no member sig whose value is a string", i)
		}
	}
	// Step 2: payload bytes
	P, err := strictB64(pl)
	if err != nil {
		return nil, failf("step 2", "payload is not base64 in the form of step 2: %v", err)
	}
	// Step 3: signature over PAE
	t := []byte(pt)
	pae := []byte(fmt.Sprintf("DSSEv1 %d %s %d ", len(t), t, len(P)))
	pae = append(pae, P...)
	verified := false
	for _, s := range sigs {
		so, ok := obj(s)
		if !ok {
			continue
		}
		sb64, ok := str(so["sig"])
		if !ok {
			continue
		}
		sig, err := strictB64(sb64)
		if err != nil || len(sig) != ed25519.SignatureSize {
			continue
		}
		if ed25519.Verify(pub, pae, sig) {
			verified = true
			break
		}
	}
	if !verified {
		return nil, failf("step 3", "no signature verifies under the expected key")
	}
	// Step 4: canonical form
	if !utf8.Valid(P) {
		return nil, failf("step 4", "payload is not UTF-8")
	}
	sv, err := parseJSON(P)
	if err != nil {
		return nil, failf("step 4", "payload does not parse: %v", err)
	}
	c, err := jcs(sv)
	if err != nil {
		return nil, failf("step 4", "%v", err)
	}
	if !bytes.Equal(c, P) {
		return nil, failf("step 4", "payload is not its own RFC 8785 serialization")
	}
	// Step 5: content root
	rc := &receipt{P: P, R: shaHex(P)}
	// Step 6: statement
	st, ok := obj(sv)
	if !ok {
		return nil, failf("step 6", "payload is not an object")
	}
	rc.Statement = st
	if s, _ := str(st["_type"]); s != statementType {
		return nil, failf("step 6", "_type %q", s)
	}
	if s, _ := str(st["predicateType"]); s != wantType {
		return nil, failf("step 6", "predicateType %q", s)
	}
	pred, ok := obj(st["predicate"])
	if !ok {
		return nil, failf("step 6", "predicate is not an object")
	}
	rc.Pred = pred
	subj, ok := st["subject"].([]any)
	if !ok || len(subj) != 1 {
		return nil, failf("step 6", "subject must have one entry")
	}
	so, _ := obj(subj[0])
	// since a later revision: only digest.sha256 is checked, other members of the subject entry and its digest are not
	d, ok := str(get(so, "digest", "sha256"))
	pc, err := jcs(pred)
	if err != nil || !ok || d != shaHex(pc) {
		return nil, failf("step 6", "subject digest is not SHA-256 of the predicate's RFC 8785 form")
	}
	return rc, nil
}

// ---------------------------------------------------------------- decision receipt (Sections 3.2, 3.3)

type decisionArgs struct {
	pub                  ed25519.PublicKey
	pubB64               string
	pol                  policy
	signer, aud, nonce   string
	when                 time.Time
	kase                 string
	actionFile, apprFile string
}

var decisionRequired = []string{"schemaVersion", "decisionId", "decisionType", "decidedAt", "decisionMaker",
	"agent", "principal", "proposedAction", "inputSnapshot", "policyBoundary", "evidenceRefs", "decision",
	"notChecked", "decisionChangeConditions", "privacy", "validity"}
var decisionOptional = []string{"recordedAt", "delegationRefs", "actionOutcome", "traceContext", "relationships"}

// Nulls permitted in a decision predicate: actionOutcome.performedAt and actionOutcome.outcomeRef, which the
// field rules allow as null and Section 3.3 (Case 2) names.
var decisionNulls = map[string]bool{"predicate.actionOutcome.performedAt": true, "predicate.actionOutcome.outcomeRef": true,
	"predicate.decisionMaker.version": true} // Null yes in the table of Section 3.8

func verifyDecision(envBytes []byte, a decisionArgs) (*receipt, error) {
	// Section 3.1: the key must be one the trust policy selects for the expected decision maker
	if !permits(a.pol.Decision, a.pubB64, a.signer) {
		return nil, failf("section 3.1", "the trust policy does not select this key for %q", a.signer)
	}
	rc, err := envelopeSteps(envBytes, a.pub, decisionType)
	if err != nil {
		return nil, err
	}
	d := rc.Pred
	// Step 7: members, types and forms
	if err := members(d, decisionRequired, decisionOptional); err != nil {
		return nil, failf("step 7", "%v", err)
	}
	for _, k := range []string{"decisionMaker", "agent", "principal", "proposedAction", "policyBoundary", "decision",
		"privacy", "validity"} {
		if _, ok := obj(d[k]); !ok {
			return nil, failf("step 7", "%s is not an object", k)
		}
	}
	for _, p := range [][]string{{"decisionId"}, {"decisionMaker", "id"}, {"agent", "id"}, {"principal", "id"}} {
		if !nonEmptyString(get(d, p...)) {
			return nil, failf("step 7", "%s is not a non-empty string", strings.Join(p, "."))
		}
	}
	for _, k := range []string{"inputSnapshot", "evidenceRefs", "notChecked", "decisionChangeConditions"} {
		if _, ok := d[k].([]any); !ok {
			return nil, failf("step 7", "%s is not an array", k)
		}
	}
	rcodes, ok := get(d, "decision", "reasonCodes").([]any)
	if !ok || len(rcodes) == 0 {
		return nil, failf("step 7", "decision.reasonCodes is not a non-empty array")
	}
	for _, x := range rcodes {
		if !nonEmptyString(x) {
			return nil, failf("step 7", "decision.reasonCodes holds a value that is not a non-empty string")
		}
	}
	if p := digestProblem(d, "policyBoundary", "policyDigest"); p != "" {
		return nil, failf("step 7", "%s", p)
	}
	if s, ok := str(d["schemaVersion"]); !ok || !schemaVersionRE.MatchString(s) {
		return nil, failf("step 7", "schemaVersion %v", d["schemaVersion"])
	}
	if getStr(d, "decisionType") != "preActionAuthorization" {
		return nil, failf("step 7", "decisionType %q", getStr(d, "decisionType"))
	}
	if err := timePaths(d, decisionTimePaths); err != nil {
		return nil, failf("step 7", "%v", err)
	}
	if err := digestPaths(d, decisionDigestPaths); err != nil {
		return nil, failf("step 7", "%v", err)
	}
	if err := typedDigests(d); err != nil {
		return nil, failf("step 7", "%v", err)
	}
	if err := checkNulls(d, "predicate", decisionNulls); err != nil {
		return nil, failf("step 7", "%v", err)
	}
	if err := decisionTable.obj(d, "", "predicate"); err != nil {
		return nil, failf("step 7", "%v", err)
	}
	// Step 8: signer
	if getStr(d, "decisionMaker", "id") != a.signer {
		return nil, failf("step 8", "decisionMaker.id %q is not %q", getStr(d, "decisionMaker", "id"), a.signer)
	}
	// Step 9: validity
	aud, okA := get(d, "validity", "audience").([]any)
	okA = okA && len(aud) > 0
	for _, x := range aud {
		okA = okA && nonEmptyString(x)
	}
	nonce, okN := str(get(d, "validity", "nonce"))
	exp, okE := str(get(d, "validity", "expiresAt"))
	if !okA || !okN || nonce == "" || !okE {
		return nil, failf("step 9", "validity lacks a non-empty audience array, a non-empty nonce or expiresAt")
	}
	decided, _ := parseTime(getStr(d, "decidedAt"))
	expires, _ := parseTime(exp)
	if decided.After(a.when) || !a.when.Before(expires) {
		return nil, failf("step 9", "T %s is not within decidedAt <= T < expiresAt", a.when.Format(time.RFC3339))
	}
	if a.aud != "" {
		found := false
		for _, x := range aud {
			if s, _ := str(x); s == a.aud {
				found = true
			}
		}
		if !found {
			return nil, failf("step 9", "audience does not contain %q", a.aud)
		}
	}
	if a.nonce != "" && nonce != a.nonce {
		return nil, failf("step 9", "nonce %q is not %q", nonce, a.nonce)
	}
	// Step 10: action bytes
	pd, _ := digestOf(get(d, "proposedAction", "parametersDigest"))
	if a.actionFile != "" {
		b, err := os.ReadFile(a.actionFile)
		if err != nil {
			return nil, failf("step 10", "%v", err)
		}
		if shaHex(b) != pd {
			return nil, failf("step 10", "action bytes do not match parametersDigest")
		}
	}
	// Section 3.3, checks per case
	verdict := getStr(d, "decision", "verdict")
	switch a.kase {
	case "approval":
		if verdict != "ALLOW" {
			return nil, failf("case 1", "verdict %q", verdict)
		}
		has := false
		for _, x := range rcodes {
			if s, _ := str(x); s == "user_approval" {
				has = true
			}
		}
		if !has {
			return nil, failf("case 1", "decision.reasonCodes lack user_approval")
		}
		var want string
		n := 0
		for _, x := range d["inputSnapshot"].([]any) {
			xo, _ := obj(x)
			if getStr(xo, "name") == "approval record" {
				n++
				want, _ = digestOf(xo["digest"])
			}
		}
		if n != 1 {
			return nil, failf("case 1", "inputSnapshot names %d approval records", n)
		}
		if a.apprFile == "" {
			return nil, failf("case 1", "the approval record bytes must be supplied")
		}
		A, err := os.ReadFile(a.apprFile)
		if err != nil {
			return nil, failf("case 1", "%v", err)
		}
		if shaHex(A) != want {
			return nil, failf("case 1", "approval record does not hash to its digest")
		}
		av, err := parseJSON(A)
		if err != nil {
			return nil, failf("case 1", "approval record does not parse")
		}
		if c, err := jcs(av); err != nil || !bytes.Equal(c, A) {
			return nil, failf("case 1", "approval record is not its own RFC 8785 serialization")
		}
		ao, ok := obj(av)
		if !ok {
			return nil, failf("case 1", "approval record is not a JSON object")
		}
		for _, k := range []string{"approvalId", "approver", "session", "actionDigest", "approvedAt", "validUntil"} {
			if _, ok := ao[k]; !ok {
				return nil, failf("case 1", "approval record lacks %s", k)
			}
		}
		for _, k := range []string{"approvalId", "approver", "session"} {
			if !nonEmptyString(ao[k]) {
				return nil, failf("case 1", "approval record %s is not a non-empty string", k)
			}
		}
		ad, ok := digestOf(ao["actionDigest"])
		if !ok {
			return nil, failf("case 1", "approval record actionDigest is not a digest")
		}
		if ad != pd {
			return nil, failf("case 1", "approval names other action bytes")
		}
		if getStr(ao, "approver") != getStr(d, "principal", "id") {
			return nil, failf("case 1", "approver is not principal.id")
		}
		at, e1 := parseTime(getStr(ao, "approvedAt"))
		vu, e2 := parseTime(getStr(ao, "validUntil"))
		if e1 != nil || e2 != nil {
			return nil, failf("case 1", "approvedAt or validUntil is not RFC 3339 UTC with Z")
		}
		// approvedAt <= decidedAt <= T < validity.expiresAt <= validUntil
		if at.After(decided) || decided.After(a.when) || !a.when.Before(expires) || expires.After(vu) {
			return nil, failf("case 1", "approvedAt <= decidedAt <= T < validity.expiresAt <= validUntil does not hold")
		}
	case "declined":
		if verdict != "DENY" && verdict != "REFUSE" {
			return nil, failf("case 2", "verdict %q", verdict)
		}
		if ao, present := d["actionOutcome"]; present {
			o, ok := obj(ao)
			if !ok {
				return nil, failf("case 2", "actionOutcome is not an object")
			}
			s := getStr(o, "status")
			if s != "notAttempted" && s != "blocked" && s != "refused" {
				return nil, failf("case 2", "actionOutcome.status %q", s)
			}
			if o["performedAt"] != nil || o["outcomeRef"] != nil {
				return nil, failf("case 2", "actionOutcome names a performance or an outcome")
			}
		}
	case "executed":
		if verdict != "ALLOW" {
			return nil, failf("case 3", "verdict %q", verdict)
		}
	case "":
	default:
		return nil, failf("call", "unknown case %q", a.kase)
	}
	return rc, nil
}

// ---------------------------------------------------------------- outcome receipt (Section 3.4)

var outcomeRequired = []string{"schemaVersion", "outcomeId", "decisionRef", "executor", "requestedActionDigest",
	"status", "performedAt"}
var outcomeOptional = []string{"effectDigest", "actualActionDigest", "responseDigest", "policyPurpose",
	"receiverRefs", "sequence", "recordedAt", "limitations", "traceContext", "validity", "relationships"}

type outcomeArgs struct {
	pub        ed25519.PublicKey
	pubB64     string
	pol        policy
	executorID string
	effectFile string
}

func verifyOutcome(envBytes []byte, a outcomeArgs, dec *receipt, decPub ed25519.PublicKey) error {
	// Step 1 and 2: steps 1 to 5 of Section 3.2 with the outcome-signing key, type and derived subject
	rc, err := envelopeSteps(envBytes, a.pub, outcomeType)
	if err != nil {
		// Section 3.4 numbers its own steps: steps 1 to 5 of Section 3.2 are its step 1, the statement check its step 2
		step := "step 1"
		if err.(fail).step == "step 6" {
			step = "step 2"
		}
		return fail{"outcome " + step, err.(fail).msg}
	}
	o := rc.Pred
	// Step 3: members, types and forms
	if err := members(o, outcomeRequired, outcomeOptional); err != nil {
		return failf("outcome step 3", "%v", err)
	}
	if s, ok := str(o["schemaVersion"]); !ok || !schemaVersionRE.MatchString(s) {
		return failf("outcome step 3", "schemaVersion %v", o["schemaVersion"])
	}
	if !nonEmptyString(o["outcomeId"]) {
		return failf("outcome step 3", "outcomeId is not a non-empty string")
	}
	if _, ok := obj(o["executor"]); !ok || !nonEmptyString(get(o, "executor", "id")) {
		return failf("outcome step 3", "executor is not an object with a non-empty id string")
	}
	switch getStr(o, "status") {
	case "executed", "refused", "failed", "partial":
	default:
		return failf("outcome step 3", "status %v", o["status"])
	}
	if err := timePaths(o, outcomeTimePaths); err != nil {
		return failf("outcome step 3", "%v", err)
	}
	if o["performedAt"] == nil {
		return failf("outcome step 3", "performedAt is null")
	}
	if err := digestPaths(o, outcomeDigestPaths); err != nil {
		return failf("outcome step 3", "%v", err)
	}
	if err := checkNulls(o, "predicate", map[string]bool{}); err != nil {
		return failf("outcome step 3", "%v", err)
	}
	if err := outcomeTable.obj(o, "", "predicate"); err != nil {
		return failf("outcome step 3", "%v", err)
	}
	// Step 4: binding
	ref, okR := digestOf(o["decisionRef"])
	req, okQ := digestOf(o["requestedActionDigest"])
	pd, _ := digestOf(get(dec.Pred, "proposedAction", "parametersDigest"))
	if !okR || ref != dec.R {
		return failf("outcome step 4", "decisionRef %v is not the content root %s", o["decisionRef"], dec.R)
	}
	if !okQ || req != pd {
		return failf("outcome step 4", "requestedActionDigest is not the decision's parametersDigest")
	}
	// Step 5: identity and separation
	eid := getStr(o, "executor", "id")
	if eid != a.executorID {
		return failf("outcome step 5", "executor.id %q is not the expected %q", eid, a.executorID)
	}
	if !permits(a.pol.Outcome, a.pubB64, eid) {
		return failf("outcome step 5", "the trust policy does not permit this key to attest %q", eid)
	}
	if bytes.Equal(a.pub, decPub) || eid == getStr(dec.Pred, "decisionMaker", "id") {
		return failf("outcome step 5", "outcome key or executor.id is the decision maker's")
	}
	// Step 6: result
	eff, hasEff := digestOf(o["effectDigest"])
	if getStr(o, "status") == "executed" && !hasEff {
		return failf("outcome step 6", "status executed without a non-null effectDigest")
	}
	if a.effectFile != "" {
		if !hasEff {
			return failf("outcome step 6", "effect bytes supplied but effectDigest absent")
		}
		b, err := os.ReadFile(a.effectFile)
		if err != nil {
			return failf("outcome step 6", "%v", err)
		}
		if shaHex(b) != eff {
			return failf("outcome step 6", "effect bytes do not match effectDigest")
		}
	}
	// Step 7: time, decidedAt <= performedAt < validity.expiresAt
	pa, _ := parseTime(getStr(o, "performedAt"))
	decided, _ := parseTime(getStr(dec.Pred, "decidedAt"))
	expires, _ := parseTime(getStr(dec.Pred, "validity", "expiresAt"))
	if pa.Before(decided) || !pa.Before(expires) {
		return failf("outcome step 7", "performedAt is not within decidedAt <= performedAt < expiresAt")
	}
	// Section 3.3, Case 3: the outcome receipt must have status executed
	if s := getStr(o, "status"); s != "executed" {
		return failf("case 3", "outcome status %q is not executed", s)
	}
	return nil
}

// ---------------------------------------------------------------- relying party (Section 4)

// relyingParty refuses an approval whose identity (approvalId, actionDigest, session) the consumed state already
// holds (Section 4, items 1 and 2). It is not part of verifying a receipt; it runs after the receipt has passed.
func relyingParty(apprFile, consumedFile, receivedFile string, t time.Time) error {
	ab, err := os.ReadFile(apprFile)
	if err != nil {
		return err
	}
	av, err := parseJSON(ab)
	if err != nil {
		return fmt.Errorf("approval record does not parse")
	}
	ao, _ := obj(av)
	ad, _ := digestOf(ao["actionDigest"])
	if receivedFile != "" {
		if err := earliestValidUntil(ao, ad, receivedFile, t); err != nil {
			return err
		}
	}
	if consumedFile == "" {
		return nil
	}
	cb, err := os.ReadFile(consumedFile)
	if err != nil {
		return err
	}
	cv, err := parseJSON(cb)
	if err != nil {
		return fmt.Errorf("consumption state does not parse, so it is not a complete view (item 5)")
	}
	// Since a later revision: the state is either one array of approval identities or an object whose members are the
	// generations (current, rotated, archived, ...), each an array; an approval in any generation is consumed (item 4).
	gens := map[string][]any{}
	switch v := cv.(type) {
	case []any:
		gens["current"] = v
	case map[string]any:
		for name, g := range v {
			list, ok := g.([]any)
			if !ok {
				return fmt.Errorf("generation %q of the consumption state is not an array, so it is not a complete view (item 5)", name)
			}
			gens[name] = list
		}
	default:
		return fmt.Errorf("consumption state is neither an array nor an object of generations (item 5)")
	}
	names := make([]string, 0, len(gens))
	for name := range gens {
		names = append(names, name)
	}
	sort.Strings(names)
	for _, name := range names {
		for _, x := range gens[name] {
			xo, _ := obj(x)
			xd, _ := digestOf(xo["actionDigest"])
			if getStr(xo, "approvalId") == getStr(ao, "approvalId") && xd == ad && getStr(xo, "session") == getStr(ao, "session") {
				return fmt.Errorf("approval identity (%s, %s, %s) is already consumed in generation %s", getStr(ao, "approvalId"), ad, getStr(ao, "session"), name)
			}
		}
	}
	return nil
}

// earliestValidUntil applies item 2 of Section 4 since revision -07: among the copies of an approval identity that the
// relying party has received (the received file, a JSON array of approval records) and the record presented now, the
// approval is not honoured unless T is strictly earlier than the earliest validUntil, whatever a later copy carries.
func earliestValidUntil(ao map[string]any, ad, receivedFile string, t time.Time) error {
	rb, err := os.ReadFile(receivedFile)
	if err != nil {
		return err
	}
	rv, err := parseJSON(rb)
	if err != nil {
		return fmt.Errorf("record of received copies does not parse")
	}
	list, ok := rv.([]any)
	if !ok {
		return fmt.Errorf("record of received copies is not an array")
	}
	earliest, err := parseTime(getStr(ao, "validUntil"))
	if err != nil {
		return fmt.Errorf("approval record has no valid validUntil")
	}
	from := "the presented record"
	for i, x := range list {
		xo, _ := obj(x)
		xd, _ := digestOf(xo["actionDigest"])
		if getStr(xo, "approvalId") != getStr(ao, "approvalId") || xd != ad || getStr(xo, "session") != getStr(ao, "session") {
			continue
		}
		v, err := parseTime(getStr(xo, "validUntil"))
		if err != nil {
			return fmt.Errorf("received copy %d has no valid validUntil", i)
		}
		if v.Before(earliest) {
			earliest, from = v, fmt.Sprintf("received copy %d", i)
		}
	}
	if !t.Before(earliest) {
		return fmt.Errorf("T is not earlier than the earliest validUntil %s of approval identity (%s, %s, %s), from %s (item 2)",
			earliest.UTC().Format(time.RFC3339Nano), getStr(ao, "approvalId"), ad, getStr(ao, "session"), from)
	}
	return nil
}

// ---------------------------------------------------------------- command line

func key(b64 string) ed25519.PublicKey {
	b, err := base64.StdEncoding.DecodeString(b64)
	if err != nil || len(b) != ed25519.PublicKeySize {
		fmt.Fprintln(os.Stderr, "a public key is 32 bytes in base64")
		os.Exit(2)
	}
	return ed25519.PublicKey(b)
}

func when(s string) time.Time {
	t, err := parseTime(s)
	if err != nil {
		fmt.Fprintln(os.Stderr, "-t:", err)
		os.Exit(2)
	}
	return t
}

// ---------------------------------------------------------------- Section 3.5, third check (delivery -42)

type held struct {
	file, R, subject string
	pred             map[string]any
	outcome          bool // passed the preliminary checks as an outcome receipt
}

type heldList []string

func (h *heldList) String() string     { return strings.Join(*h, ",") }
func (h *heldList) Set(v string) error { *h = append(*h, v); return nil }

// heldArg is one -held argument, KEY:FILE, with the expected signing key of the held receipt in base64.
type heldArg struct {
	file string
	pub  ed25519.PublicKey
}

func parseHeld(v string) (heldArg, error) {
	k, f, ok := strings.Cut(v, ":")
	if !ok || f == "" {
		return heldArg{}, fmt.Errorf("-held %q is not KEY:FILE", v)
	}
	b, err := base64.StdEncoding.DecodeString(k)
	if err != nil || len(b) != ed25519.PublicKeySize {
		return heldArg{}, fmt.Errorf("-held %q: the key is not 32 bytes in base64", v)
	}
	return heldArg{file: f, pub: ed25519.PublicKey(b)}, nil
}

// loadHeld applies the preliminary checks of the third check of Section 3.5 to every envelope the Auditor supplies,
// under the expected signing key given with it, before any predecessor is looked up: steps 1 to 6 of Section 3.2 for
// a decision receipt, or steps 1 to 5 of Section 3.2 and step 2 of Section 3.4 for an outcome receipt. Either kind may
// be a predecessor of either kind. Since delivery -53, relationships, where present, must also satisfy the field rules
// of Section 3.8 for relationships (heldRelationships). A held envelope that passes neither kind, or fails those rules,
// makes the input invalid; that is not a result of the third check.
func loadHeld(args []string) ([]held, error) {
	var hs []held
	for _, v := range args {
		a, err := parseHeld(v)
		if err != nil {
			return nil, err
		}
		b, err := os.ReadFile(a.file)
		if err != nil {
			return nil, err
		}
		rc, err := envelopeSteps(b, a.pub, decisionType)
		tc := decisionTable
		if err != nil {
			rc2, err2 := envelopeSteps(b, a.pub, outcomeType)
			if f, ok := err2.(fail); ok { // M21-a: the step as Section 3.4 counts it, as in verifyOutcome
				step := "outcome step 1"
				if f.step == "step 6" {
					step = "outcome step 2"
				}
				err2 = fail{step, f.msg}
			}
			if err2 != nil {
				return nil, fmt.Errorf("held receipt %s passes under its expected key neither steps 1 to 6 of "+
					"Section 3.2 as a decision receipt (%v) nor steps 1 to 5 of Section 3.2 and step 2 of Section 3.4 "+
					"as an outcome receipt (%v)", a.file, err, err2)
			}
			rc, tc = rc2, outcomeTable
		}
		isOutcome := tc == outcomeTable
		if err := heldRelationships(rc.Pred, tc); err != nil {
			return nil, fmt.Errorf("held receipt %s: relationships does not satisfy the field rules of Section 3.8 "+
				"for relationships (%v)", a.file, err)
		}
		so, _ := obj(rc.Statement["subject"].([]any)[0])
		d, _ := str(get(so, "digest", "sha256"))
		hs = append(hs, held{file: a.file, R: rc.R, subject: d, pred: rc.Pred, outcome: isOutcome})
	}
	return hs, nil
}

// heldRelationships applies to relationships, where present in the predicate of a held receipt, the field rules of
// Section 3.8 for relationships that step 7 of Section 3.2 and step 3 of Section 3.4 apply: the rows of
// relationships in fieldrules.go with the types and notes they reference, the timestamp form of
// relationships[].declaredAt, and no null. Since delivery -53 this is part of the preliminary checks of the third
// check of Section 3.5.
func heldRelationships(pred map[string]any, tc *tableChecker) error {
	x, ok := pred["relationships"]
	if !ok {
		return nil
	}
	var r fieldRule
	for _, c := range tc.children[""] {
		if c.path == "relationships" {
			r = c
		}
	}
	if r.path == "" {
		return fmt.Errorf("no field rule for relationships")
	}
	if err := checkNulls(x, "predicate.relationships", map[string]bool{}); err != nil {
		return err
	}
	if err := tc.val(x, r, "predicate.relationships"); err != nil {
		return err
	}
	return timePaths(pred, []string{"relationships[].declaredAt"})
}

// auditorThird runs the third check of Section 3.5 over the receipts held. Where a held envelope fails the
// preliminary checks, it prints that the input is invalid and exits with code 2, without a result of the check.
// Where an entry fails, it exits with code 4. Otherwise its last line says that the check passed over the number of
// receipts held, which is the line that tells a run of the check apart from a run without -held.
func auditorThird(rc *receipt, args []string) {
	const pre = "AUDITOR, Section 3.5, third check"
	hs, err := loadHeld(args)
	if err != nil {
		fmt.Println(pre+": NO RESULT, the input is invalid:", err)
		os.Exit(2)
	}
	at := fmt.Sprintf("%s over the receipts held (%d), separate from the receipt:", pre, len(hs))
	var lines []string
	if err := supersedes(rc.Pred, "", hs, map[string]bool{rc.R: true}, &lines); err != nil {
		fmt.Println(at, "FAIL", err)
		os.Exit(4)
	}
	for _, l := range lines {
		fmt.Println(at, l)
	}
	if len(lines) == 0 {
		fmt.Println(at, "PASS, no entry of relationships with relation supersedes")
	} else {
		fmt.Println(at, "PASS")
	}
}

// auditorSets runs, for -second, the third and then the second check of Section 3.5 over the receipts held, after
// the same preliminary checks. Where a held envelope fails them, neither check gives a result and the exit code is 2.
// The lines of the third check are those of auditorThird; where the third check fails, its exit code 4 is kept and
// the second check still runs and prints its line. The last line is that of the second check.
func auditorSets(rc *receipt, args []string) {
	const pre = "AUDITOR, Section 3.5"
	hs, err := loadHeld(args)
	if err != nil {
		fmt.Println(pre+", second and third check: NO RESULT, the input is invalid:", err)
		os.Exit(2)
	}
	code := 0
	at3 := fmt.Sprintf("%s, third check over the receipts held (%d), separate from the receipt:", pre, len(hs))
	var lines []string
	if err := supersedes(rc.Pred, "", hs, map[string]bool{rc.R: true}, &lines); err != nil {
		fmt.Println(at3, "FAIL", err)
		code = 4
	} else {
		for _, l := range lines {
			fmt.Println(at3, l)
		}
		if len(lines) == 0 {
			fmt.Println(at3, "PASS, no entry of relationships with relation supersedes")
		} else {
			fmt.Println(at3, "PASS")
		}
	}
	at2 := fmt.Sprintf("%s, second check over the receipts held (%d), separate from the receipt:", pre, len(hs))
	n, err := secondCheck(hs)
	if err != nil {
		fmt.Println(at2, "FAIL", err)
		if code == 0 {
			code = 5
		}
	} else {
		fmt.Printf("%s PASS, %d outcome receipt(s) held with status executed, none names a decision receipt held "+
			"whose verdict is not ALLOW\n", at2, n)
	}
	os.Exit(code)
}

// secondCheck is the second check of Section 3.5: no outcome receipt held with status executed may name, in
// decisionRef, the content root of a receipt held whose verdict is not ALLOW. It counts the receipts held, which have
// passed the preliminary checks; an expired one is not left out. A decisionRef that names no decision receipt held
// gives no conflict, since the check is only as complete as the set held. It returns the number of executed outcome
// receipts held or the first conflict.
func secondCheck(hs []held) (int, error) {
	n := 0
	for _, o := range hs {
		if !o.outcome || getStr(o.pred, "status") != "executed" {
			continue
		}
		n++
		ref := getStr(o.pred, "decisionRef", "sha256")
		for _, d := range hs {
			if d.outcome || d.R != ref {
				continue
			}
			if v := getStr(d.pred, "decision", "verdict"); v != "ALLOW" {
				return n, fmt.Errorf("the outcome receipt held with content root %s has status executed and names in "+
					"decisionRef the content root %s of a decision receipt held whose verdict is %s, not ALLOW",
					o.R, ref, v)
			}
		}
	}
	return n, nil
}

// supersedes follows the entries of relationships with relation supersedes from one predicate through the
// predecessors held, in turn, and returns one line per entry or the first entry that fails.
func supersedes(pred map[string]any, where string, hs []held, seen map[string]bool, out *[]string) error {
	rels, _ := pred["relationships"].([]any)
	for i, x := range rels {
		e, _ := obj(x)
		if getStr(e, "relation") != "supersedes" {
			continue
		}
		at := fmt.Sprintf("%srelationships[%d]", where, i)
		tgt := getStr(e, "targetReceiptDigest", "digest")
		var p *held
		for k := range hs {
			if hs[k].R == tgt {
				p = &hs[k]
				break
			}
		}
		if p == nil {
			return fmt.Errorf("%s supersedes %s, the content root of no receipt held", at, tgt)
		}
		if _, ok := e["targetSubjectDigest"]; ok {
			if sd := getStr(e, "targetSubjectDigest", "digest"); sd != p.subject {
				return fmt.Errorf("%s.targetSubjectDigest is %s, not the subject digest %s of the receipt held with content root %s",
					at, sd, p.subject, tgt)
			}
		}
		*out = append(*out, fmt.Sprintf("%s supersedes the receipt held with content root %s", at, tgt))
		if !seen[p.R] {
			seen[p.R] = true
			if err := supersedes(p.pred, "predecessor "+p.R[:12]+" ", hs, seen, out); err != nil {
				return err
			}
		}
	}
	return nil
}

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: adrverify decision|outcome ...")
		os.Exit(2)
	}
	switch os.Args[1] {
	case "decision":
		fs := flag.NewFlagSet("decision", flag.ExitOnError)
		polFile := fs.String("policy", "", "trust policy file")
		pub := fs.String("pub", "", "decision maker public key, base64")
		signer := fs.String("signer", "", "expected decisionMaker.id")
		t := fs.String("t", "", "evaluation time, RFC 3339 UTC")
		aud := fs.String("aud", "", "expected audience")
		nonce := fs.String("nonce", "", "expected nonce")
		kase := fs.String("case", "", "approval, declined or executed")
		action := fs.String("action", "", "action bytes file")
		appr := fs.String("approval", "", "approval record file")
		consumed := fs.String("consumed", "", "relying-party check of Section 4, separate from verifying the receipt: "+
			"JSON array of approval identities already honoured; needs -case approval")
		received := fs.String("received", "", "relying-party check of item 2 of Section 4: JSON array of approval "+
			"records of the same identity received before; needs -case approval")
		var heldFiles heldList
		fs.Var(&heldFiles, "held", "third check of Section 3.5, separate from verifying the receipt: KEY:FILE, the "+
			"expected signing key in base64 and the envelope of a decision or outcome receipt the Auditor holds; repeatable")
		second := fs.Bool("second", false, "with -held: also the second check of Section 3.5 over the receipts held")
		_ = fs.Parse(os.Args[2:])
		if *second && len(heldFiles) == 0 {
			fmt.Fprintln(os.Stderr, "-second, the second check of Section 3.5, needs -held")
			os.Exit(2)
		}
		if fs.NArg() != 1 || *polFile == "" || *pub == "" || *signer == "" || *t == "" {
			fmt.Fprintln(os.Stderr, "decision needs -policy, -pub, -signer, -t and one envelope")
			os.Exit(2)
		}
		if (*consumed != "" || *received != "") && *kase != "approval" {
			fmt.Fprintln(os.Stderr, "-consumed, the relying-party check of Section 4, needs -case approval")
			os.Exit(2)
		}
		envBytes, err := os.ReadFile(fs.Arg(0))
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(2)
		}
		rc, err := verifyDecision(envBytes, decisionArgs{pub: key(*pub), pubB64: *pub, pol: loadPolicy(*polFile),
			signer: *signer, aud: *aud, nonce: *nonce, when: when(*t), kase: *kase, actionFile: *action, apprFile: *appr})
		if err != nil {
			fmt.Println("FAIL", err)
			os.Exit(1)
		}
		fmt.Println("PASS content root", rc.R)
		if *consumed != "" || *received != "" {
			if err := relyingParty(*appr, *consumed, *received, when(*t)); err != nil {
				fmt.Println("RELYING PARTY, Section 4, separate from the receipt: REFUSE", err)
				os.Exit(3)
			}
			if *received != "" {
				fmt.Println("RELYING PARTY, Section 4, separate from the receipt: approval identity not consumed and not expired")
			} else {
				fmt.Println("RELYING PARTY, Section 4, separate from the receipt: approval identity not consumed")
			}
		}
		if *second {
			auditorSets(rc, heldFiles)
		}
		if len(heldFiles) > 0 {
			auditorThird(rc, heldFiles)
		}
	case "outcome":
		fs := flag.NewFlagSet("outcome", flag.ExitOnError)
		polFile := fs.String("policy", "", "trust policy file")
		pub := fs.String("pub", "", "outcome-signing public key, base64")
		executorID := fs.String("executor-id", "", "expected executor.id")
		decFile := fs.String("decision", "", "decision receipt envelope")
		decPub := fs.String("decision-pub", "", "decision maker public key, base64")
		decSigner := fs.String("decision-signer", "", "expected decisionMaker.id")
		t := fs.String("t", "", "evaluation time for the decision, RFC 3339 UTC")
		decAud := fs.String("decision-aud", "", "expected audience of the decision")
		decNonce := fs.String("decision-nonce", "", "expected nonce of the decision")
		effect := fs.String("effect", "", "effect bytes file")
		var heldFiles heldList
		fs.Var(&heldFiles, "held", "third check of Section 3.5, separate from verifying the receipt: KEY:FILE, the "+
			"expected signing key in base64 and the envelope of a decision or outcome receipt the Auditor holds; repeatable")
		second := fs.Bool("second", false, "with -held: also the second check of Section 3.5 over the receipts held")
		_ = fs.Parse(os.Args[2:])
		if *second && len(heldFiles) == 0 {
			fmt.Fprintln(os.Stderr, "-second, the second check of Section 3.5, needs -held")
			os.Exit(2)
		}
		if fs.NArg() != 1 || *polFile == "" || *pub == "" || *executorID == "" || *decFile == "" || *decPub == "" ||
			*decSigner == "" || *t == "" {
			fmt.Fprintln(os.Stderr, "outcome needs -policy, -pub, -executor-id, -decision, -decision-pub, -decision-signer, -t and one envelope")
			os.Exit(2)
		}
		pol := loadPolicy(*polFile)
		decBytes, err := os.ReadFile(*decFile)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(2)
		}
		dp := key(*decPub)
		dec, err := verifyDecision(decBytes, decisionArgs{pub: dp, pubB64: *decPub, pol: pol, signer: *decSigner,
			aud: *decAud, nonce: *decNonce, when: when(*t), kase: "executed"})
		if err != nil {
			fmt.Println("FAIL decision", err)
			os.Exit(1)
		}
		envBytes, err := os.ReadFile(fs.Arg(0))
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(2)
		}
		if err := verifyOutcome(envBytes, outcomeArgs{pub: key(*pub), pubB64: *pub, pol: pol, executorID: *executorID,
			effectFile: *effect}, dec, dp); err != nil {
			fmt.Println("FAIL", err)
			os.Exit(1)
		}
		fmt.Println("PASS bound to decision", dec.R)
		if len(heldFiles) > 0 {
			rc, err := envelopeSteps(envBytes, key(*pub), outcomeType)
			if err != nil { // not reached: the receipt has passed these steps above
				fmt.Fprintln(os.Stderr, err)
				os.Exit(2)
			}
			if *second {
				auditorSets(rc, heldFiles)
			}
			auditorThird(rc, heldFiles)
		}
	default:
		fmt.Fprintln(os.Stderr, "usage: adrverify decision|outcome ...")
		os.Exit(2)
	}
}
