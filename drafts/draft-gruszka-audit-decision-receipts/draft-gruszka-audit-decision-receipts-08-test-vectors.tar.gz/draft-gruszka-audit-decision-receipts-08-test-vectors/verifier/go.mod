module adrverify

go 1.22
