# Test vectors of draft-gruszka-audit-decision-receipts-08

This package holds all 171 test vectors of Appendix A of draft-gruszka-audit-decision-receipts-08: the seven vectors
of Appendix A.3 (V1-good, V1-bad, V2-good, V2-bad, V3-decision, V3-good, V3-bad), the failure vectors F1 to F93, F95
to F125 with F17-outcome, the passing vectors V2-micro, V2-num, V2-rel, V3-rel, V3-seq, F94, V1-accept, V2-ref and
V3-late, K1 to K29 of the third check of Section 3.5 and S1 and S2 of its second check. Appendix A.3 and Appendix
A.5 of the draft give the seven vectors of A.3 and F10 in full; the package holds them as well, so that one run
covers every vector. It also holds the example Signed Statements and SCITT Receipts for registration that
Appendix A.4 names.

## Contents

- vectors/ holds every envelope and every input that a check uses, under the names that expected.json gives. Among
  them are action bytes, approval records, consumption states, effect bytes and trust policies.
- expected.json gives, for each vector, where the draft gives it, the result and step expected for it, the
  arguments of the verifier, its expected exit code and the start of its first output line, the output recorded
  when the package was made, and the proofbundle 6.4.0 commands with their recorded exit codes, and lists the
  checks of a4/.
- verifier/ holds a verifier of Sections 3 and 4 written in Go from the text of the draft, with the Go standard
  library only. It shares no code with proofbundle. verifier/BUILD.txt gives the build command and the SHA-256 of
  the program for one toolchain.
- run_vectors.py runs every vector against that verifier.
- For the third check of Section 3.5 the verifier takes each receipt held as -held KEY:FILE, the expected signing
  key in base64 and the envelope. Before it looks up a predecessor, it checks every receipt held under its key, a
  decision receipt by steps 1 to 6 of Section 3.2 and an outcome receipt by steps 1 to 5 of Section 3.2 and step 2 of
  Section 3.4. The predicate of a receipt held must be a JSON object, and where it has relationships, that member and
  its entries must satisfy the field rules of Section 3.8 for relationships. Where a receipt held does not
  meet these checks, the input is invalid, the verifier gives no result
  for the third check and ends with exit code 2. Where a predecessor is not among the receipts held, the third check
  fails with exit code 4. A run without -held does not run the third check.
- For the second check of Section 3.5 the verifier takes, with -second, the same -held arguments and the same
  preliminary checks, and runs that check after the third. It reports an outcome receipt held with status executed
  whose decisionRef names the content root of a decision receipt held whose verdict is not ALLOW. If the third check
  passed, the verifier then exits with code 5; if the third check fails, its exit code 4 is kept, and the second
  check still runs and reports its result. A decisionRef that names no decision receipt held gives no conflict,
  because the check is only as complete as the receipts held. A run without -second does not run the second check
  and prints what it printed before.
- description.txt says, for every vector, how it is derived and which inputs the verifier is given: T, the
  envelope, keys, expected audience and nonce, case, action, effect and approval bytes, consumption state and trust
  policy, and for K1 to K29, S1 and S2 the receipts held with the expected signing key of each. inputs.json
  holds the same calls as expected.json. Neither names a result, so a verifier can be run
  blind against them; the expected results are only in expected.json. V3-decision is checked as the pair with
  V3-good.
- a4/ holds the inputs of the registration examples. These are the V2-good envelope bytes, Signed Statements A and B, the
  detached payload of B, the counterexamples, the public test keys of the Issuer and of the Receipt issuer, and the
  two SCITT Receipts with a counterexample. A4-description.txt is the text that gave their bytes and described how
  they are built and checked.
- MANIFEST.sha256 lists the SHA-256 of every other file.
- The relying-party inputs of Section 4 have these forms. A consumption state is either a JSON array of
  approval identities, each an object with approvalId, actionDigest and session, which is the current
  generation (c0.json is empty, f-c1.json holds the identity of ap, as c1 in Appendix A.5), or a JSON
  object whose members name generations such as current and rotated, each such an array (f-c2.json, used
  by F13). in-c3.json, used by F71, is f-c1.json without its closing bracket and does not parse. F77 uses
  f-c1.json. The received copies of -received (r1.json, used by F90) are a JSON array of approval records.

## Running

Before extracting the downloaded archive, verify its SHA-256 against the value in Appendix A.5 of the draft.
Once extracted, check the files and run the verifier.

    sha256sum -c MANIFEST.sha256
    python3 run_vectors.py

You can try it offline. If a vector does not behave as the draft says, please tell us.

The script uses the Python standard library and builds the verifier with a local Go toolchain without network
access. The recorded outputs were produced with Python 3.13.18 and Go 1.24.7 on Linux x86-64. Other
toolchains may produce different binary hashes or output. With
--verifier PATH it uses an existing build instead. With --proofbundle PATH it also runs the recorded commands
of proofbundle 6.4.0 (https://proofbundle.dev), a separate open-source verifier, and compares their exit codes.

It prints one line per vector and exits with 0 only if every vector
and every check meets its expected result. A passing vector must pass
with exit code 0. A failing vector must fail at its expected step.
A vector that the relying party refuses under Section 4 must pass
receipt verification and be refused.

For each vector of the third check of Section 3.5, receipt
verification must pass first. With valid held inputs, the output
must show that the third check ran over the supplied held receipts,
with exit code 0 if it passes or 4 if it fails. With invalid held
input, the verifier must instead report invalid input and no result
for the third check, with exit code 2.

For S1 and S2, the vectors of the second check of Section 3.5,
receipt verification must pass first, and the last line of the
output must show that the second check ran over the supplied held
receipts, with exit code 0 if it passes or 5 if it fails.

The files in a4/ must have the sizes, SHA-256 values and one-byte
changes that A4-description.txt states.

It does not verify the COSE signatures of a4/;
A4-description.txt describes how to.

## Further vectors

Appendix A.5 of the draft gives the further vectors in tables. This section describes them. Section numbers are
those of the draft.

F91, F92 and F93 are V2-good with the member n and the numbers 9007199254740994, 9007199254740992 and
-9007199254740992 written after the member _type, and fail at step 4 of Section 3.2. Each is its own RFC 8785
serialization and fails only under the sentence of that step on numbers whose absolute value is greater than
9007199254740991 and that is written without the frac and exp parts of the grammar in Section 6 of RFC 8259, which
F81 also violates. F92 is 2^53, F91 is 2^53 plus 2, and F93 is the negative of F92. F94 is the same with the number
1e+21, which is written with exp and is its own RFC 8785 serialization, and passes. For step 8, F122 is V1-good
checked under a trust policy that binds the key of gate-1 to gate-1 and gate-2, with gate-2 as the expected
decisionMaker.id, and fails at step 8.

Three further vectors are each checked like their base vector. V2-num is V2-good with the member n and the number
1.5e-7 written after the member _type, which RFC 8785 writes in the same form, and passes. F89 is V1-good without
the approval record entry of inputSnapshot and with the evidenceRefs of V3-decision, which cite B. It fails at Case
1 of Section 3.3 because its inputSnapshot has no entry whose name is "approval record". F89 illustrates rejection
despite the presence of evaluation evidence, but does not establish that a verifier enforces the second half of the
rule of Section 2.6. F17 fails at the verdict check of Case 3 whatever its evidenceRefs hold and only illustrates
that rule. F90 is the envelope of F10, checked like F10 by a relying party that has honoured nothing and has
received ap, whose validUntil is earlier than T; that relying party refuses it under item 2 of Section 4.

F95 is V2-good with its payload written without its base64 padding and fails at step 2 of Section 3.2. F96 and F97
are the envelope of V2-good with one more member whose value is written NaN or Infinity, neither of which is a
number in the grammar of Section 6 of RFC 8259; both fail at step 1. The test package describes each vector and the
inputs it is checked with without naming its result, which only the file of expected results gives, so that an
implementation can be checked blind.

For the member relationships, V2-rel and V3-rel are V2-good and V3-good with one entry that holds every member of
Figure 1 and Figure 2 for it, and pass. F98 to F107 change that entry or the array in V2-good, one rule of Section
3.8 each, and fail at step 7 of Section 3.2; F108 to F114 do the same in V3-good and fail at step 3 of Section 3.4.

For the third check of Section 3.5, K1 to K3 check a receipt together with the receipts that an Auditor holds. The
entry of relationships of V2-rel has relation supersedes and names V1-good by targetReceiptDigest and
targetSubjectDigest. K1 is V2-rel with V1-good and V2-num held, and passes. K2 is V2-rel with
relationships[0].targetSubjectDigest set to an object whose digestAlgorithm is "jcs-sha256-v1" and whose digest is
the value of subject[0].digest.sha256 of V2-num, with the same receipts held, and K3 is V2-rel with V2-good and
V2-num held; both pass Section 3.2 and fail that check. V1-good and V2-rel decide different actions, and a DENY
changes no state (Section 2.2), so K1 to K3 show only how that check matches digests, not a sequence of states of
one action (Section 2.1). K4 and K5 check the outcome receipt V3-rel, whose entry of relationships names V1-good as
that of V2-rel does. K4 holds V1-good and passes; K5 holds V2-good, passes Section 3.4 and fails that check. Like K1
to K3, K4 and K5 show only how that check matches digests, not a sequence of states of one action.

Each receipt held is given with its expected signing key, and K1 to K29 show whether that check ran over the
receipts held. K1 and K4 hold V1-good, which has expired at their evaluation time T, and pass that check. In K6 the
predecessor V1-good and in K8 a receipt held that no entry names is held only with one byte of its signature
changed, and in K11 V1-good is supplied under the key of observer-1, so the input of each is invalid. K7 names F30,
which passes steps 1 to 6 of Section 3.2 and fails step 7, as its predecessor and passes that check. K9 is a
decision receipt and K10 an outcome receipt whose predecessor is the outcome receipt V3-good, and both pass, as K1
and K4 do with a decision receipt as predecessor. K12 to K14 check a chain of three, a receipt that names V2-rel,
which names V1-good. With V1-good held only with a changed signature the input is invalid (K12), with V1-good absent
that check fails (K13), and with V2-rel and V1-good held it passes (K14). K27 checks V2-good, which has no entry of
relationships, with V2-rel held, whose entry names V1-good, which is not held; it passes, because the lookup does
not follow the entries of a receipt held that no entry of the chain names.

K15 and K16 hold a predecessor whose predicate is not a JSON object. F120 is V2-good with predicate replaced by the
JSON string "decision" and F121 is V3-good with predicate replaced by the empty JSON array, each with the subject
digest taken over that value and signed again by the key that signed its base. As receipts in their own right, F120
fails at step 6 of Section 3.2 and F121 at step 2 of Section 3.4. K15 uses a variant of V2-rel whose entry of
relationships names F120, signed again by the key that signed V2-rel. K16 uses a variant of V3-rel whose entry names
F121, signed again by the key that signed V3-rel. Each holds F120 or F121 under the key that signed it. The input of
each is invalid because the predicate of a held receipt must be a JSON object.

K17 to K25 hold a receipt whose relationships does not have the form that Section 3.8 gives. In K17 to K19, the held
predecessor is a variant of V2-good with relationships added, signed again by the key that signed V2-good. Each uses
a variant of V2-rel whose entry names that predecessor, signed again by the key that signed V2-rel. In K20 to K22,
the held predecessor is a variant of V3-good with relationships added, signed again by the key that signed V3-good.
Each uses a variant of V3-rel whose entry names that predecessor, signed again by the key that signed V3-rel. That
relationships is an object instead of an array in K17 and K20, has an entry that is not an object in K18 and K21,
and has an entry with relation supersedes whose targetReceiptDigest is an object with the only member sha256 in K19
and K22. K23 to K25 check V2-rel with V1-good held and, named by no entry, the predecessor of K17, K18 or K19, and
K26 holds F120 in the same way. The held receipts of K17 to K25 pass steps 1 to 6 of Section 3.2, or steps 1 to 5 of
Section 3.2 and step 2 of Section 3.4, under the key that signed them, and F120 fails step 6 of Section 3.2. The
input of each of K17 to K26 is invalid, because the preliminary checks of Section 3.5 include the form of predicate
and of relationships of every supplied held receipt, whether or not an entry names it.

For the type integer of Section 3.8, V3-seq is V3-good with the member sequence whose runId is r1 and whose seq is
written 1, and passes. F115 writes seq as 1.0 and fails at step 1 of Section 3.4, because its payload is not its own
RFC 8785 serialization, which writes 1. F116 writes seq as 1e+21, which is its own serialization, and fails at step
3 of Section 3.4.

For the form of the entries of signatures in step 1 of Section 3.2, F117, F118 and F119 are the envelope of V1-good
with a second entry of signatures after its one entry, the number 42, the empty object and an object whose sig is
the number 5. The first entry still verifies in step 3, and each of the three fails at step 1. For step 3, F123 is
the envelope of V1-good with S of its signature replaced by S plus L, and fails at step 3. No vector separates the
equation with the cofactor from the one without.

Each of the following vectors separates one rule that the earlier vectors of this package do not separate. Each
changed payload is signed again by the key that signed its base, with the subject digest taken over the new
predicate.

F124 is V2-good with privacy.rawInputsIncluded written as the JSON string "false" instead of the boolean false and
fails at step 7 of Section 3.2. V2-ref is V2-good with proposedAction.parametersRef {"uri":
"https://git.example/acme/widgets/pull/7"} in place of proposedAction.parametersDigest, checked without action
bytes, and passes, because note (1) of Section 3.8 permits parametersRef alone. F125 is the envelope of V2-ref
checked with the action bytes a2 and fails at step 10 of Section 3.2, because this document takes no digest from
parametersRef. V3-late is V3-good with performedAt 2026-10-15T09:11:01Z, one second after its evaluation time T and
before validity.expiresAt of V3-decision, and passes, because step 7 of Section 3.4 does not compare performedAt
with T.

K28 is V2-rel with a second entry of relationships with relation supersedes, whose targetReceiptDigest names the
content root of V2-good, checked like K1 with V1-good and V2-num held. Its first entry is met and its second names
no receipt held, so it passes Section 3.2 and fails the third check, because each entry with relation supersedes is
checked on its own. K29 is V2-rel with relation corrects in place of supersedes in its one entry, which still names
V1-good, checked with V2-num held only. It passes the third check, because an entry with another relation is not
part of that check, although its target is not held.

For the second check of Section 3.5, S1 and S2 check V3-good, as the pair with V3-decision, with two receipts held
and -second. In S1 they are V3-decision with decision.verdict ESCALATE and V3-good with decisionRef naming the
content root of that receipt; S1 passes Section 3.4 and fails the second check, because an outcome receipt held with
status executed names a decision receipt held whose verdict is not ALLOW. In S2 they are V3-decision and V3-good
themselves, and S2 passes that check. The first check of Section 3.5 has no vector.

## Keys

All keys in this package are test keys of the draft, given in Appendix A.1 and in A4-description.txt. They are
published and are not for real receipts.

Assisted by little helpers.
